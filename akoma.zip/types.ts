// Fix: Defined and exported UserRole enum directly to fix module resolution errors.
export enum UserRole {
  Patient = 'Patient',
  Doctor = 'Doctor',
  Admin = 'Admin',
  Nurse = 'Nurse',
  LabTech = 'Lab Technician',
  Pharmacist = 'Pharmacist',
  Insurer = 'Insurer',
  Lawyer = 'Lawyer',
  Vendor = 'Vendor',
  FacilityAdmin = 'Facility Admin',
}

export type PasswordStrength = 'Weak' | 'Medium' | 'Strong';

export interface MedicationReminder {
  id: string;
  medicationName: string;
  dosage: string;
  times: string[];
}
// Payout Account Types
interface BasePayoutAccount {
    id: string;
    isDefault: boolean;
}
export interface BankPayoutAccount extends BasePayoutAccount {
    type: 'bank';
    bankName: string;
    accountHolder: string;
    accountNumber: string;
}
export interface PaystackPayoutAccount extends BasePayoutAccount {
    type: 'paystack';
    email: string;
}
export interface MomoPayoutAccount extends BasePayoutAccount {
    type: 'momo';
    provider: string;
    phoneNumber: string;
}
export type PayoutAccount = BankPayoutAccount | PaystackPayoutAccount | MomoPayoutAccount;

export interface User {
  id: string;
  akomaId: string;
  name: string;
  email: string;
  password?: string; // Added for authentication
  country?: string; // Added for registration
  approvalStatus: 'Approved' | 'Pending' | 'Suspended'; // Added for vendor/partner onboarding
  role: UserRole;
  profileImageUrl?: string;
  joinDate?: string;
  isListedProvider?: boolean; // For professionals to opt-in to be discoverable
  temporaryPassword?: boolean; // For forced password change flow
  payoutAccounts?: PayoutAccount[]; // For vendors, professionals
  // Role-specific properties
  specialty?: string; // For Doctor
  companyName?: string; // For Vendor, Insurer, Lawyer
  licenseNumber?: string; // For clinical roles
  facilityName?: string; // For facility-based roles
}

export interface HealthSummary {
  metric: string;
  value: string;
  status: 'normal' | 'high' | 'low';
}

export interface Appointment {
  id: string;
  specialty: string;
  doctor: string;
  date: string;
  time: string;
  status: 'booked' | 'completed' | 'cancelled';
}

export interface Prescription {
  id: string;
  drug: string;
  dosage: string;
  date: string;
  dispensed: boolean;
}

export interface LabResult {
  id: string;
  testName: string;
  date: string;
  scientificExplanation: string;
  attachmentUrl?: string;
  attachmentName?: string;
}

export interface Patient extends User {
  role: UserRole.Patient;
  lastVisit: string;
  status: string;
  appointments: Appointment[];
  prescriptions: Prescription[];
  labResults: LabResult[];
  healthSummary: HealthSummary[];
  doctorNotes?: string[];
  onboardingCompleted?: boolean;
  medicalHistory?: {
    allergies: string;
    conditions: string;
  };
  currentMedications?: {
    name: string;
    dosage: string;
  }[];
  emergencyContacts?: EmergencyContact[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isReadByRecipient: boolean;
  readStatus?: 'sent' | 'read';
  attachment?: {
    name: string;
    type: 'image' | 'doc' | 'audio' | 'video' | 'other';
    url: string;
  };
}

export enum Currency {
  USD = 'USD',
  GHS = 'GHS',
  EUR = 'EUR',
  GBP = 'GBP',
  NGN = 'NGN',
  KES = 'KES',
  ZAR = 'ZAR',
}

export interface Language {
  code: string;
  name: string;
}

export interface EmergencyContact {
  name: string;
  number: string;
  relationship?: string;
}

export interface StaffMember {
    id: string;
    name: string;
    role: string;
    onDuty: boolean;
}

export interface FacilityAppointment {
    id: string;
    patientName: string;
    doctorName: string;
    date: string;
    time: string;
    reason: string;
}

export interface Provider {
  id: string;
  name: string;
  specialty: string;
  location: string;
  available: boolean;
  availability?: Availability;
}

export interface Availability {
  [date: string]: {
    capacity: number;
    slots: {
      time: string;
      bookedBy?: string;
    }[];
  };
}

export interface Task {
    id: string;
    description: string;
    completed: boolean;
    priority: 'High' | 'Medium' | 'Low';
    dueDate?: string;
    creationDate: string;
}

export interface NurseAssignment {
    patientName: string;
    room: string;
    tasks: Task[];
}

export interface PharmacyPrescription {
    id: string;
    patientName: string;
    medication: string;
    date: string;
    status: 'Pending' | 'Filled';
    doctor: string;
}

export interface InsuranceClaim {
    id: string;
    patientName: string;
    policyNumber: string;
    claimAmount: number;
    date: string;
    status: 'Processing' | 'Approved' | 'Denied';
    isActivated?: boolean;
}

export interface Conversation {
  id: string;
  participants: { id: string; name: string; profileImageUrl?: string }[];
  messages: ChatMessage[];
  isTyping?: boolean;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  baseCurrency: Currency;
}

export interface CartItem {
    product: Product;
    quantity: number;
}

export interface Receipt {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  currency: Currency;
}

export interface Vendor {
    id:string;
    name: string;
    specialty: string;
    applicationStatus: 'Approved' | 'Pending';
    dateApplied: string;
}

export interface LegalCase {
    id: string;
    clientName: string;
    caseType: string;
    status: 'Active' | 'Closed' | 'Consultation';
    lastUpdated: string;
    isActivated?: boolean;
}

export interface FacilityPatient {
    id: string;
    name: string;
    akomaId: string;
    lastVisit: string;
    doctor: string;
}

export interface LabRequest {
    id: string;
    patientName: string;
    testName: string;
    date: string;
    status: 'Pending' | 'In Progress' | 'Completed';
    attachmentUrl?: string;
    attachmentName?: string;
}

export interface Notification {
  id: string;
  message: string;
  date: string;
  read: boolean;
  type?: 'user' | 'payout' | 'system';
  title?: string;
}

export interface OnboardingData {
    allergies: string;
    conditions: string;
    medications: { name: string; dosage: string }[];
    emergencyContacts: EmergencyContact[];
}

export interface Theme {
  background: string;
  font: 'Inter' | 'Roboto' | 'Lato' | 'Montserrat';
}

export interface HealthTip {
  title: string;
  tip: string;
}

export interface ActivityItem {
  id: string;
  text: string;
  timestamp: string;
}

export type ToastType = 'success' | 'error' | 'info';

export interface Toast {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
}

export interface ConfirmationModalState {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  confirmText?: string;
  cancelText?: string;
}