import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { UserRole } from '../types';
import { validateEmail, checkPasswordStrength } from '../utils/validation';
import { COUNTRIES } from '../constants';
import { Spinner } from './ui/Spinner';

const Login: React.FC = () => {
    const { signIn, signUp, t } = useApp();
    const [isSignUp, setIsSignUp] = useState(false);
    
    // Form state
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const [role, setRole] = useState<UserRole>(UserRole.Patient);
    const [country, setCountry] = useState(COUNTRIES[0].code);
    
    // UI State
    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const passwordStrength = checkPasswordStrength(password);

    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccessMessage('');
        setIsLoading(true);

        if (isSignUp) {
            // Sign Up Logic
            if (!validateEmail(email)) { setError(t.auth.errors.invalidEmail); setIsLoading(false); return; }
            if (passwordStrength.strength === 'Weak') { setError(t.auth.errors.passwordTooWeak); setIsLoading(false); return; }
            if (!fullName.trim()) { setError(t.auth.errors.nameRequired); setIsLoading(false); return; }

            const result = signUp({ name: fullName, email, password, role, country });
            if (result.success) {
                if (result.message) {
                    setSuccessMessage(result.message);
                    setIsSignUp(false); // Switch to sign-in view
                }
            } else {
                setError(result.message || 'An unknown error occurred.');
            }
        } else {
            // Sign In Logic
            const result = signIn(email, password);
            if (!result.success) {
                setError(result.message || t.auth.errors.authFailed);
            }
        }
        setIsLoading(false);
    };

    const renderPasswordStrength = () => {
        if (!password || !isSignUp) return null;
        const strength = passwordStrength.strength;
        const color = strength === 'Strong' ? 'bg-akoma-green' : strength === 'Medium' ? 'bg-yellow-500' : 'bg-red-500';
        const width = strength === 'Strong' ? '100%' : strength === 'Medium' ? '66%' : '33%';
        
        return (
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className={`${color} h-1.5 rounded-full`} style={{ width }}></div>
            </div>
        );
    }
    
    const partnerRoles = Object.values(UserRole).filter(r => ![UserRole.Patient, UserRole.Admin].includes(r as UserRole));
    const inputClasses = "mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
            <div className="p-8 bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="text-center mb-6">
                    <h1 className="text-4xl font-bold text-akoma-blue">akoma</h1>
                    <p className="text-akoma-grey">{isSignUp ? t.auth.getStarted : t.auth.signInToYourAccount}</p>
                </div>
                
                {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md mb-4 text-sm">{error}</div>}
                {successMessage && <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md mb-4 text-sm">{successMessage}</div>}

                <form onSubmit={handleFormSubmit} className="space-y-4">
                    {isSignUp && (
                         <>
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark">{t.auth.fullName}</label>
                                <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} required className={inputClasses} />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-akoma-dark">{t.auth.selectRole}</label>
                                <select value={role} onChange={e => setRole(e.target.value as UserRole)} className={inputClasses}>
                                    <option value={UserRole.Patient}>I am a Patient</option>
                                    <optgroup label="Partners & Professionals">
                                        {partnerRoles.map(r => <option key={r} value={r}>{r}</option>)}
                                    </optgroup>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark">{t.auth.selectCountry}</label>
                                <select value={country} onChange={e => setCountry(e.target.value)} className={inputClasses}>
                                    {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
                                </select>
                            </div>
                         </>
                    )}

                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{isSignUp ? t.auth.email : t.auth.signInIdentifier}</label>
                        <input type="text" value={email} onChange={e => setEmail(e.target.value)} required className={inputClasses} />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.auth.password}</label>
                        <div className="relative">
                            <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required className={inputClasses} />
                            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5 text-gray-300">
                               {showPassword ? 'Hide' : 'Show'}
                            </button>
                        </div>
                        {renderPasswordStrength()}
                    </div>
                    
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-akoma-blue hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {isLoading ? <Spinner size="sm" /> : (isSignUp ? t.auth.createAccount : t.auth.signIn)}
                    </button>
                </form>
                <div className="mt-6 text-center text-sm">
                    <button onClick={() => { setIsSignUp(!isSignUp); setError(''); setSuccessMessage(''); }} className="font-medium text-akoma-blue hover:text-blue-700">
                        {isSignUp ? t.auth.alreadyHaveAccount : t.auth.dontHaveAccount} {isSignUp ? t.auth.signIn : t.auth.signUp}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Login;