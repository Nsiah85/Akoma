import React, { useEffect, useState } from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import MobileNav from './components/MobileNav';
import { UserRole } from './types';
import PatientOnboarding from './components/onboarding/PatientOnboarding';
import ForcePasswordChange from './components/ForcePasswordChange';
import ToastContainer from './components/ui/ToastContainer';
import ConfirmationModal from './components/ui/ConfirmationModal';

const AppContent: React.FC = () => {
  const { user, isOnboarding, isForcePasswordChange } = useApp();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const showMobileNav = user && !isOnboarding && user.role !== UserRole.Admin && isMobile;

  const renderContent = () => {
    if (isForcePasswordChange) {
      return <ForcePasswordChange />;
    }
    if (user) {
      if (isOnboarding && user.role === UserRole.Patient) {
        return <PatientOnboarding />;
      }
      return <Dashboard />;
    }
    return <Login />;
  }

  return (
    <div className="min-h-screen font-sans text-akoma-dark">
      <ToastContainer />
      <ConfirmationModal />
      <div className={showMobileNav ? "pb-16" : ""}>
        {renderContent()}
      </div>
      {showMobileNav && <MobileNav />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;