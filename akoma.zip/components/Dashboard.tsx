
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { UserRole } from '../types';

// Import all the hubs
import PatientHub from './hubs/PatientHub';
import DoctorHub from './hubs/DoctorHub';
import AdminHub from './hubs/AdminHub';
import NurseHub from './hubs/NurseHub';
// Fix: Corrected import path casing to resolve module ambiguity.
import LabTechHub from './hubs/LabTechHub';
import PharmacistHub from './hubs/PharmacistHub';
import InsurerHub from './hubs/InsurerHub';
import LawyerHub from './hubs/LawyerHub';
import VendorHub from './hubs/VendorHub';
import HealthcareFacilityHub from './hubs/HealthcareFacilityHub';
import Header from './Header';
import AkomaAIAssistant from './AkomaAIAssistant';
import Cart from './Cart';

const Dashboard: React.FC = () => {
    const { user, isCartOpen } = useApp();
    const [isAdminSidebarOpen, setIsAdminSidebarOpen] = useState(false);

    const renderDashboard = () => {
        if (!user) {
            return <div className="text-center p-8">Error: No user data found.</div>;
        }
        
        switch (user.role) {
            case UserRole.Patient:
                return <PatientHub />;
            case UserRole.Doctor:
                return <DoctorHub />;
            case UserRole.Admin:
                 return <AdminHub isSidebarOpen={isAdminSidebarOpen} onSidebarClose={() => setIsAdminSidebarOpen(false)} />;
            case UserRole.Nurse:
                return <NurseHub />;
            case UserRole.LabTech:
                return <LabTechHub />;
            case UserRole.Pharmacist:
                return <PharmacistHub />;
            case UserRole.Insurer:
                return <InsurerHub />;
            case UserRole.Lawyer:
                return <LawyerHub />;
            case UserRole.Vendor:
                return <VendorHub />;
            case UserRole.FacilityAdmin:
                return <HealthcareFacilityHub />;
            default:
                return <div className="text-center p-8">No dashboard available for this role.</div>;
        }
    };
    
    return (
        <div className="bg-gray-100 min-h-screen">
            <Header onToggleSidebar={() => setIsAdminSidebarOpen(prev => !prev)} />
            <main className="p-4 md:p-6">
                {renderDashboard()}
            </main>
            {user?.role === UserRole.Patient && <AkomaAIAssistant />}
            {isCartOpen && <Cart />}
        </div>
    );
};

export default Dashboard;