import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { EmergencyContact } from '../../types';
import { HeartIcon } from '../icons/HeartIcon';

const ProgressBar: React.FC<{ currentStep: number; totalSteps: number; stepLabels: string[] }> = ({ currentStep, totalSteps, stepLabels }) => (
    <div className="flex items-center justify-between mb-8">
        {stepLabels.map((label, index) => {
            const step = index + 1;
            const isCompleted = currentStep > step;
            const isActive = currentStep === step;
            return (
                <React.Fragment key={step}>
                    <div className="flex flex-col items-center text-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                            isCompleted ? 'bg-akoma-green text-white' : isActive ? 'bg-akoma-blue text-white' : 'bg-gray-200 text-akoma-grey'
                        }`}>
                            {isCompleted ? '✓' : step}
                        </div>
                        <p className={`mt-2 text-xs font-semibold ${isActive ? 'text-akoma-blue' : 'text-akoma-grey'}`}>{label}</p>
                    </div>
                    {step < totalSteps && <div className={`flex-1 h-1 mx-2 transition-colors ${isCompleted ? 'bg-akoma-green' : 'bg-gray-200'}`}></div>}
                </React.Fragment>
            );
        })}
    </div>
);

const PatientOnboarding: React.FC = () => {
    const { user, completeOnboarding } = useApp();
    const [step, setStep] = useState(1);
    const [allergies, setAllergies] = useState('');
    const [conditions, setConditions] = useState('');
    const [medications, setMedications] = useState([{ name: '', dosage: '' }]);
    const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([{ name: '', number: '', relationship: '' }]);

    const totalSteps = 4;
    const stepLabels = ['Welcome', 'Medical History', 'Medications', 'Emergency Contacts'];
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";


    const handleNext = () => setStep(prev => Math.min(prev + 1, totalSteps + 1));
    const handleBack = () => setStep(prev => Math.max(prev - 1, 1));
    
    const handleSubmit = () => {
        completeOnboarding({
            allergies,
            conditions,
            medications: medications.filter(m => m.name.trim() && m.dosage.trim()),
            emergencyContacts: emergencyContacts.filter(c => c.name.trim() && c.number.trim() && c.relationship?.trim())
        });
    }

    const updateMedication = (index: number, field: 'name' | 'dosage', value: string) => {
        const newMeds = [...medications];
        newMeds[index][field] = value;
        setMedications(newMeds);
    };
    const addMedication = () => setMedications([...medications, { name: '', dosage: '' }]);
    const removeMedication = (index: number) => setMedications(medications.filter((_, i) => i !== index));

    const updateContact = (index: number, field: keyof EmergencyContact, value: string) => {
        const newContacts = [...emergencyContacts];
        newContacts[index][field] = value;
        setEmergencyContacts(newContacts);
    };
    const addContact = () => setEmergencyContacts([...emergencyContacts, { name: '', number: '', relationship: '' }]);
    const removeContact = (index: number) => setEmergencyContacts(emergencyContacts.filter((_, i) => i !== index));


    const renderStepContent = () => {
        switch (step) {
            case 1:
                return (
                    <div className="text-center animate-fade-in-up">
                        <HeartIcon className="w-16 h-16 text-akoma-blue mx-auto mb-4" />
                        <h2 className="text-3xl font-bold text-akoma-dark">Welcome to akoma, {user?.name.split(' ')[0]}!</h2>
                        <p className="mt-2 text-akoma-grey">Let's get your health profile set up. This will only take a couple of minutes.</p>
                    </div>
                );
            case 2:
                return (
                    <div className="animate-fade-in-up">
                        <h3 className="text-xl font-bold text-akoma-dark mb-4">Medical History</h3>
                        <p className="text-sm text-akoma-grey mb-4">Please list any known allergies and chronic conditions. If none, you can leave these fields blank.</p>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">Allergies (e.g., Peanuts, Penicillin)</label>
                                <textarea value={allergies} onChange={e => setAllergies(e.target.value)} rows={3} className={inputClasses} />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">Chronic Conditions (e.g., Hypertension, Asthma)</label>
                                <textarea value={conditions} onChange={e => setConditions(e.target.value)} rows={3} className={inputClasses} />
                            </div>
                        </div>
                    </div>
                );
            case 3:
                return (
                    <div className="animate-fade-in-up">
                        <h3 className="text-xl font-bold text-akoma-dark mb-4">Current Medications</h3>
                        <p className="text-sm text-akoma-grey mb-4">List any medications you are currently taking regularly.</p>
                        <div className="space-y-3">
                            {medications.map((med, index) => (
                                <div key={index} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-md">
                                    <input type="text" placeholder="Medication Name" value={med.name} onChange={e => updateMedication(index, 'name', e.target.value)} className={`${inputClasses} w-1/2`} />
                                    <input type="text" placeholder="Dosage (e.g., 10mg)" value={med.dosage} onChange={e => updateMedication(index, 'dosage', e.target.value)} className={`${inputClasses} w-1/2`} />
                                    {medications.length > 1 && <button onClick={() => removeMedication(index)} className="p-2 text-gray-400 hover:text-red-600 rounded-full">&times;</button>}
                                </div>
                            ))}
                        </div>
                        <button onClick={addMedication} className="mt-2 text-sm font-semibold text-akoma-blue hover:underline">+ Add another medication</button>
                    </div>
                );
             case 4:
                return (
                     <div className="animate-fade-in-up">
                        <h3 className="text-xl font-bold text-akoma-dark mb-4">Emergency Contacts</h3>
                        <p className="text-sm text-akoma-grey mb-4">Add at least one person we can contact in an emergency.</p>
                        <div className="space-y-3">
                            {emergencyContacts.map((contact, index) => (
                                <div key={index} className="p-3 bg-gray-50 rounded-md border grid grid-cols-1 md:grid-cols-3 gap-2">
                                    <input type="text" placeholder="Full Name" value={contact.name} onChange={e => updateContact(index, 'name', e.target.value)} className={inputClasses} />
                                    <input type="text" placeholder="Phone Number" value={contact.number} onChange={e => updateContact(index, 'number', e.target.value)} className={inputClasses} />
                                    <div className="flex items-center space-x-2">
                                        <input type="text" placeholder="Relationship" value={contact.relationship} onChange={e => updateContact(index, 'relationship', e.target.value)} className={`${inputClasses} flex-1`} />
                                        {emergencyContacts.length > 1 && <button onClick={() => removeContact(index)} className="p-2 text-gray-400 hover:text-red-600 rounded-full">&times;</button>}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <button onClick={addContact} className="mt-2 text-sm font-semibold text-akoma-blue hover:underline">+ Add another contact</button>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="fixed inset-0 bg-gray-100 z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-2xl bg-white rounded-lg shadow-xl p-6 md:p-10 flex flex-col" style={{ minHeight: '450px' }}>
                <ProgressBar currentStep={step} totalSteps={totalSteps} stepLabels={stepLabels} />
                <div className="flex-grow flex flex-col justify-center">
                    {renderStepContent()}
                </div>
                <div className="mt-8 pt-4 border-t flex justify-between items-center">
                    <div>
                        {step > 1 && (
                            <button onClick={handleBack} className="px-6 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                                Back
                            </button>
                        )}
                    </div>
                    <div>
                         {step < totalSteps && (
                            <button onClick={handleNext} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                                Next
                            </button>
                        )}
                        {step === totalSteps && (
                            <button onClick={handleSubmit} className="px-6 py-2 text-sm font-medium text-white bg-akoma-green rounded-md hover:bg-green-700">
                                Finish Setup
                            </button>
                        )}
                         {step === 1 && (
                            <button onClick={handleNext} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                                Let's Go
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PatientOnboarding;