import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { getAIResponse, fileToGenerativePart } from '../services/geminiService';

const PaperAirplaneIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>;
const PaperClipIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.122 2.122l7.81-7.81" /></svg>;
const XMarkIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;


const AkomaAIAssistant: React.FC = () => {
    const { user } = useApp();
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<{ id: number; text: string; sender: 'user' | 'ai' }[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [imageFile, setImageFile] = useState<File | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);
    
    const sendMessage = async (messageText: string, attachedFile?: File) => {
        if (!messageText.trim() && !attachedFile) return;

        setInput('');
        setMessages(prev => [...prev, { id: Date.now(), text: messageText, sender: 'user' }]);
        setIsLoading(true);

        try {
            let imagePart;
            const fileToSend = attachedFile || imageFile;
            if (fileToSend) {
                imagePart = await fileToGenerativePart(fileToSend);
                setImageFile(null);
            }
            const aiResponse = await getAIResponse(messageText, imagePart);
            setMessages(prev => [...prev, { id: Date.now() + 1, text: aiResponse, sender: 'ai' }]);
        } catch (error) {
            setMessages(prev => [...prev, { id: Date.now() + 1, text: "Sorry, I'm having trouble connecting.", sender: 'ai' }]);
        } finally {
            setIsLoading(false);
        }
    }

    const handleSend = () => {
        sendMessage(input, imageFile);
    };
    
    const handlePromptStarter = (prompt: string) => {
        sendMessage(prompt);
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const file = e.target.files[0];
            setImageFile(file);
            // Automatically send if a file is selected, perhaps with a default prompt
            sendMessage(`Please analyze this file: ${file.name}`, file);
        }
    };
    
    const PromptStarters = () => (
        <div className="p-2 border-t">
            <p className="text-xs text-center text-akoma-grey">Or try one of these:</p>
            <div className="flex flex-wrap gap-2 justify-center mt-2">
                <button onClick={() => handlePromptStarter('Explain my lab results')} className="text-xs bg-gray-200 hover:bg-gray-300 text-akoma-dark font-semibold py-1 px-2 rounded-full">Explain lab results</button>
                <button onClick={() => handlePromptStarter('What is Lisinopril for?')} className="text-xs bg-gray-200 hover:bg-gray-300 text-akoma-dark font-semibold py-1 px-2 rounded-full">What is Lisinopril for?</button>
                 <button onClick={() => handlePromptStarter('Suggest a healthy meal')} className="text-xs bg-gray-200 hover:bg-gray-300 text-akoma-dark font-semibold py-1 px-2 rounded-full">Suggest a healthy meal</button>
            </div>
        </div>
    );

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-20 right-4 md:bottom-6 md:right-6 bg-akoma-blue text-white w-14 h-14 md:w-16 md:h-16 rounded-full shadow-lg flex items-center justify-center transform hover:scale-110 transition-transform z-30"
                aria-label="Open AI Assistant"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>
            </button>
        );
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:z-auto">
            <div className="fixed bottom-0 right-0 w-full max-w-md h-[80vh] md:bottom-6 md:right-6 md:w-96 md:h-[500px] bg-white rounded-t-lg md:rounded-lg shadow-2xl flex flex-col z-50 animate-slide-in-up md:animate-slide-in-right">
                <header className="p-4 bg-white text-akoma-dark border-b border-gray-200 flex justify-between items-center flex-shrink-0">
                    <h3 className="font-bold text-akoma-blue">akoma AI Assistant</h3>
                    <button onClick={() => setIsOpen(false)}><XMarkIcon className="w-6 h-6" /></button>
                </header>
                <main className="flex-1 p-4 overflow-y-auto bg-gray-50">
                    <div className="space-y-4">
                        {messages.length === 0 && !isLoading && (
                            <div className="animate-fade-in-fast flex justify-start">
                                <div className="max-w-xs px-4 py-2 rounded-lg bg-gray-200 text-akoma-dark">
                                    Hello! I'm your Akoma AI assistant. How can I help you today? You can ask me to explain a lab result, describe a medication, or upload a medical document for analysis.
                                </div>
                            </div>
                        )}
                        {messages.map(msg => (
                            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-xs px-4 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-akoma-blue text-white' : 'bg-gray-200 text-akoma-dark'}`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                        {isLoading && (
                            <div className="flex justify-start">
                                <div className="max-w-xs px-4 py-2 rounded-lg bg-gray-200 text-akoma-dark">
                                    <div className="flex items-center space-x-2">
                                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
                                        <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                </main>
                {messages.length === 0 && !isLoading && <PromptStarters />}
                <footer className="p-2 border-t flex items-center space-x-2 flex-shrink-0">
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*,application/pdf" />
                    <button onClick={() => fileInputRef.current?.click()} className="p-2 text-gray-500 hover:text-akoma-blue rounded-full">
                        <PaperClipIcon className="w-6 h-6" />
                    </button>
                    <div className="flex-1 relative">
                        <input
                            type="text"
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyPress={e => e.key === 'Enter' && handleSend()}
                            placeholder="Ask akoma anything..."
                            className="w-full p-2 pr-10 border rounded-full bg-gray-100"
                        />
                        {imageFile && <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs bg-gray-300 rounded-full px-2 py-0.5">{imageFile.name}</span>}
                    </div>
                    <button onClick={handleSend} disabled={isLoading} className="p-2 text-white bg-akoma-blue rounded-full disabled:bg-gray-400">
                        <PaperAirplaneIcon className="w-6 h-6" />
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default AkomaAIAssistant;
