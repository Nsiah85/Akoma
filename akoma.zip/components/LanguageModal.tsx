import React from 'react';
import { useApp } from '../contexts/AppContext';
import { LANGUAGES } from '../constants';

const LanguageModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { language, setLanguage, t } = useApp();

    const handleSelectLanguage = (langCode: string) => {
        setLanguage(langCode);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-end" onClick={onClose}>
            <div 
                className="w-full bg-white rounded-t-2xl shadow-lg p-4 animate-slide-in-up flex flex-col max-h-[80vh]"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4 flex-shrink-0"></div>
                <h3 className="text-lg font-bold text-center text-akoma-dark mb-4 flex-shrink-0">Select Language</h3>
                <ul className="space-y-2 overflow-y-auto">
                    {LANGUAGES.map(lang => (
                        <li key={lang.code}>
                            <button
                                onClick={() => handleSelectLanguage(lang.code)}
                                className={`w-full text-left p-3 rounded-lg font-semibold ${
                                    language === lang.code ? 'bg-akoma-light-blue text-akoma-blue' : 'hover:bg-gray-100'
                                }`}
                            >
                                {lang.name}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default LanguageModal;
