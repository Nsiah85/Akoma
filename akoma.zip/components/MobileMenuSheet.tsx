import React from 'react';
import { useApp } from '../contexts/AppContext';
import { GlobeIcon, CurrencyIcon } from './icons/InternationalIcons';

interface MenuItem {
    id: string;
    label: string;
    icon: React.ReactNode;
    action?: () => void;
}

interface MobileMenuSheetProps {
    items: MenuItem[];
    onClose: () => void;
    onOpenLanguage: () => void;
    onOpenCurrency: () => void;
}

const MobileMenuSheet: React.FC<MobileMenuSheetProps> = ({ items, onClose, onOpenLanguage, onOpenCurrency }) => {
    const { setActiveHubTab, t } = useApp();

    const menuItems = [
        ...items,
        { id: 'language', label: t.common.language, icon: <GlobeIcon className="w-6 h-6" />, action: onOpenLanguage },
        { id: 'currency', label: t.common.currency, icon: <CurrencyIcon className="w-6 h-6" />, action: onOpenCurrency },
    ];

    const handleItemClick = (item: MenuItem) => {
        onClose(); // Close this sheet first
        if (item.action) {
            // Use a small timeout to let the close animation start
            setTimeout(() => item.action!(), 150);
        } else {
            setActiveHubTab(item.id);
        }
    }

    return (
        <>
            <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={onClose}></div>
            <div
                className="fixed bottom-0 left-0 w-full bg-white rounded-t-2xl shadow-lg p-4 z-50 animate-slide-in-up"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4"></div>
                <h3 className="text-lg font-bold text-center text-akoma-dark mb-4">{t.common.more}</h3>
                <ul className="space-y-1">
                    {menuItems.map(item => (
                        <li key={item.id}>
                            <button onClick={() => handleItemClick(item)} className="w-full flex items-center space-x-4 p-3 rounded-lg font-semibold text-akoma-dark hover:bg-gray-100">
                                {item.icon}
                                <span>{item.label}</span>
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </>
    );
};

export default MobileMenuSheet;
