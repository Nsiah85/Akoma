
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Receipt } from '../types';

const CheckoutModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { user, cart, currency, formatCurrency, clearCart, addNotification, addToast } = useApp();
    const [step, setStep] = useState<'method' | 'details' | 'processing' | 'success'>('method');
    const [paymentMethod, setPaymentMethod] = useState<'card' | 'momo' | null>(null);
    const [receipt, setReceipt] = useState<Receipt | null>(null);

    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

    const handlePayment = () => {
        setStep('processing');
        setTimeout(() => {
            const newReceipt: Receipt = {
                id: `order_${Date.now()}`,
                date: new Date().toISOString(),
                items: [...cart],
                total: subtotal,
                currency: currency,
            };
            setReceipt(newReceipt);
            clearCart();
            // Fix: Replaced string argument with an object to match the function's expected type.
            addNotification({ title: 'Order Placed', message: 'Your order has been placed successfully!', type: 'system' });
            addToast({ message: 'Your payment was successful!', type: 'success' });
            setStep('success');
        }, 2000);
    };

    const renderMethodSelection = () => (
        <>
            <main className="p-6">
                <h4 className="font-semibold text-akoma-dark mb-4">Select a payment method</h4>
                <div className="space-y-3">
                    <button onClick={() => { setPaymentMethod('card'); setStep('details'); }} className="w-full p-4 border rounded-lg text-left hover:bg-gray-50 flex items-center">💳 Credit/Debit Card</button>
                    <button onClick={() => { setPaymentMethod('momo'); setStep('details'); }} className="w-full p-4 border rounded-lg text-left hover:bg-gray-50 flex items-center">📱 Mobile Money</button>
                </div>
            </main>
            <footer className="px-6 py-4 bg-gray-50 flex justify-between items-center">
                <span className="font-bold text-lg">Total: {formatCurrency(subtotal)}</span>
                <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">Cancel</button>
            </footer>
        </>
    );

    const renderDetailsForm = () => {
        const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
        return (
            <>
                <main className="p-6 space-y-4">
                    <button onClick={() => setStep('method')} className="text-sm text-akoma-blue mb-2">&larr; Back to methods</button>
                    {paymentMethod === 'card' && (
                        <>
                            <h4 className="font-semibold text-akoma-dark">Enter Card Details</h4>
                            <div><label className="text-xs text-akoma-dark">Card Number</label><input type="text" placeholder="**** **** **** ****" className={inputClasses} required /></div>
                            <div className="flex space-x-4">
                                <div className="w-1/2"><label className="text-xs text-akoma-dark">Expiry Date</label><input type="text" placeholder="MM/YY" className={inputClasses} required /></div>
                                <div className="w-1/2"><label className="text-xs text-akoma-dark">CVV</label><input type="text" placeholder="***" className={inputClasses} required /></div>
                            </div>
                        </>
                    )}
                    {paymentMethod === 'momo' && (
                        <>
                            <h4 className="font-semibold text-akoma-dark">Enter Mobile Money Details</h4>
                            <div>
                                <label className="text-xs text-akoma-dark">Provider</label>
                                <select className={inputClasses}>
                                    <option>MTN Mobile Money</option>
                                    <option>Vodafone Cash</option>
                                    <option>AirtelTigo Money</option>
                                </select>
                            </div>
                            <div><label className="text-xs text-akoma-dark">Phone Number</label><input type="tel" placeholder="e.g. 024 123 4567" className={inputClasses} required /></div>
                        </>
                    )}
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-between items-center">
                    <span className="font-bold text-lg">Total: {formatCurrency(subtotal)}</span>
                    <button onClick={handlePayment} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Pay Now</button>
                </footer>
            </>
        )
    };
    
    const renderProcessing = () => (
        <main className="p-12 flex flex-col items-center justify-center text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-akoma-blue mb-4"></div>
            <h4 className="font-semibold text-akoma-dark">Processing your payment...</h4>
            <p className="text-sm text-akoma-grey">Please do not close this window.</p>
        </main>
    );

    const renderSuccess = () => (
         <main className="p-6 text-center">
            <div className="w-16 h-16 bg-akoma-green rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                <svg xmlns="http://www.w.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            </div>
            <h3 className="text-2xl font-bold text-akoma-dark">Thank You, {user?.name.split(' ')[0]}!</h3>
            <p className="text-akoma-grey mt-1">Your order has been placed successfully.</p>
            {receipt && (
                <div className="mt-6 p-4 bg-gray-50 border rounded-lg text-left text-sm">
                    <h5 className="font-bold mb-2">Order Summary ({receipt.id})</h5>
                    <ul className="space-y-1 mb-2">
                        {receipt.items.map(item => (
                            <li key={item.product.id} className="flex justify-between">
                                <span>{item.product.name} x{item.quantity}</span>
                                <span>{formatCurrency(item.product.price * item.quantity, item.product.baseCurrency)}</span>
                            </li>
                        ))}
                    </ul>
                    <div className="border-t pt-2 font-bold flex justify-between">
                        <span>Total Paid</span>
                        <span>{formatCurrency(receipt.total)}</span>
                    </div>
                </div>
            )}
             <button onClick={onClose} className="mt-6 w-full px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                Close
            </button>
        </main>
    );

    const renderContent = () => {
        switch(step) {
            case 'method': return renderMethodSelection();
            case 'details': return renderDetailsForm();
            case 'processing': return renderProcessing();
            case 'success': return renderSuccess();
        }
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b flex justify-between items-center">
                    <h3 className="text-xl font-bold text-akoma-blue">Checkout</h3>
                     <button onClick={onClose} className="p-1 text-akoma-grey hover:text-akoma-dark text-2xl leading-none">&times;</button>
                </header>
                {renderContent()}
            </div>
        </div>
    );
};

export default CheckoutModal;
