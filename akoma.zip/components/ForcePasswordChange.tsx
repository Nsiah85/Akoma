import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { checkPasswordStrength } from '../utils/validation';

const ForcePasswordChange: React.FC = () => {
    const { forcePasswordUpdate, logout } = useApp();
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const passwordStrength = checkPasswordStrength(newPassword);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (newPassword !== confirmPassword) {
            setError("Passwords do not match.");
            return;
        }
        if (passwordStrength.strength === 'Weak') {
            setError("New password is too weak.");
            return;
        }
        setIsLoading(true);
        const result = forcePasswordUpdate(newPassword);
        if (!result.success) {
            setError(result.message);
            setIsLoading(false);
        }
        // On success, the app context will handle the state change
    };
    
    const renderPasswordStrength = () => {
        if (!newPassword) return null;
        const { strength } = passwordStrength;
        const color = strength === 'Strong' ? 'bg-akoma-green' : strength === 'Medium' ? 'bg-yellow-500' : 'bg-red-500';
        const width = strength === 'Strong' ? '100%' : strength === 'Medium' ? '66%' : '33%';
        
        return (
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                <div className={`${color} h-1.5 rounded-full`} style={{ width }}></div>
            </div>
        );
    }

    const inputClasses = "mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
        <div className="fixed inset-0 bg-gray-100 z-50 flex items-center justify-center p-4">
            <div className="p-8 bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="text-center mb-6">
                    <h1 className="text-3xl font-bold text-akoma-dark">Update Your Password</h1>
                    <p className="text-akoma-grey mt-2">For your security, please create a new password to continue.</p>
                </div>

                {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md mb-4 text-sm">{error}</div>}

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">New Password</label>
                        <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required className={inputClasses} />
                        {renderPasswordStrength()}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Confirm New Password</label>
                        <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className={inputClasses} />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-akoma-blue hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {isLoading ? 'Updating...' : 'Set New Password and Sign In'}
                    </button>
                </form>
                <div className="mt-6 text-center text-sm">
                    <button onClick={logout} className="font-medium text-akoma-grey hover:text-akoma-dark">
                        Cancel and Log Out
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ForcePasswordChange;
