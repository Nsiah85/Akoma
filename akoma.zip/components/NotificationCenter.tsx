import React from 'react';
import { useApp } from '../contexts/AppContext';
import { BellIcon } from './icons/BellIcon';
import { PayoutNotificationIcon, SystemNotificationIcon, UserNotificationIcon } from './icons/NotificationIcons';
import { Notification } from '../types';

const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
        case 'user':
            return <UserNotificationIcon className="w-6 h-6 text-akoma-blue" />;
        case 'payout':
            return <PayoutNotificationIcon className="w-6 h-6 text-akoma-green" />;
        case 'system':
        default:
            return <SystemNotificationIcon className="w-6 h-6 text-akoma-grey" />;
    }
}

const formatTimeAgo = (isoString: string) => {
    const date = new Date(isoString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return "just now";
};


const NotificationCenter: React.FC = () => {
    const { notifications, markNotificationsAsRead } = useApp();

    return (
        <div className="absolute right-0 md:right-4 mt-2 w-80 bg-white rounded-lg shadow-xl border z-30 animate-fade-in-fast">
            <div className="p-4 border-b flex justify-between items-center">
                <h4 className="font-bold text-akoma-dark">Notifications</h4>
                <button onClick={markNotificationsAsRead} className="text-xs text-akoma-blue font-semibold hover:underline">Mark all as read</button>
            </div>
            <div className="max-h-80 overflow-y-auto">
                {notifications.length > 0 ? (
                    <ul>
                        {notifications.map(notification => (
                            <li key={notification.id} className={`flex items-start space-x-3 p-4 border-b last:border-b-0 hover:bg-gray-50 ${!notification.read ? 'bg-akoma-light-blue' : ''}`}>
                                <div className="flex-shrink-0 mt-1">
                                    {getNotificationIcon(notification.type)}
                                </div>
                                <div className="flex-1">
                                    <p className="text-sm font-semibold text-akoma-dark">{notification.title}</p>
                                    <p className="text-sm text-akoma-grey">{notification.message}</p>
                                    <p className="text-xs text-akoma-grey mt-1">{formatTimeAgo(notification.date)}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="p-8 text-center text-akoma-grey">
                         <BellIcon className="w-10 h-10 mx-auto mb-2 text-gray-300"/>
                        <p>No new notifications.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default NotificationCenter;