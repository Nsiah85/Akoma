import React, { useState, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import { BellIcon } from './icons/BellIcon';
import { InboxIcon } from './icons/InboxIcon';
import NotificationCenter from './NotificationCenter';
import Inbox from './Inbox';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';
import { UserRole } from '../types';
import { EmergencyInfo } from './EmergencyInfo';
import { useOutsideClick } from '../hooks/useOutsideClick';
import { GlobeIcon, CurrencyIcon } from './icons/InternationalIcons';
import LanguageModal from './LanguageModal';
import CurrencyModal from './CurrencyModal';
import { SignOutIcon } from './icons/SignOutIcon';

type OpenPopover = 'notifications' | 'inbox' | 'profile' | null;

const Header: React.FC<{ onToggleSidebar?: () => void }> = ({ onToggleSidebar }) => {
    const { user, notifications, conversations, cart, toggleCart, logout, t } = useApp();
    
    const [openPopover, setOpenPopover] = useState<OpenPopover>(null);
    const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
    const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);

    const notificationsRef = useOutsideClick(() => { if (openPopover === 'notifications') setOpenPopover(null); });
    const inboxRef = useOutsideClick(() => { if (openPopover === 'inbox') setOpenPopover(null); });
    const profileRef = useOutsideClick(() => { if (openPopover === 'profile') setOpenPopover(null); });

    const unreadNotifications = notifications.filter(n => !n.read).length;
    const unreadMessages = conversations.reduce((acc, convo) => {
        if (!user) return acc;
        return acc + convo.messages.filter(m => !m.isReadByRecipient && m.senderId !== user.id).length;
    }, 0);

    const togglePopover = (popover: OpenPopover) => {
        setOpenPopover(prev => (prev === popover ? null : popover));
    };

    return (
        <>
            <header className="bg-white shadow-sm sticky top-0 z-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-16">
                        <div className="flex items-center">
                            {user?.role === UserRole.Admin && (
                                <button onClick={onToggleSidebar} className="lg:hidden mr-4 p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100">
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                                </button>
                            )}
                            <h1 className="text-2xl font-bold text-akoma-blue">akoma</h1>
                        </div>
                        <div className="flex items-center space-x-2 md:space-x-4">
                            <EmergencyInfo />
                             {/* Language & Currency for Desktop */}
                            <div className="hidden md:flex items-center space-x-2">
                                <button onClick={() => setIsLanguageModalOpen(true)} title="Change Language" className="p-2 text-gray-500 hover:text-akoma-blue rounded-full">
                                    <GlobeIcon className="w-6 h-6" />
                                </button>
                                <button onClick={() => setIsCurrencyModalOpen(true)} title="Change Currency" className="p-2 text-gray-500 hover:text-akoma-blue rounded-full">
                                    <CurrencyIcon className="w-6 h-6" />
                                </button>
                            </div>
                            <div className="relative" ref={notificationsRef}>
                                <button onClick={() => togglePopover('notifications')} className="p-2 text-gray-500 hover:text-akoma-blue rounded-full relative">
                                    <BellIcon className="w-6 h-6" />
                                    {unreadNotifications > 0 && <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />}
                                </button>
                                {openPopover === 'notifications' && <NotificationCenter />}
                            </div>
                            <div className="relative" ref={inboxRef}>
                                <button onClick={() => togglePopover('inbox')} className="p-2 text-gray-500 hover:text-akoma-blue rounded-full relative">
                                    <InboxIcon className="w-6 h-6" />
                                    {unreadMessages > 0 && <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />}
                                </button>
                                {openPopover === 'inbox' && <Inbox />}
                            </div>
                            {user?.role !== UserRole.Admin && (
                                <div className="relative">
                                    <button onClick={toggleCart} className="p-2 text-gray-500 hover:text-akoma-blue rounded-full relative">
                                        <ShoppingCartIcon className="w-6 h-6" />
                                        {cart.length > 0 && <span className="absolute -top-1 -right-1 flex items-center justify-center h-5 w-5 text-xs rounded-full bg-akoma-blue text-white">{cart.reduce((sum, item) => sum + item.quantity, 0)}</span>}
                                    </button>
                                </div>
                            )}
                            <div className="relative" ref={profileRef}>
                                <button onClick={() => togglePopover('profile')} className="flex items-center space-x-2">
                                    {user?.profileImageUrl ? (
                                        <img src={user.profileImageUrl} alt="Profile" className="w-8 h-8 rounded-full object-cover" />
                                    ) : (
                                        <div className="w-8 h-8 rounded-full bg-akoma-light-blue text-akoma-blue flex items-center justify-center text-sm font-bold">
                                            {user?.name.charAt(0)}
                                        </div>
                                    )}
                                </button>
                                {openPopover === 'profile' && (
                                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-md shadow-lg border z-30 animate-fade-in-fast">
                                        <div className="p-4 border-b flex items-center space-x-3">
                                            {user?.profileImageUrl ? (
                                                <img src={user.profileImageUrl} alt="Profile" className="w-12 h-12 rounded-full object-cover" />
                                            ) : (
                                                <div className="w-12 h-12 rounded-full bg-akoma-light-blue text-akoma-blue flex items-center justify-center text-xl font-bold flex-shrink-0">
                                                    {user?.name.charAt(0)}
                                                </div>
                                            )}
                                            <div className="overflow-hidden">
                                                <p className="font-bold text-akoma-dark truncate" title={user?.name}>{user?.name}</p>
                                                <p className="text-xs text-akoma-grey truncate" title={user?.email}>{user?.email}</p>
                                                <p className="text-xs text-akoma-grey font-mono truncate">{user?.akomaId}</p>
                                            </div>
                                        </div>
                                        <a href="#" onClick={(e) => { e.preventDefault(); logout(); }} className="flex items-center space-x-2 w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-100">
                                            <SignOutIcon className="w-5 h-5 text-akoma-grey"/>
                                            <span>{t.common.signOut}</span>
                                        </a>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            {isLanguageModalOpen && <LanguageModal onClose={() => setIsLanguageModalOpen(false)} />}
            {isCurrencyModalOpen && <CurrencyModal onClose={() => setIsCurrencyModalOpen(false)} />}
        </>
    );
};

export default Header;