import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import CheckoutModal from './CheckoutModal';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';
import { TrashIcon } from './icons/TrashIcon';
import { useOutsideClick } from '../hooks/useOutsideClick';

const Cart: React.FC = () => {
    const { cart, isCartOpen, toggleCart, formatCurrency, setActiveHubTab, updateCartItemQuantity, removeFromCart } = useApp();
    const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

    const cartRef = useOutsideClick(() => {
        if (isCartOpen && !isCheckoutOpen) {
            toggleCart();
        }
    });

    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

    const handleShopNow = () => {
        toggleCart();
        setActiveHubTab('wellness-store');
    }

    const handleCloseCheckout = () => {
        setIsCheckoutOpen(false);
        // If cart is empty after checkout, close the whole cart panel
        if (cart.length === 0) {
            toggleCart();
        }
    }

    return (
        <>
            <div className="fixed inset-0 bg-black bg-opacity-50 z-40"></div>
            <div ref={cartRef} className="fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-lg z-50 flex flex-col animate-slide-in-right">
                <header className="p-4 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-akoma-dark">My Cart</h2>
                    <button onClick={toggleCart} className="p-2 text-akoma-grey hover:text-akoma-dark">
                        &times;
                    </button>
                </header>
                <div className="flex-1 overflow-y-auto p-4">
                    {cart.length > 0 ? (
                        <ul className="space-y-4">
                            {cart.map(item => (
                                <li key={item.product.id} className="flex items-center space-x-4">
                                    <img src={item.product.imageUrl} alt={item.product.name} className="w-16 h-16 object-cover rounded-md" />
                                    <div className="flex-1">
                                        <p className="font-semibold text-sm">{item.product.name}</p>
                                        <p className="text-xs text-akoma-grey">{formatCurrency(item.product.price, item.product.baseCurrency)}</p>
                                        <div className="flex items-center space-x-2 mt-1">
                                            <button onClick={() => updateCartItemQuantity(item.product.id, item.quantity - 1)} className="w-6 h-6 border rounded-md text-akoma-grey">-</button>
                                            <span className="w-6 text-center">{item.quantity}</span>
                                            <button onClick={() => updateCartItemQuantity(item.product.id, item.quantity + 1)} className="w-6 h-6 border rounded-md text-akoma-grey">+</button>
                                        </div>
                                    </div>
                                    <button onClick={() => removeFromCart(item.product.id)} className="p-2 text-gray-400 hover:text-red-600">
                                        <TrashIcon className="w-5 h-5"/>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <div className="text-center text-akoma-grey py-8 flex flex-col items-center">
                            <ShoppingCartIcon className="w-16 h-16 text-gray-300 mb-4" />
                            <p className="font-semibold text-lg">Your cart is empty.</p>
                            <p className="text-sm mb-4">Looks like you haven't added anything yet.</p>
                            <button
                                onClick={handleShopNow}
                                className="mt-4 px-6 py-2 bg-akoma-blue text-white rounded-md font-semibold hover:bg-blue-700"
                            >
                                Shop Now
                            </button>
                        </div>
                    )}
                </div>
                <footer className="p-4 border-t bg-gray-50">
                    <div className="flex justify-between font-bold text-lg mb-4">
                        <span>Subtotal</span>
                        <span>{formatCurrency(subtotal)}</span>
                    </div>
                    <button
                        onClick={() => setIsCheckoutOpen(true)}
                        disabled={cart.length === 0}
                        className="w-full bg-akoma-blue text-white py-3 rounded-md font-semibold hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        Proceed to Checkout
                    </button>
                </footer>
            </div>
            {isCheckoutOpen && <CheckoutModal onClose={handleCloseCheckout} />}
        </>
    );
};

export default Cart;