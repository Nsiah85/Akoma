import React from 'react';
import { CashIcon } from './CashIcon';
import { UsersIcon } from './UsersIcon';
import { BellIcon } from './BellIcon';

export const PayoutNotificationIcon: React.FC<{className?: string}> = ({className}) => <CashIcon className={className} />;
export const UserNotificationIcon: React.FC<{className?: string}> = ({className}) => <UsersIcon className={className} />;
// Fix: Removed trailing underscore causing a syntax error.
export const SystemNotificationIcon: React.FC<{className?: string}> = ({className}) => <BellIcon className={className} />