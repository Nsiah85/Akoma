import React, { useState } from 'react';
// Fix: Corrected imports for mock data from `constants.ts`.
import { MOCK_LAB_REQUESTS, MOCK_PATIENTS } from '../../constants';
// Fix: Corrected import from '../../contexts/AppContext'
import { useApp } from '../../contexts/AppContext';
// Fix: Corrected imports for types from `types.ts`.
import { LabResult } from '../../types';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
      <h3 className="text-xl font-bold text-akoma-blue mb-4">{title}</h3>
      {children}
    </div>
);

const UploadResultModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { t, addLabResult, addNotification } = useApp();
    const [testName, setTestName] = useState('');
    const [resultDetails, setResultDetails] = useState('');
    const [attachment, setAttachment] = useState<File | null>(null);
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    const handleSubmit = () => {
        if (!testName.trim() || !resultDetails.trim()) {
            alert('Please fill in all fields.');
            return;
        }
        const newResult: LabResult = {
            id: `lab_${new Date().getTime()}`,
            testName,
            date: new Date().toISOString().split('T')[0],
            scientificExplanation: resultDetails,
            attachmentName: attachment?.name,
            attachmentUrl: attachment ? URL.createObjectURL(attachment) : undefined
        };
        addLabResult(newResult);
        // Fix: Replaced string argument with an object to match the function's expected type.
        addNotification({ title: 'New Lab Result', message: `A new lab result for "${testName}" is available for ${MOCK_PATIENTS[0].name}.`, type: 'system' });
        alert(`Result for ${testName} submitted for ${MOCK_PATIENTS[0].name}`);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">{t.labTechHub.newResult}</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.labTechHub.selectPatient}</label>
                        <select className={`mt-1 block w-full p-2 border rounded-md bg-gray-700 text-gray-400 border-akoma-grey cursor-not-allowed`} disabled>
                            <option>{MOCK_PATIENTS[0].name}</option>
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.labTechHub.testName}</label>
                        <input type="text" value={testName} onChange={e => setTestName(e.target.value)} className={`mt-1 ${inputClasses}`} placeholder="e.g., Lipid Panel" required />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.labTechHub.resultDetails}</label>
                        <textarea rows={4} value={resultDetails} onChange={e => setResultDetails(e.target.value)} className={`mt-1 ${inputClasses}`} required></textarea>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.labTechHub.uploadFile}</label>
                        <input type="file" onChange={e => setAttachment(e.target.files?.[0] || null)} className="mt-1 block w-full text-sm text-akoma-grey file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-akoma-light-blue file:text-akoma-blue hover:file:bg-blue-200"/>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button type="button" onClick={handleSubmit} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.labTechHub.upload}</button>
                </footer>
            </div>
        </div>
    )
}

type Tab = 'dashboard' | 'find-providers' | 'wellness-store' | 'settings';

const LabTechHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab } = useApp();
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    const renderContent = () => {
        switch (activeHubTab) {
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                return (
                     <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2">
                            <Card title={t.labTechHub.labRequests}>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="bg-gray-50">
                                            <tr className="border-b">
                                                <th className="p-3">{t.common.patient}</th>
                                                <th className="p-3">{t.labTechHub.testName}</th>
                                                <th className="p-3">{t.common.date}</th>
                                                <th className="p-3">{t.common.status}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {MOCK_LAB_REQUESTS.map(req => (
                                                <tr key={req.id} className="border-b last:border-0 hover:bg-gray-50">
                                                    <td className="p-3 font-medium text-akoma-dark">{req.patientName}</td>
                                                    <td className="p-3">{req.testName}</td>
                                                    <td className="p-3">{req.date}</td>
                                                    <td className="p-3">
                                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                                            req.status === 'Completed' ? 'bg-akoma-light-green text-akoma-green' 
                                                            : req.status === 'Pending' ? 'bg-yellow-100 text-yellow-800'
                                                            : 'bg-blue-100 text-akoma-blue'
                                                        }`}>
                                                            {req.status}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </Card>
                        </div>
                        <div>
                            <Card title={t.labTechHub.quickActions}>
                                <button onClick={() => setIsModalOpen(true)} className="w-full text-left p-3 bg-akoma-light-blue text-akoma-blue font-semibold rounded-lg hover:bg-blue-200 transition-colors">
                                    {t.labTechHub.newResult}
                                </button>
                            </Card>
                        </div>
                    </div>
                );
        }
    };
    
    const TabButton: React.FC<{ tabName: Tab; label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'} hidden md:inline-block`}
        >{label}</button>
    );

    return (
        <div className="max-w-6xl mx-auto">
            {isModalOpen && <UploadResultModal onClose={() => setIsModalOpen(false)} />}
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">{t.labTechHub.dashboardTitle}</h2>
            <div className="mb-6 bg-white p-2 rounded-lg shadow-sm inline-flex space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            {renderContent()}
        </div>
    );
};

export default LabTechHub;