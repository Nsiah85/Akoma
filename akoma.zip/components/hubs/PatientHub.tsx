import React from 'react';
import { useApp } from '../../contexts/AppContext';
import PatientDashboardView from './patient/PatientDashboardView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';
import UserSettingsView from './shared/UserSettingsView';
import MedicationReminders from './patient/MedicationReminders';

type PatientTab = 'dashboard' | 'find-providers' | 'wellness-store' | 'reminders' | 'settings';

const PatientHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab } = useApp();

    const TabButton: React.FC<{ tabName: PatientTab, label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >
            {label}
        </button>
    );
    
    const renderContent = () => {
        switch (activeHubTab) {
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'reminders':
                return <MedicationReminders />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                // If on mobile and an invalid tab is selected, default to dashboard
                if (window.innerWidth < 768 && !['dashboard', 'find-providers', 'wellness-store', 'settings'].includes(activeHubTab)) {
                    setActiveHubTab('dashboard');
                }
                return <PatientDashboardView />;
        }
    };

    return (
        <div className="max-w-7xl mx-auto">
            <div className="mb-6 bg-white p-2 rounded-lg shadow-sm space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="reminders" label={t.patientHub.reminders} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>

            <div className="p-4 md:p-0">
                {renderContent()}
            </div>
        </div>
    );
};

export default PatientHub;