import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import UserSettingsView from './shared/UserSettingsView';
import { Product } from '../../types';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';
import ProductModal from './vendor/ProductModal';
import { TrashIcon } from '../icons/TrashIcon';
import VendorPayoutsView from './vendor/VendorPayoutsView';

const ManageProducts: React.FC = () => {
    const { products, deleteProduct } = useApp();
    // In a real app, this would be filtered to the vendor's own products
    const [vendorProducts] = useState<Product[]>(products);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [productToEdit, setProductToEdit] = useState<Product | null>(null);

    const handleEdit = (product: Product) => {
        setProductToEdit(product);
        setIsModalOpen(true);
    };

    const handleAdd = () => {
        setProductToEdit(null);
        setIsModalOpen(true);
    };

    const handleDelete = (productId: string) => {
        if (window.confirm('Are you sure you want to delete this product?')) {
            deleteProduct(productId);
        }
    };
    
    const closeModal = () => {
        setIsModalOpen(false);
        setProductToEdit(null);
    }

    return (
        <div>
            {isModalOpen && <ProductModal product={productToEdit} onClose={closeModal} />}
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-akoma-dark">My Products</h3>
                <button onClick={handleAdd} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                    Add Product
                </button>
            </div>
            <div className="space-y-4">
                {products.map(product => (
                    <div key={product.id} className="bg-gray-50 p-4 rounded-lg border flex items-center space-x-4">
                        <img src={product.imageUrl} alt={product.name} className="w-20 h-20 object-cover rounded-md bg-gray-200" />
                        <div className="flex-1">
                            <p className="font-bold text-akoma-dark">{product.name}</p>
                            <p className="text-sm text-akoma-grey">{product.description}</p>
                            <p className="text-md font-semibold text-akoma-blue mt-1">${product.price.toFixed(2)}</p>
                        </div>
                        <div className="flex flex-col space-y-2">
                             <button onClick={() => handleEdit(product)} className="text-sm font-semibold text-akoma-blue hover:underline">Edit</button>
                             <button onClick={() => handleDelete(product.id)} className="p-1 text-gray-400 hover:text-red-600 flex items-center space-x-1 text-sm">
                                <TrashIcon className="w-4 h-4" />
                                <span>Delete</span>
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

type VendorTab = 'products' | 'payouts' | 'find-providers' | 'wellness-store' | 'settings';

const VendorHub: React.FC = () => {
    const { activeHubTab, setActiveHubTab, t } = useApp();

    const TabButton: React.FC<{ tabName: VendorTab, label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >
            {label}
        </button>
    );

    const renderContent = () => {
        switch (activeHubTab) {
            case 'payouts':
                return <VendorPayoutsView />;
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'products':
            default:
                if (window.innerWidth < 768 && !['products', 'settings'].includes(activeHubTab)) {
                    setActiveHubTab('products');
                }
                return <ManageProducts />;
        }
    };
    
    return (
        <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">Vendor Dashboard</h2>
             <div className="mb-6 bg-white p-2 rounded-lg shadow-sm inline-flex space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="products" label={t.common.products} />
                <TabButton tabName="payouts" label={t.common.payouts} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
             <div className="bg-white p-6 rounded-lg shadow-sm min-h-[400px]">
                {renderContent()}
            </div>
        </div>
    );
};

export default VendorHub;
