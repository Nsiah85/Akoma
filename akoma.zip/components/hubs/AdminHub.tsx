import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import AdminDashboardView from './admin/AdminDashboardView';
import AdminUsersView from './admin/AdminUsersView';
import AdminVendorsView from './admin/AdminVendorsView';
import AdminPayoutsView from './admin/AdminPayoutsView';
import AdminSettingsView from './admin/AdminSettingsView';
import { DashboardIcon, UsersIcon, StoreIcon, CashIcon, SettingsIcon } from '../icons/NavIcons';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';
import { ProviderIcon } from '../icons/ProviderIcon';
import { ShoppingCartIcon } from '../icons/ShoppingCartIcon';

type AdminTab = 'dashboard' | 'users' | 'vendors' | 'payouts' | 'settings' | 'find-providers' | 'wellness-store';

const AdminHub: React.FC<{ isSidebarOpen: boolean; onSidebarClose: () => void }> = ({ isSidebarOpen, onSidebarClose }) => {
    const { t, activeHubTab, setActiveHubTab } = useApp();

    const handleTabClick = (tab: AdminTab) => {
        setActiveHubTab(tab);
        if (window.innerWidth < 1024) { // Close sidebar on mobile/tablet after selection
            onSidebarClose();
        }
    }

    const renderContent = () => {
        switch (activeHubTab) {
            case 'users': return <AdminUsersView />;
            case 'vendors': return <AdminVendorsView />;
            case 'find-providers': return <FindProviders />;
            case 'wellness-store': return <WellnessStore />;
            case 'payouts': return <AdminPayoutsView />;
            case 'settings': return <AdminSettingsView />;
            case 'dashboard':
            default:
                return <AdminDashboardView />;
        }
    };
    
    const navItems = [
        { id: 'dashboard', label: t.common.dashboard, icon: <DashboardIcon className="w-5 h-5" /> },
        { id: 'users', label: t.common.users, icon: <UsersIcon className="w-5 h-5" /> },
        { id: 'vendors', label: t.common.vendors, icon: <StoreIcon className="w-5 h-5" /> },
        { id: 'find-providers', label: t.common.findProviders, icon: <ProviderIcon className="w-5 h-5" /> },
        { id: 'wellness-store', label: t.common.wellnessStore, icon: <ShoppingCartIcon className="w-5 h-5" /> },
        { id: 'payouts', label: t.common.payouts, icon: <CashIcon className="w-5 h-5" /> },
        { id: 'settings', label: t.common.settings, icon: <SettingsIcon className="w-5 h-5" /> },
    ];

    const sidebarClasses = `
        bg-white h-full shadow-lg lg:shadow-none lg:bg-transparent lg:h-auto 
        fixed lg:static top-0 left-0 z-40 
        w-64 flex-shrink-0 
        transition-transform duration-300 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0
    `;

    return (
        <div className="flex max-w-7xl mx-auto relative">
            {isSidebarOpen && <div className="sidebar-backdrop lg:hidden" onClick={onSidebarClose}></div>}
            
            <aside className={sidebarClasses}>
                <nav className="p-4 h-full">
                    <ul className="space-y-2">
                        {navItems.map(item => (
                            <li key={item.id}>
                                <button
                                    onClick={() => handleTabClick(item.id as AdminTab)}
                                    className={`w-full flex items-center space-x-3 p-3 rounded-md text-sm font-semibold transition-colors ${
                                        activeHubTab === item.id 
                                        ? 'bg-akoma-light-blue text-akoma-blue' 
                                        : 'text-akoma-grey hover:bg-gray-100'
                                    }`}
                                >
                                    {item.icon}
                                    <span>{item.label}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                </nav>
            </aside>
            <main className="flex-1 p-4 md:p-0">
                {renderContent()}
            </main>
        </div>
    );
};

export default AdminHub;