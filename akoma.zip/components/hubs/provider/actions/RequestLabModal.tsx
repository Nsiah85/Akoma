
import React, { useState } from 'react';
import { useApp } from '../../../../contexts/AppContext';
import { Patient } from '../../../../types';

const RequestLabModal: React.FC<{ patient: Patient; onClose: () => void; }> = ({ patient, onClose }) => {
    const { addLabRequestForPatient, addToast } = useApp();
    const [testName, setTestName] = useState('');
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!testName.trim()) return;
        addLabRequestForPatient(patient.id, testName);
        addToast({ message: `Lab request for "${testName}" sent to ${patient.name}.`, type: 'info' });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Request Lab for {patient.name}</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Lab Test Name</label>
                        <input
                            type="text"
                            value={testName}
                            onChange={e => setTestName(e.target.value)}
                            className="mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey"
                            placeholder="e.g., Complete Blood Count"
                            required
                        />
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md">Send Request</button>
                </footer>
            </form>
        </div>
    );
};

export default RequestLabModal;
