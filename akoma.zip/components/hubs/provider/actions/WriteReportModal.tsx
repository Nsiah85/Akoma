import React, { useState } from 'react';
import { useApp } from '../../../../contexts/AppContext';
import { Patient } from '../../../../types';

const SOAP_TEMPLATE = `Subjective:
- Patient reports...

Objective:
- Vitals: 
- Physical Exam: 

Assessment:
- 

Plan:
- 
- 
- Follow-up: 
`;

const WriteReportModal: React.FC<{ patient: Patient; onClose: () => void; }> = ({ patient, onClose }) => {
    const { addReportForPatient } = useApp();
    const [report, setReport] = useState('');
    const [attachment, setAttachment] = useState<File | null>(null);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!report.trim()) return;
        
        let reportWithAttachment = report;
        if (attachment) {
            reportWithAttachment += `\n\n--- Attached File: ${attachment.name} ---`;
        }

        addReportForPatient(patient.id, reportWithAttachment);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Write Report for {patient.name}</h3>
                </header>
                <main className="p-6">
                    <div>
                        <div className="flex justify-between items-center mb-1">
                             <label className="block text-sm font-medium text-akoma-dark">Report / Doctor's Note</label>
                             <button type="button" onClick={() => setReport(SOAP_TEMPLATE)} className="text-xs font-semibold text-akoma-blue hover:underline">Use SOAP Template</button>
                        </div>
                        <textarea
                            value={report}
                            onChange={e => setReport(e.target.value)}
                            rows={10}
                            className="mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white"
                            placeholder="Enter clinical notes, visit summary, etc."
                            required
                        />
                    </div>
                    <div className="mt-4">
                        <label className="block text-sm font-medium text-akoma-dark">Attach File (Optional)</label>
                         <input type="file" onChange={e => setAttachment(e.target.files?.[0] || null)} className="mt-1 block w-full text-sm text-akoma-grey file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-akoma-light-blue file:text-akoma-blue hover:file:bg-blue-200"/>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md">Save Report</button>
                </footer>
            </form>
        </div>
    );
};

export default WriteReportModal;
