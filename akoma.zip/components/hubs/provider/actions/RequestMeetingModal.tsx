
import React, { useState } from 'react';
import { useApp } from '../../../../contexts/AppContext';
import { Patient } from '../../../../types';

const RequestMeetingModal: React.FC<{ patient: Patient; onClose: () => void; }> = ({ patient, onClose }) => {
    const { user, addAppointmentForPatient, addToast } = useApp();
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [reason, setReason] = useState('');
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!date || !time || !reason.trim() || !user) return;
        addAppointmentForPatient(patient.id, {
            date,
            time,
            specialty: reason,
            doctor: user.name,
        });
        addToast({ message: `Meeting request for ${patient.name} on ${date} has been sent.`, type: 'info' });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Request Meeting with {patient.name}</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Date</label>
                        <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md bg-akoma-dark text-white"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">Time</label>
                        <input type="time" value={time} onChange={e => setTime(e.target.value)} required className="mt-1 w-full p-2 border rounded-md bg-akoma-dark text-white"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">Reason for Meeting</label>
                        <input type="text" value={reason} onChange={e => setReason(e.target.value)} required placeholder="e.g., Follow-up consultation" className="mt-1 w-full p-2 border rounded-md bg-akoma-dark text-white"/>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md">Send Request</button>
                </footer>
            </form>
        </div>
    );
};

export default RequestMeetingModal;
