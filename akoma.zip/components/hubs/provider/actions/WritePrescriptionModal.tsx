
import React, { useState } from 'react';
import { useApp } from '../../../../contexts/AppContext';
import { Patient } from '../../../../types';

const WritePrescriptionModal: React.FC<{ patient: Patient; onClose: () => void; }> = ({ patient, onClose }) => {
    const { addPrescriptionForPatient, addToast } = useApp();
    const [drug, setDrug] = useState('');
    const [dosage, setDosage] = useState('');
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!drug.trim() || !dosage.trim()) return;
        addPrescriptionForPatient(patient.id, {
            drug,
            dosage,
            date: new Date().toISOString().split('T')[0],
        });
        addToast({ message: `Prescription for ${drug} has been added for ${patient.name}.`, type: 'success' });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Write Prescription for {patient.name}</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Drug Name</label>
                        <input type="text" value={drug} onChange={e => setDrug(e.target.value)} required className="mt-1 w-full p-2 border rounded-md bg-akoma-dark text-white"/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Dosage Instructions</label>
                        <input type="text" value={dosage} onChange={e => setDosage(e.target.value)} required className="mt-1 w-full p-2 border rounded-md bg-akoma-dark text-white" placeholder="e.g., 1 tablet daily"/>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md">Add Prescription</button>
                </footer>
            </form>
        </div>
    );
};

export default WritePrescriptionModal;
