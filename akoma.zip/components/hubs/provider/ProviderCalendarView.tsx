import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { Availability } from '../../../types';

const EditDayModal: React.FC<{ date: Date; availability: Availability; onClose: () => void; onSave: (date: string, slots: { time: string }[], capacity: number) => void; }> = ({ date, availability, onClose, onSave }) => {
    const dateString = date.toISOString().split('T')[0];
    const dayData = availability[dateString];
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
    
    const [capacity, setCapacity] = useState(dayData?.capacity || 5);
    const [slots, setSlots] = useState(dayData?.slots.map(s => s.time) || ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM']);
    
    const handleSlotChange = (index: number, value: string) => {
        const newSlots = [...slots];
        newSlots[index] = value;
        setSlots(newSlots);
    };

    const handleAddSlot = () => setSlots([...slots, '']);
    const handleRemoveSlot = (index: number) => setSlots(slots.filter((_, i) => i !== index));

    const handleSave = () => {
        onSave(dateString, slots.filter(s => s.trim()).map(time => ({ time })), capacity);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b"><h3 className="text-xl font-bold text-akoma-blue">Edit Availability for {date.toDateString()}</h3></header>
                <main className="p-6 space-y-4 max-h-96 overflow-y-auto">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Max Appointments for this Day</label>
                        <input type="number" value={capacity} onChange={e => setCapacity(parseInt(e.target.value))} className={`mt-1 ${inputClasses}`} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark mb-2">Available Time Slots</label>
                        <div className="space-y-2">
                        {slots.map((slot, index) => (
                            <div key={index} className="flex items-center space-x-2">
                                <input type="time" value={slot.split(' ')[0]} onChange={e => handleSlotChange(index, e.target.value)} className={inputClasses} />
                                <button onClick={() => handleRemoveSlot(index)} className="text-red-500 p-1 rounded-full hover:bg-red-100">&times;</button>
                            </div>
                        ))}
                        </div>
                        <button onClick={handleAddSlot} className="text-sm font-semibold text-akoma-blue hover:underline mt-2">Add Slot</button>
                    </div>
                </main>
                 <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">Cancel</button>
                    <button onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Save Changes</button>
                </footer>
            </div>
        </div>
    )
}

const ProviderCalendarView: React.FC = () => {
    const { t } = useApp();
    const [availability, setAvailability] = useState<Availability>({});
    const [editingDate, setEditingDate] = useState<Date | null>(null);
    const today = new Date();

    const handleSaveDay = (date: string, slots: { time: string }[], capacity: number) => {
        setAvailability(prev => ({
            ...prev,
            [date]: { capacity, slots }
        }));
    };

    const renderDay = (date: Date) => {
        const dateString = date.toISOString().split('T')[0];
        const dayData = availability[dateString];
        const isPast = dateString < today.toISOString().split('T')[0];
        
        let statusClass = 'bg-gray-100 hover:bg-gray-200';
        if (isPast) statusClass = 'bg-gray-50 text-gray-400';
        else if (dayData) {
            const bookedSlots = dayData.slots.filter(s => s.bookedBy).length;
            if (bookedSlots === dayData.capacity) statusClass = 'bg-red-200 text-red-700';
            else if (bookedSlots > 0) statusClass = 'bg-yellow-200 text-yellow-800';
            else statusClass = 'bg-green-200 text-green-800';
        }
        
        return (
            <button key={dateString} disabled={isPast} onClick={() => !isPast && setEditingDate(date)} className={`h-20 flex flex-col items-start p-2 rounded-md transition-colors text-sm border ${statusClass}`}>
                <span className="font-semibold">{date.getDate()}</span>
                {dayData && <span className="text-xs mt-1">{dayData.slots.filter(s=>s.bookedBy).length} / {dayData.capacity} booked</span>}
            </button>
        )
    }
    
    const calendarDays = () => {
        const days = [];
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        
        for(let i=0; i < monthStart.getDay(); i++) { days.push(<div key={`empty-${i}`}></div>); }
        for (let i = 1; i <= monthEnd.getDate(); i++) {
            days.push(renderDay(new Date(monthStart.getFullYear(), monthStart.getMonth(), i)));
        }
        return days;
    }

    return (
        <div className="bg-white p-6 rounded-lg shadow-sm">
            {editingDate && <EditDayModal date={editingDate} availability={availability} onClose={() => setEditingDate(null)} onSave={handleSaveDay} />}
            <h2 className="text-xl font-bold text-akoma-dark mb-4">Manage My Availability</h2>
            <p className="text-akoma-grey mb-4 text-sm">Click on a date to set or edit your available time slots and daily capacity.</p>
            
            <div className="flex justify-between items-center mb-2 px-2">
                <span className="font-bold text-lg">{today.toLocaleString('default', { month: 'long', year: 'numeric' })}</span>
            </div>
            <div className="grid grid-cols-7 gap-2 text-center text-xs text-akoma-grey mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => <div key={d}>{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-2">
                {calendarDays()}
            </div>
        </div>
    );
};

export default ProviderCalendarView;