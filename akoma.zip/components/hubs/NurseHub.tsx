
import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../contexts/AppContext';
import { Task } from '../../types';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';
import AddTaskModal from './nurse/AddTaskModal';
import { TrashIcon } from '../icons/TrashIcon';

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
        <h3 className="text-xl font-bold text-akoma-blue mb-4">{title}</h3>
        {children}
    </div>
);

const RecordVitalsModal: React.FC<{ patientName: string; onClose: () => void; }> = ({ patientName, onClose }) => {
    const { t, updateHealthSummary, addToast } = useApp();
    const [bp, setBp] = useState('135/85');
    const [hr, setHr] = useState('72');
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
    
    const handleSave = () => {
        updateHealthSummary('Blood Pressure', bp, 'high');
        updateHealthSummary('Heart Rate', hr, 'normal');
        addToast({ message: `Vitals for ${patientName} updated successfully.`, type: 'success' });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b"><h3 className="text-xl font-bold text-akoma-blue">{t.nurseHub.vitalsFor.replace('{patientName}', patientName)}</h3></header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.nurseHub.bp} (mmHg)</label>
                        <input type="text" value={bp} onChange={e => setBp(e.target.value)} className={`mt-1 ${inputClasses}`} placeholder="e.g., 120/80" required />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.nurseHub.hr} (bpm)</label>
                        <input type="text" value={hr} onChange={e => setHr(e.target.value)} className={`mt-1 ${inputClasses}`} placeholder="e.g., 75" required />
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.nurseHub.saveVitals}</button>
                </footer>
            </div>
        </div>
    );
}

type Tab = 'dashboard' | 'find-providers' | 'wellness-store' | 'settings';
type SortBy = 'priority' | 'dueDate' | 'creationDate';

const NurseHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab, nurseAssignments, updateTaskStatus, deleteTaskForPatient, showConfirmation } = useApp();
    const [isVitalsModalOpen, setIsVitalsModalOpen] = useState(false);
    const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
    
    const assignment = nurseAssignments[0]; 
    const [tasks, setTasks] = useState<Task[]>(assignment?.tasks || []);
    const [sortBy, setSortBy] = useState<SortBy>('priority');
    const [recentlyCompletedId, setRecentlyCompletedId] = useState<string | null>(null);

    useEffect(() => {
        setTasks(nurseAssignments[0]?.tasks || []);
    }, [nurseAssignments]);

    const handleCompleteTask = (taskId: string) => {
        setRecentlyCompletedId(taskId);
        setTimeout(() => {
            updateTaskStatus(assignment.patientName, taskId, true);
            setRecentlyCompletedId(null);
        }, 500); // Duration of the animation
    };

    const handleDeleteTask = (taskId: string) => {
        showConfirmation({
            title: 'Delete Task',
            message: 'Are you sure you want to permanently delete this task?',
            onConfirm: () => deleteTaskForPatient(assignment.patientName, taskId),
            confirmText: 'Delete Task',
        });
    };

    const sortedTasks = useMemo(() => {
        return [...tasks].sort((a, b) => {
            if (a.completed && !b.completed) return 1;
            if (!a.completed && b.completed) return -1;
            if (a.completed && b.completed) return new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime();

            switch (sortBy) {
                case 'dueDate':
                    if (!a.dueDate) return 1;
                    if (!b.dueDate) return -1;
                    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
                case 'creationDate':
                    return new Date(b.creationDate).getTime() - new Date(a.creationDate).getTime();
                case 'priority':
                default:
                    const priorityOrder = { High: 1, Medium: 2, Low: 3 };
                    return priorityOrder[a.priority] - priorityOrder[b.priority];
            }
        });
    }, [tasks, sortBy]);

    const priorityStyles: { [key in Task['priority']]: string } = {
        High: 'border-red-500',
        Medium: 'border-yellow-500',
        Low: 'border-gray-400',
    };

     const renderContent = () => {
        switch (activeHubTab) {
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                if (window.innerWidth < 768 && !['dashboard', 'settings'].includes(activeHubTab)) {
                    setActiveHubTab('dashboard');
                }
                return (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2">
                            <Card title={t.nurseHub.assignedPatients}>
                                <div className="bg-akoma-light-blue p-4 rounded-lg">
                                    <div className="flex justify-between items-center">
                                        <p className="font-bold text-lg text-akoma-dark">{assignment.patientName}</p>
                                        <p className="text-sm text-akoma-grey">{t.nurseHub.room}: {assignment.room}</p>
                                    </div>
                                    <div className="mt-4 border-t pt-4">
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="font-semibold text-akoma-blue">{t.nurseHub.carePlanTasks}</h4>
                                            <button onClick={() => setIsAddTaskModalOpen(true)} className="text-xs font-semibold text-akoma-blue hover:underline">
                                                + Add Task
                                            </button>
                                        </div>
                                        <div className="flex justify-end items-center space-x-2 mb-2">
                                            <label htmlFor="sort-tasks" className="text-xs font-medium text-akoma-grey">Sort by:</label>
                                            <select id="sort-tasks" value={sortBy} onChange={(e) => setSortBy(e.target.value as SortBy)} className="text-xs rounded-md border-gray-300 shadow-sm focus:border-akoma-blue focus:ring-akoma-blue">
                                                <option value="priority">Priority</option>
                                                <option value="dueDate">Due Date</option>
                                                <option value="creationDate">Newest</option>
                                            </select>
                                        </div>
                                        <ul className="space-y-2">
                                            {sortedTasks.map(task => (
                                                <li key={task.id} className={`task-item flex items-start justify-between text-sm p-3 bg-white rounded-md border-l-4 transition-all duration-500 ${priorityStyles[task.priority]} ${task.completed ? 'completed' : ''} ${recentlyCompletedId === task.id ? 'animate-fade-out-and-shrink' : ''}`}>
                                                    <div className="flex-1">
                                                        <p className="task-description text-akoma-dark">{task.description}</p>
                                                        {task.dueDate && <p className="text-xs text-akoma-grey mt-1">Due: {new Date(task.dueDate + 'T00:00:00').toDateString()}</p>}
                                                    </div>
                                                    <div className="flex items-center ml-4 space-x-2">
                                                        {!task.completed && (
                                                            <button onClick={() => handleCompleteTask(task.id)} className="text-xs font-semibold text-akoma-green hover:underline whitespace-nowrap">
                                                                {t.nurseHub.completeTask}
                                                            </button>
                                                        )}
                                                        <button onClick={() => handleDeleteTask(task.id)} className="p-1 text-gray-400 hover:text-red-600 rounded-full" aria-label="Delete task">
                                                            <TrashIcon className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </Card>
                        </div>
                        <div>
                            <Card title={t.nurseHub.quickActions}>
                                <button onClick={() => setIsVitalsModalOpen(true)} className="w-full text-left p-3 bg-akoma-light-blue text-akoma-blue font-semibold rounded-lg hover:bg-blue-200 transition-colors">
                                    {t.nurseHub.recordVitals}
                                </button>
                            </Card>
                        </div>
                    </div>
                )
        }
    }

    const TabButton: React.FC<{ tabName: Tab; label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >{label}</button>
    );

    return (
        <div className="max-w-6xl mx-auto">
            {isVitalsModalOpen && <RecordVitalsModal patientName={assignment.patientName} onClose={() => setIsVitalsModalOpen(false)} />}
            {isAddTaskModalOpen && <AddTaskModal patientName={assignment.patientName} onClose={() => setIsAddTaskModalOpen(false)} />}
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">{t.nurseHub.dashboardTitle}</h2>
             <div className="mb-6 bg-white p-2 rounded-lg shadow-sm inline-flex space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            {renderContent()}
        </div>
    );
};

export default NurseHub;
