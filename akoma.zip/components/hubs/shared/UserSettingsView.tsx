import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { User, UserRole } from '../../../types';
import ThemeSettings from './ThemeSettings';

const UserSettingsView: React.FC = () => {
    const { t, user, updateUserProfile, updateUserPassword, updateUserListingStatus } = useApp();
    const [name, setName] = useState(user?.name || '');
    const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(user?.profileImageUrl || null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Role-specific state
    const [specialty, setSpecialty] = useState(user?.specialty || '');
    const [companyName, setCompanyName] = useState(user?.companyName || '');
    const [licenseNumber, setLicenseNumber] = useState(user?.licenseNumber || '');
    const [facilityName, setFacilityName] = useState(user?.facilityName || '');
    
    // UI Feedback State
    const [profileError, setProfileError] = useState('');
    const [profileSuccess, setProfileSuccess] = useState('');

    // Password State
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [passwordSuccess, setPasswordSuccess] = useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setProfileImageFile(file);
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleSaveChanges = () => {
        setProfileError('');
        setProfileSuccess('');

        if (!name.trim()) {
            setProfileError(t.settings.errors.nameRequired);
            return;
        }

        const profileData: Partial<User> = {
            name,
            profileImageUrl: previewUrl || undefined,
            specialty: user?.role === UserRole.Doctor ? specialty : undefined,
            companyName: [UserRole.Vendor, UserRole.Insurer, UserRole.Lawyer].includes(user?.role as UserRole) ? companyName : undefined,
            licenseNumber: [UserRole.Doctor, UserRole.Nurse, UserRole.Pharmacist].includes(user?.role as UserRole) ? licenseNumber : undefined,
            facilityName: [UserRole.Nurse, UserRole.LabTech, UserRole.FacilityAdmin].includes(user?.role as UserRole) ? facilityName : undefined,
        };

        updateUserProfile(profileData);
        setProfileSuccess(t.settings.successMessage);
    };
    
    const handlePasswordChange = (e: React.FormEvent) => {
        e.preventDefault();
        setPasswordError('');
        setPasswordSuccess('');
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            setPasswordError('All password fields are required.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setPasswordError('New passwords do not match.');
            return;
        }
        if (newPassword.length < 8) {
            setPasswordError('New password must be at least 8 characters long.');
            return;
        }

        const result = updateUserPassword({ current: currentPassword, new: newPassword });
        if(result.success) {
            setPasswordSuccess(result.message);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } else {
            setPasswordError(result.message);
        }
    }

    // Fix: Replaced a single useEffect with a logic bug and incorrect type with two separate, correct useEffects.
    // This resolves the 'NodeJS' type error and ensures timers for success messages are handled independently.
    useEffect(() => {
        if (profileSuccess) {
            const timer = setTimeout(() => setProfileSuccess(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [profileSuccess]);

    useEffect(() => {
        if (passwordSuccess) {
            const timer = setTimeout(() => setPasswordSuccess(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [passwordSuccess]);
    
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
    const disabledInputClasses = "w-full p-2 border rounded-md bg-gray-700 text-gray-400 border-akoma-grey cursor-not-allowed";

    const isProfessional = user && [UserRole.Doctor, UserRole.Nurse, UserRole.Pharmacist, UserRole.LabTech].includes(user.role);

    return (
        <div>
            <h2 className="text-2xl font-bold text-akoma-dark mb-6">{t.settings.title}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 space-y-6">
                    <div className="bg-white p-6 rounded-lg shadow-sm border">
                        <h3 className="text-lg font-semibold text-akoma-blue mb-4">{t.settings.profile}</h3>
                        <div className="space-y-4">
                            <div className="flex items-center space-x-4">
                                {previewUrl ? (
                                    <img src={previewUrl} alt="Profile" className="w-20 h-20 rounded-full object-cover" />
                                ) : (
                                    <div className="w-20 h-20 rounded-full bg-akoma-light-blue text-akoma-blue flex items-center justify-center text-3xl font-bold">
                                        {name.charAt(0)}
                                    </div>
                                )}
                                <div>
                                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                                    <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 text-sm font-medium text-akoma-blue bg-white border border-akoma-blue rounded-md hover:bg-gray-50">
                                        {t.settings.uploadProfilePicture}
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">{t.common.name}</label>
                                <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={inputClasses} required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">Email</label>
                                <input type="email" value={user?.email || ''} disabled className={disabledInputClasses} />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">akomaID</label>
                                <input type="text" value={user?.akomaId || ''} disabled className={disabledInputClasses} />
                            </div>
                            {user?.role === UserRole.Doctor && (
                                <div>
                                    <label className="block text-sm font-medium text-akoma-dark mb-1">Specialty</label>
                                    <input type="text" value={specialty} onChange={(e) => setSpecialty(e.target.value)} className={inputClasses} />
                                </div>
                            )}
                            {[UserRole.Doctor, UserRole.Nurse, UserRole.Pharmacist].includes(user?.role as UserRole) && (
                                <div>
                                    <label className="block text-sm font-medium text-akoma-dark mb-1">License Number</label>
                                    <input type="text" value={licenseNumber} onChange={(e) => setLicenseNumber(e.target.value)} className={inputClasses} />
                                </div>
                            )}
                            {[UserRole.Nurse, UserRole.LabTech, UserRole.FacilityAdmin].includes(user?.role as UserRole) && (
                                <div>
                                    <label className="block text-sm font-medium text-akoma-dark mb-1">Facility / Hospital Name</label>
                                    <input type="text" value={facilityName} onChange={(e) => setFacilityName(e.target.value)} className={inputClasses} />
                                </div>
                            )}
                            {[UserRole.Vendor, UserRole.Insurer, UserRole.Lawyer].includes(user?.role as UserRole) && (
                                <div>
                                    <label className="block text-sm font-medium text-akoma-dark mb-1">Company Name</label>
                                    <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className={inputClasses} />
                                </div>
                            )}
                        </div>
                        <div className="mt-6 border-t pt-4 flex justify-end items-center space-x-4">
                            {profileError && <p className="text-sm text-red-600 animate-fade-in-fast">{profileError}</p>}
                            {profileSuccess && <p className="text-sm text-akoma-green animate-fade-in-fast">{profileSuccess}</p>}
                            <button onClick={handleSaveChanges} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                                {t.settings.saveChanges}
                            </button>
                        </div>
                    </div>

                    {isProfessional && (
                        <div className="bg-white p-6 rounded-lg shadow-sm border">
                            <h3 className="text-lg font-semibold text-akoma-blue mb-2">Provider Settings</h3>
                            <div className="flex justify-between items-center py-4">
                                <div>
                                    <p className="font-medium text-akoma-dark">List my profile for patient booking</p>
                                    <p className="text-sm text-akoma-grey">Allow patients to find and book appointments with you.</p>
                                </div>
                                <button onClick={() => updateUserListingStatus(!user?.isListedProvider)} className={`w-12 h-6 rounded-full p-1 flex items-center transition-colors ${user?.isListedProvider ? 'bg-akoma-blue justify-end' : 'bg-gray-300 justify-start'}`}>
                                    <span className="w-4 h-4 rounded-full bg-white block"></span>
                                </button>
                            </div>
                        </div>
                    )}


                     <form onSubmit={handlePasswordChange} className="bg-white p-6 rounded-lg shadow-sm border">
                        <h3 className="text-lg font-semibold text-akoma-blue mb-4">Change Password</h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">Current Password</label>
                                <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className={inputClasses} required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">New Password</label>
                                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className={inputClasses} required />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-akoma-dark mb-1">Confirm New Password</label>
                                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className={inputClasses} required />
                            </div>
                        </div>
                         <div className="mt-6 border-t pt-4 flex justify-end items-center space-x-4">
                            {passwordError && <p className="text-sm text-red-600 animate-fade-in-fast">{passwordError}</p>}
                            {passwordSuccess && <p className="text-sm text-akoma-green animate-fade-in-fast">{passwordSuccess}</p>}
                            <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                                Update Password
                            </button>
                        </div>
                    </form>
                </div>
                 <div className="md:col-span-1">
                    <ThemeSettings />
                </div>
            </div>
        </div>
    );
};

export default UserSettingsView;