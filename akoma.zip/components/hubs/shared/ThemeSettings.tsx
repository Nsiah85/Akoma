import React from 'react';
import { useApp } from '../../../contexts/AppContext';
import { Theme } from '../../../types';

const THEME_OPTIONS = {
    backgrounds: [
        { name: 'Light', color: '#F9FAFB' },
        { name: 'Paper', color: '#FEFCE8' },
        { name: 'Mint', color: '#F0FDF4' },
        { name: 'Sky', color: '#F0F9FF' },
    ],
    fonts: [
        'Inter', 'Roboto', 'Lato', 'Montserrat'
    ]
};

const ThemeSettings: React.FC = () => {
    const { theme, setTheme } = useApp();

    const handleThemeChange = (key: keyof Theme, value: string) => {
        setTheme({ ...theme, [key]: value });
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-lg font-semibold text-akoma-blue mb-4">Appearance</h3>
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-akoma-dark mb-2">Background Color</label>
                    <div className="flex flex-wrap gap-2">
                        {THEME_OPTIONS.backgrounds.map(bg => (
                            <button key={bg.name} onClick={() => handleThemeChange('background', bg.color)} className={`w-12 h-8 rounded-md border-2 ${theme.background === bg.color ? 'border-akoma-blue' : 'border-gray-200'}`} style={{ backgroundColor: bg.color }} title={bg.name}></button>
                        ))}
                    </div>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-akoma-dark mb-1">Font Family</label>
                    <select
                        value={theme.font}
                        onChange={(e) => handleThemeChange('font', e.target.value)}
                        className="w-full p-2 border rounded-md bg-white text-akoma-dark"
                    >
                       {THEME_OPTIONS.fonts.map(font => (
                           <option key={font} value={font} style={{ fontFamily: `'${font}', sans-serif` }}>{font}</option>
                       ))}
                    </select>
                </div>
            </div>
        </div>
    );
};

export default ThemeSettings;