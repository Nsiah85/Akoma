
import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { UserRole } from '../../../types';
import { validateEmail, checkPasswordStrength } from '../../../utils/validation';
import { COUNTRIES } from '../../../constants';

const AddPatientModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { addUser, t, addToast } = useApp();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const [country, setCountry] = useState(COUNTRIES[0].code);
    const [error, setError] = useState('');
    const inputClasses = "mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!validateEmail(email)) { setError("Invalid email format."); return; }
        if (checkPasswordStrength(password).strength === 'Weak') { setError("Password is too weak."); return; }
        if (!fullName.trim()) { setError("Full name is required."); return; }

        const result = addUser({ name: fullName, email, password, role: UserRole.Patient, country });
        if (result.success) {
            addToast({ message: `${fullName} has been added and an invite has been sent.`, type: 'success' });
            onClose();
        } else {
            setError(result.message || 'Failed to add patient.');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Add New Patient</h3>
                </header>
                <main className="p-6 space-y-4">
                    {error && <div className="bg-red-100 text-red-700 p-3 rounded-md text-sm">{error}</div>}
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.auth.fullName}</label>
                        <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} required className={inputClasses} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.auth.email}</label>
                        <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className={inputClasses} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.auth.password}</label>
                        <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className={inputClasses} placeholder="Create a temporary password" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.auth.selectCountry}</label>
                        <select value={country} onChange={e => setCountry(e.target.value)} className={inputClasses}>
                            {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
                        </select>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Add Patient</button>
                </footer>
            </form>
        </div>
    );
};

export default AddPatientModal;
