import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { PharmacyPrescription } from '../../types';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
        <h3 className="text-xl font-bold text-akoma-blue mb-4">{title}</h3>
        {children}
    </div>
);

const ConfirmDispenseModal: React.FC<{ prescription: PharmacyPrescription; onClose: () => void; }> = ({ prescription, onClose }) => {
    const { t, updatePrescriptionStatus } = useApp();
    
    const handleConfirm = () => {
        // Assuming prescription id from PharmacyPrescription matches an id in patientData.prescriptions
        updatePrescriptionStatus(prescription.id, true);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md text-center p-6">
                <h3 className="text-xl font-bold text-akoma-blue">{t.pharmacistHub.confirmDispense}</h3>
                <p className="my-4 text-akoma-grey">{t.pharmacistHub.confirmDispenseMsg.replace('{patientName}', prescription.patientName)}</p>
                <div className="flex justify-center space-x-4">
                    <button onClick={onClose} className="px-6 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button onClick={handleConfirm} className="px-6 py-2 text-sm font-medium text-white bg-akoma-green rounded-md hover:bg-green-700">{t.pharmacistHub.dispense}</button>
                </div>
            </div>
        </div>
    );
};

type Tab = 'dashboard' | 'find-providers' | 'wellness-store' | 'settings';

const PharmacistHub: React.FC = () => {
    const { t, patientData, activeHubTab, setActiveHubTab } = useApp();
    const [confirmingDispense, setConfirmingDispense] = useState<PharmacyPrescription | null>(null);
    

    // Live data from patient context
    // Fix: Add explicit type `PharmacyPrescription[]` to ensure `status` is correctly typed as 'Pending' | 'Filled' instead of string.
    const prescriptions: PharmacyPrescription[] = patientData?.prescriptions.map(p => ({
        id: p.id,
        patientName: patientData.name,
        medication: p.drug,
        date: p.date,
        status: p.dispensed ? 'Filled' : 'Pending',
        doctor: 'Dr. Kwaku Mensah' // Mock doctor
    })) || [];

    const pendingPrescriptions = prescriptions.filter(p => p.status === 'Pending');
    const filledPrescriptions = prescriptions.filter(p => p.status === 'Filled');

    const renderContent = () => {
        switch (activeHubTab) {
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                if (window.innerWidth < 768 && !['dashboard', 'settings'].includes(activeHubTab)) {
                    setActiveHubTab('dashboard');
                }
                return (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-8">
                            <Card title={t.pharmacistHub.pendingPrescriptions}>
                                <PrescriptionTable prescriptions={pendingPrescriptions} onDispense={setConfirmingDispense} t={t} />
                            </Card>
                            <Card title={t.pharmacistHub.recentlyFilled}>
                                <PrescriptionTable prescriptions={filledPrescriptions} t={t} />
                            </Card>
                        </div>
                        <div>
                            <Card title={t.pharmacistHub.quickActions}>
                                <div className="flex flex-col space-y-3">
                                    <button className="w-full text-left p-3 bg-akoma-light-blue text-akoma-blue font-semibold rounded-lg hover:bg-blue-200 transition-colors">{t.pharmacistHub.checkInventory}</button>
                                    <button className="w-full text-left p-3 bg-akoma-light-blue text-akoma-blue font-semibold rounded-lg hover:bg-blue-200 transition-colors">{t.pharmacistHub.contactDoctor}</button>
                                </div>
                            </Card>
                        </div>
                    </div>
                );
        }
    };

     const TabButton: React.FC<{ tabName: Tab; label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >{label}</button>
    );

    return (
        <div className="max-w-6xl mx-auto">
            {confirmingDispense && <ConfirmDispenseModal prescription={confirmingDispense} onClose={() => setConfirmingDispense(null)} />}
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">{t.pharmacistHub.dashboardTitle}</h2>
             <div className="mb-6 bg-white p-2 rounded-lg shadow-sm inline-flex space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            {renderContent()}
        </div>
    );
};

const PrescriptionTable: React.FC<{ prescriptions: PharmacyPrescription[], onDispense?: (p: PharmacyPrescription) => void, t: any }> = ({ prescriptions, onDispense, t }) => (
    <div className="overflow-x-auto">
        {prescriptions.length === 0 ? <p className="text-akoma-grey">No prescriptions in this category.</p> : (
        <table className="w-full text-left">
            <thead className="bg-gray-50"><tr className="border-b"><th className="p-3">{t.common.patient}</th><th className="p-3">{t.pharmacistHub.medication}</th><th className="p-3">{t.common.date}</th><th></th></tr></thead>
            <tbody>
                {prescriptions.map(p => (
                    <tr key={p.id} className="border-b last:border-0 hover:bg-gray-50">
                        <td className="p-3 font-medium">{p.patientName}</td>
                        <td className="p-3">{p.medication}</td>
                        <td className="p-3">{p.date}</td>
                        <td className="p-3 text-right">
                            {onDispense && <button onClick={() => onDispense(p)} className="text-sm font-semibold text-akoma-blue hover:underline">{t.pharmacistHub.dispense}</button>}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
        )}
    </div>
);

export default PharmacistHub;