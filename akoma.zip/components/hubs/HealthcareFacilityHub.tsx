import React, { useState } from 'react';
// Fix: Corrected imports for mock data from `constants.ts`.
import { MOCK_FACILITY_APPOINTMENTS, MOCK_FACILITY_PATIENTS, MOCK_STAFF } from '../../constants';
// Fix: Corrected import from '../../contexts/AppContext'
import { useApp } from '../../contexts/AppContext';
// Fix: Corrected imports for types from `types.ts`.
import { StaffMember, FacilityAppointment, FacilityPatient } from '../../types';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';

type Tab = 'overview' | 'appointments' | 'staff' | 'patients' | 'find-providers' | 'wellness-store' | 'settings';

const StatCard: React.FC<{ title: string; value: string | number; actionText: string; onAction: () => void }> = ({ title, value, actionText, onAction }) => (
    <div className="bg-white p-4 rounded-lg shadow-sm border">
        <p className="text-sm text-akoma-grey font-medium">{title}</p>
        <p className="text-3xl font-bold text-akoma-dark mt-1">{value}</p>
        <button onClick={onAction} className="text-sm font-semibold text-akoma-blue hover:underline mt-2">{actionText}</button>
    </div>
);

const AddAppointmentModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { t } = useApp();
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">{t.facilityHub.scheduleAppointment}</h3>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.facilityHub.patientName}</label>
                        <input type="text" className={`mt-1 ${inputClasses}`} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.facilityHub.doctorName}</label>
                         <select className={`mt-1 ${inputClasses}`} required>
                           {MOCK_STAFF.filter(s => s.role === 'Doctor').map(d => <option key={d.id}>{d.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.common.date}</label>
                        <input type="date" className={`mt-1 ${inputClasses}`} required />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.common.time}</label>
                        <input type="time" className={`mt-1 ${inputClasses}`} required />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.facilityHub.reasonForVisit}</label>
                        <textarea rows={3} className={`mt-1 ${inputClasses}`} required></textarea>
                    </div>
                </div>
                <div className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.common.submit}</button>
                </div>
            </div>
        </div>
    );
};

const AddStaffModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { t } = useApp();
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">{t.facilityHub.addStaffMember}</h3>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.facilityHub.staffName}</label>
                        <input type="text" className={`mt-1 ${inputClasses}`} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">{t.facilityHub.staffRole}</label>
                         <select className={`mt-1 ${inputClasses}`} required>
                           <option>Doctor</option>
                           <option>Nurse</option>
                           <option>Admin</option>
                           <option>Lab Technician</option>
                        </select>
                    </div>
                </div>
                <div className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.common.add}</button>
                </div>
            </div>
        </div>
    );
}

const HealthcareFacilityHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab } = useApp();
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
    const searchInputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
    

    const renderContent = () => {
        switch (activeHubTab) {
            case 'appointments':
                return (
                    <div>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-2xl font-bold text-akoma-dark">{t.common.appointments}</h3>
                            <button onClick={() => setIsAppointmentModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.facilityHub.scheduleAppointment}</button>
                        </div>
                        <div className="bg-white rounded-lg shadow-md overflow-hidden">
                             <table className="w-full text-left">
                                <thead className="bg-gray-50"><tr className="border-b"><th className="p-3">{t.facilityHub.patientName}</th><th className="p-3">{t.facilityHub.doctorName}</th><th className="p-3">{t.common.date} & {t.common.time}</th><th className="p-3">{t.facilityHub.reasonForVisit}</th></tr></thead>
                                <tbody>
                                    {MOCK_FACILITY_APPOINTMENTS.map((apt: FacilityAppointment) => (
                                        <tr key={apt.id} className="border-b last:border-0 hover:bg-gray-50">
                                            <td className="p-3 font-medium text-akoma-dark">{apt.patientName}</td>
                                            <td className="p-3">{apt.doctorName}</td>
                                            <td className="p-3">{apt.date} at {apt.time}</td>
                                            <td className="p-3">{apt.reason}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            case 'staff':
                 return (
                    <div>
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-2xl font-bold text-akoma-dark">{t.facilityHub.allStaff}</h3>
                            <button onClick={() => setIsStaffModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.facilityHub.addStaffMember}</button>
                        </div>
                        <div className="bg-white rounded-lg shadow-md overflow-hidden">
                             <table className="w-full text-left">
                                <thead className="bg-gray-50"><tr className="border-b"><th className="p-3">{t.common.name}</th><th className="p-3">{t.common.role}</th><th className="p-3">{t.common.status}</th></tr></thead>
                                <tbody>
                                    {MOCK_STAFF.map((staff: StaffMember) => (
                                        <tr key={staff.id} className="border-b last:border-0 hover:bg-gray-50">
                                            <td className="p-3 font-medium text-akoma-dark">{staff.name}</td>
                                            <td className="p-3">{staff.role}</td>
                                            <td className="p-3">
                                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${staff.onDuty ? 'bg-akoma-light-green text-akoma-green' : 'bg-gray-100 text-akoma-grey'}`}>
                                                    {staff.onDuty ? 'On Duty' : 'Off Duty'}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            case 'patients':
                 return (
                    <div>
                        <h3 className="text-2xl font-bold text-akoma-dark mb-4">{t.facilityHub.allPatients}</h3>
                        <input type="text" placeholder={t.facilityHub.searchPatient} className={`mb-4 ${searchInputClasses}`} />
                         <div className="bg-white rounded-lg shadow-md overflow-hidden">
                             <table className="w-full text-left">
                                <thead className="bg-gray-50"><tr className="border-b"><th className="p-3">{t.common.name}</th><th className="p-3">akoma ID</th><th className="p-3">{t.doctorHub.lastVisit}</th><th className="p-3">{t.common.doctor}</th></tr></thead>
                                <tbody>
                                    {MOCK_FACILITY_PATIENTS.map((p: FacilityPatient) => (
                                        <tr key={p.id} className="border-b last:border-0 hover:bg-gray-50">
                                            <td className="p-3 font-medium text-akoma-dark">{p.name}</td>
                                            <td className="p-3 font-mono">{p.akomaId}</td>
                                            <td className="p-3">{p.lastVisit}</td>
                                            <td className="p-3">{p.doctor}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'overview':
            default:
                 // Set default tab for mobile if current is not in mobile nav
                if (!['overview', 'settings'].includes(activeHubTab) && window.innerWidth < 768) {
                    setActiveHubTab('overview');
                }
                return (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <StatCard title={t.facilityHub.todaysAppointments} value={MOCK_FACILITY_APPOINTMENTS.length} actionText={t.facilityHub.viewSchedule} onAction={() => setActiveHubTab('appointments')} />
                        <StatCard title={t.facilityHub.activePatients} value={MOCK_FACILITY_PATIENTS.length} actionText={t.facilityHub.managePatients} onAction={() => setActiveHubTab('patients')} />
                        <StatCard title={t.facilityHub.staffOnDuty} value={MOCK_STAFF.filter(s => s.onDuty).length} actionText={t.facilityHub.manageStaff} onAction={() => setActiveHubTab('staff')} />
                    </div>
                );
        }
    };
    
    const TabButton: React.FC<{ tabName: Tab; label: string; }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >{label}</button>
    );

    return (
        <div className="max-w-6xl mx-auto">
            {isAppointmentModalOpen && <AddAppointmentModal onClose={() => setIsAppointmentModalOpen(false)} />}
            {isStaffModalOpen && <AddStaffModal onClose={() => setIsStaffModalOpen(false)} />}
            <h2 className="text-3xl font-bold text-akoma-dark mb-4">{t.facilityHub.dashboardTitle}</h2>
            <div className="mb-6 bg-white p-2 rounded-lg shadow-sm space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="overview" label={t.facilityHub.overview} />
                <TabButton tabName="appointments" label={t.common.appointments} />
                <TabButton tabName="staff" label={t.facilityHub.staff} />
                <TabButton tabName="patients" label={t.facilityHub.patients} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            
            <div className="bg-gray-100 md:bg-white md:p-6 rounded-lg min-h-[400px]">
                {renderContent()}
            </div>
        </div>
    );
};

export default HealthcareFacilityHub;