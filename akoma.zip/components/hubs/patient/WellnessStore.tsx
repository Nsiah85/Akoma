import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { Product } from '../../../types';
import ProductDetailModal from './ProductDetailModal';

const WellnessStore: React.FC = () => {
    const { products, addToCart, toggleCart, isCartOpen, formatCurrency } = useApp();
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    const handleAddToCart = (product: Product) => {
        addToCart(product);
        if (!isCartOpen) {
            toggleCart();
        }
    }

    return (
        <div>
            {selectedProduct && <ProductDetailModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />}
            <h2 className="text-2xl font-bold text-akoma-dark mb-4">Wellness Store</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {products.map(product => (
                    <div 
                        key={product.id} 
                        className="bg-gray-50 border rounded-lg p-2 flex flex-col text-center cursor-pointer group hover:shadow-md transition-shadow"
                        onClick={() => setSelectedProduct(product)}
                    >
                        <img src={product.imageUrl} alt={product.name} className="w-full h-24 object-cover rounded-md mb-2 bg-gray-200" />
                        <div className="flex-grow flex flex-col justify-center">
                            <h3 className="font-bold text-sm text-akoma-dark truncate group-hover:text-akoma-blue">{product.name}</h3>
                            <p className="text-akoma-blue font-semibold text-sm">{formatCurrency(product.price, product.baseCurrency)}</p>
                        </div>
                        <button 
                            onClick={(e) => { e.stopPropagation(); handleAddToCart(product); }} 
                            className="mt-2 w-full px-2 py-1 text-xs font-semibold text-white bg-akoma-blue rounded-md hover:bg-blue-700"
                        >
                            Add to Cart
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default WellnessStore;