import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { HealthSummary, Appointment, Prescription } from '../../../types';
import LabResultsView from './LabResultsView';
import { getDrugPurpose, explainHealthMetric } from '../../../services/geminiService';
import HealthTipsView from './HealthTipsView';
import ExplanationModal from './ExplanationModal';

const HealthSummaryCard: React.FC<{ summary: HealthSummary, onExplain: (summary: HealthSummary) => void }> = ({ summary, onExplain }) => {
    const statusColor = {
        normal: 'text-akoma-green',
        high: 'text-red-500',
        low: 'text-yellow-500',
    };
    return (
        <div className="p-4 bg-gray-50 rounded-lg text-center flex flex-col justify-between">
            <div>
                <p className="text-sm text-akoma-grey">{summary.metric}</p>
                <p className={`text-2xl font-bold ${statusColor[summary.status]}`}>{summary.value}</p>
            </div>
            <button onClick={() => onExplain(summary)} className="text-xs font-semibold text-akoma-blue hover:underline mt-2">
                Explain this
            </button>
        </div>
    );
};

const AppointmentCard: React.FC<{ appointment: Appointment }> = ({ appointment }) => (
    <div className="p-3 bg-gray-50 rounded-lg border">
        <p className="font-semibold text-akoma-dark">{appointment.specialty}</p>
        <p className="text-sm text-akoma-dark">with {appointment.doctor}</p>
        <p className="text-sm text-akoma-grey mt-1">{new Date(appointment.date + 'T00:00:00').toDateString()} at {appointment.time}</p>
    </div>
);

const PrescriptionCard: React.FC<{ prescription: Prescription, t: any }> = ({ prescription, t }) => {
    const [purpose, setPurpose] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleShowPurpose = async () => {
        setIsLoading(true);
        const p = await getDrugPurpose(prescription.drug);
        setPurpose(p);
        setIsLoading(false);
    };

    return (
        <div className="p-3 bg-gray-50 rounded-lg border">
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-semibold text-akoma-dark">{prescription.drug}</p>
                    <p className="text-sm text-akoma-grey">{prescription.dosage}</p>
                </div>
                <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${prescription.dispensed ? 'bg-akoma-light-green text-akoma-green' : 'bg-yellow-100 text-yellow-800'}`}>
                    {prescription.dispensed ? 'Dispensed' : 'Pending'}
                </span>
            </div>
            {purpose ? (
                <p className="text-xs text-akoma-dark mt-2 bg-akoma-light-blue p-2 rounded-md">{purpose}</p>
            ) : (
                <button onClick={handleShowPurpose} disabled={isLoading} className="text-xs font-semibold text-akoma-blue hover:underline mt-2">
                    {isLoading ? 'Loading...' : t.patientHub.whatIsThisFor}
                </button>
            )}
        </div>
    );
};

const DoctorNoteCard: React.FC<{t: any}> = ({t}) => {
    const { patientData } = useApp();
    const notes = patientData?.doctorNotes || [];

    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-bold text-akoma-blue mb-4 text-lg">{t.patientHub.doctorsNotes}</h3>
            {notes.length > 0 ? (
                 <div className="space-y-3 max-h-60 overflow-y-auto">
                    {notes.slice().reverse().map((note, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg text-sm text-akoma-dark whitespace-pre-wrap leading-relaxed">
                            {note}
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-4">
                    <p className="text-akoma-grey">{t.patientHub.noNewNotes}</p>
                </div>
            )}
        </div>
    )
}

const PatientDashboardView: React.FC = () => {
    const { patientData, user, t } = useApp();
    const [explanation, setExplanation] = useState('');
    const [explanationTitle, setExplanationTitle] = useState('');
    const [isExplanationLoading, setIsExplanationLoading] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleExplainMetric = async (summary: HealthSummary) => {
        setExplanationTitle(summary.metric);
        setIsModalOpen(true);
        setIsExplanationLoading(true);
        setExplanation('');
        const exp = await explainHealthMetric(summary.metric, summary.value, summary.status);
        setExplanation(exp);
        setIsExplanationLoading(false);
    }
    
    const closeModal = () => {
        setIsModalOpen(false);
        setExplanation('');
        setExplanationTitle('');
    };

    if (!patientData) {
        return <div className="p-8 text-center text-akoma-grey">Loading patient data...</div>;
    }

    return (
        <div className="space-y-6">
            {isModalOpen && (
                <ExplanationModal
                    title={explanationTitle}
                    explanation={explanation}
                    isLoading={isExplanationLoading}
                    onClose={closeModal}
                />
            )}
            <h2 className="text-3xl font-bold text-akoma-dark">{t.patientHub.welcomeBack.replace('{name}', user?.name.split(' ')[0] || '')}</h2>
            
            {/* Health Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {patientData.healthSummary.map(summary => (
                    <HealthSummaryCard key={summary.metric} summary={summary} onExplain={handleExplainMetric} />
                ))}
                 <div className="p-4 bg-gray-50 rounded-lg text-center">
                    <p className="text-sm text-akoma-grey">{t.patientHub.lastVisit}</p>
                    <p className="text-2xl font-bold text-akoma-dark">{new Date(patientData.lastVisit + 'T00:00:00').toLocaleDateString()}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                     {/* Appointments */}
                    <div className="bg-white p-6 rounded-lg shadow-sm border">
                        <h3 className="font-bold text-akoma-blue mb-4 text-lg">{t.patientHub.upcomingAppointments}</h3>
                        <div className="space-y-3">
                            {patientData.appointments.filter(a => a.status === 'booked').map(apt => (
                                <AppointmentCard key={apt.id} appointment={apt} />
                            ))}
                        </div>
                    </div>

                    {/* Prescriptions */}
                    <div className="bg-white p-6 rounded-lg shadow-sm border">
                        <h3 className="font-bold text-akoma-blue mb-4 text-lg">{t.patientHub.myPrescriptions}</h3>
                        <div className="space-y-3">
                            {patientData.prescriptions.map(pre => (
                                <PrescriptionCard key={pre.id} prescription={pre} t={t} />
                            ))}
                        </div>
                    </div>

                    {/* Lab Results */}
                    <LabResultsView />
                    {/* Imaging Results Placeholder */}
                    <div className="bg-white p-6 rounded-lg shadow-sm border">
                        <h3 className="font-bold text-akoma-blue mb-4 text-lg">{t.patientHub.imagingResults}</h3>
                        <div className="text-center py-4">
                            <p className="text-akoma-grey">{t.patientHub.imagingPlaceholder}</p>
                        </div>
                    </div>
                </div>
                <div className="lg:col-span-1 space-y-6">
                    <DoctorNoteCard t={t} />
                    <HealthTipsView />
                </div>
            </div>

        </div>
    );
};

export default PatientDashboardView;
