import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';

const ReminderModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { addReminder } = useApp();
    const [medicationName, setMedicationName] = useState('');
    const [dosage, setDosage] = useState('');
    const [times, setTimes] = useState<string[]>(['09:00']);
    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";


    const handleTimeChange = (index: number, value: string) => {
        const newTimes = [...times];
        newTimes[index] = value;
        setTimes(newTimes);
    };

    const addTime = () => setTimes([...times, '']);
    const removeTime = (index: number) => setTimes(times.filter((_, i) => i !== index));

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!medicationName.trim() || !dosage.trim() || times.some(t => !t)) {
            alert('Please fill all fields correctly.');
            return;
        }
        addReminder({
            medicationName,
            dosage,
            times,
        });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Add Medication Reminder</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Medication Name</label>
                        <input
                            type="text"
                            value={medicationName}
                            onChange={e => setMedicationName(e.target.value)}
                            className={`mt-1 ${inputClasses}`}
                            placeholder="e.g., Lisinopril"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Dosage</label>
                        <input
                            type="text"
                            value={dosage}
                            onChange={e => setDosage(e.target.value)}
                            className={`mt-1 ${inputClasses}`}
                            placeholder="e.g., 1 tablet, 10mg"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark mb-2">Reminder Times</label>
                        <div className="space-y-2">
                            {times.map((time, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                    <input
                                        type="time"
                                        value={time}
                                        onChange={e => handleTimeChange(index, e.target.value)}
                                        className={inputClasses}
                                        required
                                    />
                                    {times.length > 1 && (
                                        <button type="button" onClick={() => removeTime(index)} className="p-2 text-gray-400 hover:text-red-600 rounded-full">
                                            &#x2715;
                                        </button>
                                    )}
                                </div>
                            ))}
                        </div>
                        <button type="button" onClick={addTime} className="mt-2 text-sm font-semibold text-akoma-blue hover:underline">
                            + Add another time
                        </button>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Save Reminder</button>
                </footer>
            </form>
        </div>
    );
};

export default ReminderModal;