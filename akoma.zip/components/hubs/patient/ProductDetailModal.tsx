import React from 'react';
import { Product } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

const ProductDetailModal: React.FC<{ product: Product, onClose: () => void }> = ({ product, onClose }) => {
    const { addToCart, toggleCart, isCartOpen, formatCurrency } = useApp();

    const handleAddToCart = () => {
        addToCart(product);
        if (!isCartOpen) {
          toggleCart();
        }
        onClose();
    }
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <header className="p-6 border-b flex justify-between items-center">
                    <h3 className="text-xl font-bold text-akoma-blue">{product.name}</h3>
                    <button onClick={onClose} className="text-2xl">&times;</button>
                </header>
                <main className="p-6">
                    <img src={product.imageUrl} alt={product.name} className="w-full h-64 object-cover rounded-md mb-4" />
                    <p className="text-akoma-grey">{product.description}</p>
                    <p className="text-2xl font-bold mt-4 text-akoma-dark">{formatCurrency(product.price, product.baseCurrency)}</p>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end">
                    <button onClick={handleAddToCart} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Add to Cart</button>
                </footer>
            </div>
        </div>
    );
};

export default ProductDetailModal;
