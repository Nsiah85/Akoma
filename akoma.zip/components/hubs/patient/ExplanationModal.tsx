import React, { useEffect } from 'react';
import { useTextToSpeech } from '../../../hooks/useTextToSpeech';
import { SpeakerPlayIcon, SpeakerStopIcon } from '../../icons/SpeakerIcon';

interface ExplanationModalProps {
    title: string;
    explanation: string;
    isLoading: boolean;
    onClose: () => void;
}

const ExplanationModal: React.FC<ExplanationModalProps> = ({ title, explanation, isLoading, onClose }) => {
    const { speak, cancel, isSpeaking } = useTextToSpeech();

    useEffect(() => {
        // Stop speech when modal is closed
        return () => {
            cancel();
        };
    }, [cancel]);
    
    const handleReadAloud = () => {
        if (isSpeaking) {
            cancel();
        } else if (!isLoading && explanation) {
            speak(explanation);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <header className="p-4 border-b flex justify-between items-center flex-shrink-0">
                    <h3 className="text-lg font-bold text-akoma-blue">Understanding Your Result: {title}</h3>
                    <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600 rounded-full">&times;</button>
                </header>
                <main className="p-6 overflow-y-auto">
                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-48">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-akoma-blue"></div>
                            <p className="mt-4 text-akoma-grey">akoma AI is preparing your explanation...</p>
                        </div>
                    ) : (
                        <p className="text-akoma-dark whitespace-pre-wrap leading-relaxed">{explanation}</p>
                    )}
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex-shrink-0 flex justify-between items-center border-t">
                    <button 
                        onClick={handleReadAloud}
                        disabled={isLoading || !explanation}
                        className="flex items-center px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {isSpeaking ? <SpeakerStopIcon className="w-5 h-5 mr-2" /> : <SpeakerPlayIcon className="w-5 h-5 mr-2" />}
                        {isSpeaking ? 'Stop Reading' : 'Read Aloud'}
                    </button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">Close</button>
                </footer>
            </div>
        </div>
    );
};

export default ExplanationModal;