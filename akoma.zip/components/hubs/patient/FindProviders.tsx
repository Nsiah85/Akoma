
import React, { useState, useMemo } from 'react';
import { Provider, Availability } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

// Mock availability for providers who don't have it
const generateMockAvailability = (): Availability => {
    const availability: Availability = {};
    const today = new Date();
    for (let i = 0; i < 30; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        const dateString = date.toISOString().split('T')[0];
        
        // Make some days unavailable
        if (i % 4 === 0) continue;

        availability[dateString] = {
            capacity: 5,
            slots: [
                { time: '09:00 AM' }, { time: '10:00 AM' }, { time: '11:00 AM' }, { time: '02:00 PM' }, { time: '03:00 PM' }
            ]
        };
    }
    // Simulate some booked slots
    const firstAvailableDate = Object.keys(availability)[0];
    if(availability[firstAvailableDate] && availability[firstAvailableDate].slots.length > 0) {
        availability[firstAvailableDate].slots[0].bookedBy = 'p002';
    }
    return availability;
}

const BookingModal: React.FC<{ provider: Provider, onClose: () => void }> = ({ provider, onClose }) => {
    const { t, addNotification, addToast } = useApp();
    const [step, setStep] = useState(1);
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const [selectedTime, setSelectedTime] = useState<string | null>(null);

    // Use mock availability if none is provided
    const availability = provider.availability || generateMockAvailability();
    const today = new Date().toISOString().split('T')[0];

    const handleDateSelect = (date: string) => {
        setSelectedDate(date);
        setSelectedTime(null);
        setStep(2);
    }
    
    const handleConfirmBooking = () => {
        // Fix: Replaced string argument with an object to match the function's expected type.
        addNotification({ title: 'Appointment Confirmed', message: `Your appointment with ${provider.name} on ${selectedDate} at ${selectedTime} is confirmed!`, type: 'system' });
        addToast({ message: `Appointment with ${provider.name} confirmed!`, type: 'success' });
        onClose();
    }

    const renderDay = (date: Date) => {
        const dateString = date.toISOString().split('T')[0];
        const dayData = availability[dateString];
        const isPast = dateString < today;
        const isAvailable = dayData && !isPast;
        
        let statusClass = 'bg-gray-100 text-gray-400';
        if (isAvailable) {
            const bookedSlots = dayData.slots.filter(s => s.bookedBy).length;
            if (bookedSlots === dayData.capacity) statusClass = 'bg-red-200 text-red-600';
            else if (bookedSlots > 0) statusClass = 'bg-yellow-200 text-yellow-800';
            else statusClass = 'bg-green-200 text-green-800 hover:bg-akoma-blue hover:text-white';
        }
        
        return (
            <button key={dateString} disabled={!isAvailable} onClick={() => isAvailable && handleDateSelect(dateString)} className={`w-10 h-10 flex items-center justify-center rounded-full transition-colors text-sm ${statusClass}`}>
                {date.getDate()}
            </button>
        )
    }

    const calendarDays = () => {
        const days = [];
        const monthStart = new Date();
        monthStart.setDate(1);
        const monthEnd = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);
        
        for(let i=0; i < monthStart.getDay(); i++) {
            days.push(<div key={`empty-${i}`} className="w-10 h-10"></div>);
        }

        for (let i = 1; i <= monthEnd.getDate(); i++) {
            days.push(renderDay(new Date(monthStart.getFullYear(), monthStart.getMonth(), i)));
        }
        return days;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                 <header className="p-6 border-b flex justify-between items-center">
                    <h3 className="text-xl font-bold text-akoma-blue">Book with {provider.name}</h3>
                    <button onClick={onClose} className="text-2xl">&times;</button>
                </header>
                <main className="p-6">
                    {step === 1 && (
                        <div>
                            <h4 className="font-semibold mb-4 text-center">Select an available date</h4>
                            <div className="flex justify-between items-center mb-2 px-2">
                                <span className="font-bold text-lg">{new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}</span>
                            </div>
                            <div className="grid grid-cols-7 gap-2 text-center text-xs text-akoma-grey mb-2">
                                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => <div key={d}>{d}</div>)}
                            </div>
                            <div className="grid grid-cols-7 gap-2">
                                {calendarDays()}
                            </div>
                        </div>
                    )}
                    {step === 2 && selectedDate && (
                        <div>
                             <button onClick={() => setStep(1)} className="text-sm text-akoma-blue mb-4">&larr; Back to calendar</button>
                             <h4 className="font-semibold mb-4 text-center">Select an available time for {new Date(selectedDate + 'T00:00:00').toDateString()}</h4>
                             <div className="grid grid-cols-3 gap-3">
                                {availability[selectedDate].slots.map(slot => (
                                    <button 
                                        key={slot.time}
                                        disabled={!!slot.bookedBy}
                                        onClick={() => setSelectedTime(slot.time)}
                                        className={`p-3 rounded-md text-sm font-semibold transition-colors ${
                                            slot.bookedBy ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 
                                            selectedTime === slot.time ? 'bg-akoma-blue text-white' : 'bg-gray-100 hover:bg-akoma-light-blue'
                                        }`}
                                    >
                                        {slot.time}
                                    </button>
                                ))}
                             </div>
                        </div>
                    )}
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end">
                    <button onClick={handleConfirmBooking} disabled={!selectedTime} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700 disabled:bg-gray-400">
                        Confirm Booking
                    </button>
                </footer>
            </div>
        </div>
    );
};


const FindProviders: React.FC = () => {
    const { t, providers } = useApp();
    const [searchTerm, setSearchTerm] = useState('');
    const [location, setLocation] = useState('');
    const [bookingProvider, setBookingProvider] = useState<Provider | null>(null);

    const locations = useMemo(() => [...new Set(providers.map(p => p.location))], [providers]);

    const filteredProviders = providers.filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              p.specialty.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesLocation = location ? p.location.toLowerCase() === location.toLowerCase() : true;
        return matchesSearch && matchesLocation;
    });

    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
        <div>
            {bookingProvider && <BookingModal provider={bookingProvider} onClose={() => setBookingProvider(null)} />}
            <h2 className="text-2xl font-bold text-akoma-dark mb-4">{t.common.findProviders}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <input
                    type="text"
                    placeholder="Search by name or specialty..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className={inputClasses}
                />
                 <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className={inputClasses}
                >
                    <option value="">All Locations</option>
                    {locations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                </select>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {filteredProviders.map(provider => (
                    <div key={provider.id} className="bg-gray-50 border rounded-lg p-2 flex flex-col text-center">
                        <h3 className="font-bold text-sm text-akoma-dark truncate">{provider.name}</h3>
                        <p className="text-akoma-blue font-semibold text-xs truncate">{provider.specialty}</p>
                        <p className="text-xs text-akoma-grey mt-0.5">{provider.location}</p>
                        <div className="flex-grow"></div>
                        <button 
                            onClick={() => setBookingProvider(provider)} 
                            disabled={!provider.available} 
                            className="mt-2 w-full px-2 py-1 text-xs font-semibold text-white bg-akoma-blue rounded-md disabled:bg-gray-400"
                        >
                            {provider.available ? 'Book' : 'Unavailable'}
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default FindProviders;
