import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { LabResult } from '../../../types';
import { explainMedicalTermInLaymanTerms } from '../../../services/geminiService';
import ExplanationModal from './ExplanationModal';

const LabResultsView: React.FC = () => {
    const { patientData } = useApp();
    const [selectedResult, setSelectedResult] = useState<LabResult | null>(null);
    const [explanation, setExplanation] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleExplainClick = async (result: LabResult) => {
        setSelectedResult(result);
        setIsLoading(true);
        setExplanation('');
        const exp = await explainMedicalTermInLaymanTerms(result.testName, result.scientificExplanation);
        setExplanation(exp);
        setIsLoading(false);
    };
    
    const closeModal = () => {
        setSelectedResult(null);
        setExplanation('');
    };

    if (!patientData || !patientData.labResults.length) {
        return null; 
    }

    return (
        <>
            {selectedResult && (
                <ExplanationModal 
                    title={selectedResult.testName}
                    explanation={explanation}
                    isLoading={isLoading}
                    onClose={closeModal}
                />
            )}
            <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="font-bold text-akoma-blue mb-4 text-lg">Recent Lab Results</h3>
                <ul className="space-y-3">
                    {patientData.labResults.map(result => (
                        <li key={result.id} className="p-3 bg-gray-50 rounded-md border">
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-semibold text-akoma-dark">{result.testName}</p>
                                    <p className="text-xs text-akoma-grey">{new Date(result.date + 'T00:00:00').toDateString()}</p>
                                </div>
                                <button
                                    onClick={() => handleExplainClick(result)}
                                    className="text-xs font-semibold text-akoma-blue hover:underline whitespace-nowrap px-3 py-1 bg-akoma-light-blue rounded-full"
                                >
                                    Explain this
                                </button>
                            </div>
                            <p className="text-sm text-akoma-dark mt-2 italic">"{result.scientificExplanation}"</p>
                        </li>
                    ))}
                </ul>
            </div>
        </>
    );
};

export default LabResultsView;