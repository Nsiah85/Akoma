import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { generateHealthTips } from '../../../services/geminiService';
import { HealthTip, Patient } from '../../../types';

const HealthTipsView: React.FC = () => {
    const { patientData } = useApp();
    const [tips, setTips] = useState<HealthTip[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleFetchTips = async () => {
        if (!patientData) return;
        setIsLoading(true);
        setError('');
        setTips([]);
        try {
            const fetchedTips = await generateHealthTips(patientData as Patient);
            setTips(fetchedTips);
        } catch (err) {
            setError('Sorry, we couldn\'t fetch your tips right now. Please try again later.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-bold text-akoma-blue mb-4 text-lg">AI Health Tips for You</h3>
            {tips.length > 0 ? (
                <div className="space-y-4">
                    {tips.map((tip, index) => (
                        <div key={index} className="p-3 bg-akoma-light-green rounded-md border border-green-200">
                            <p className="font-semibold text-akoma-green">{tip.title}</p>
                            <p className="text-sm text-green-800">{tip.tip}</p>
                        </div>
                    ))}
                    <button
                        onClick={handleFetchTips}
                        disabled={isLoading}
                        className="text-xs font-semibold text-akoma-blue hover:underline mt-2"
                    >
                        {isLoading ? 'Refreshing...' : 'Get new tips'}
                    </button>
                </div>
            ) : (
                <div className="text-center py-4">
                    <p className="text-akoma-grey mb-3">Get personalized wellness tips from Akoma AI to help you on your health journey.</p>
                    <button
                        onClick={handleFetchTips}
                        disabled={isLoading}
                        className="px-4 py-2 text-sm font-medium text-white bg-akoma-green rounded-md hover:bg-green-700 disabled:bg-gray-400"
                    >
                        {isLoading ? 'Generating...' : 'Get My Health Tips'}
                    </button>
                    {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                </div>
            )}
        </div>
    );
};

export default HealthTipsView;