import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import ReminderModal from './ReminderModal';
import { BellIcon } from '../../icons/BellIcon';
import { TrashIcon } from '../../icons/TrashIcon';

const MedicationReminders: React.FC = () => {
    const { reminders, deleteReminder } = useApp();
    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <div>
            {isModalOpen && <ReminderModal onClose={() => setIsModalOpen(false)} />}
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-akoma-dark">Medication Reminders</h2>
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700"
                >
                    Add Reminder
                </button>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border">
                {reminders.length > 0 ? (
                    <ul className="space-y-4">
                        {reminders.map(reminder => (
                            <li key={reminder.id} className="p-4 bg-gray-50 rounded-md border flex justify-between items-start">
                                <div>
                                    <p className="font-bold text-akoma-dark">{reminder.medicationName}</p>
                                    <p className="text-sm text-akoma-grey">{reminder.dosage}</p>
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        {reminder.times.map(time => (
                                            <span key={time} className="text-xs bg-akoma-light-blue text-akoma-blue font-semibold px-2 py-1 rounded-full">
                                                {time}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                                <button
                                    onClick={() => deleteReminder(reminder.id)}
                                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-100 rounded-full"
                                    aria-label="Delete reminder"
                                >
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="text-center text-akoma-grey py-8">
                        <BellIcon className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                        <p>You have no medication reminders set.</p>
                        <p className="text-sm">Click "Add Reminder" to get started.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MedicationReminders;
