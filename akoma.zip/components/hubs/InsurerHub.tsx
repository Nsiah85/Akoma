
import React from 'react';
import { useApp } from '../../contexts/AppContext';
import { MOCK_INSURANCE_CLAIMS } from '../../constants';
import { InsuranceClaim } from '../../types';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 ${className}`}>
      <h3 className="text-xl font-bold text-akoma-blue mb-4">{title}</h3>
      {children}
    </div>
);

type Tab = 'dashboard' | 'find-providers' | 'wellness-store' | 'settings';

const InsurerHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab, activateInsuranceClaim, addNotification, addToast } = useApp();
    const claims: InsuranceClaim[] = MOCK_INSURANCE_CLAIMS;
    
    const handleRequestDocs = (patientName: string) => {
        // Fix: Replaced string argument with an object to match the function's expected type.
        addNotification({ title: 'Document Request', message: `Please upload the required documents for your claim, requested by your insurer.`, type: 'user' });
        addToast({ message: `A document request has been sent to ${patientName}.`, type: 'info' });
    };

    const renderContent = () => {
        switch (activeHubTab) {
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                if (window.innerWidth < 768 && !['dashboard', 'settings'].includes(activeHubTab)) {
                    setActiveHubTab('dashboard');
                }
                return (
                     <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2">
                             <Card title="Insurance Claims">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="bg-gray-50">
                                            <tr className="border-b">
                                                <th className="p-3">Patient</th>
                                                <th className="p-3">Policy</th>
                                                <th className="p-3">Status</th>
                                                <th className="p-3">Activated</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {claims.map(claim => (
                                                <tr key={claim.id} className="border-b last:border-0 hover:bg-gray-50">
                                                    <td className="p-3 font-medium">{claim.patientName}</td>
                                                    <td className="p-3">{claim.policyNumber}</td>
                                                    <td className="p-3">
                                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                                            claim.status === 'Approved' ? 'bg-akoma-light-green text-akoma-green' 
                                                            : claim.status === 'Processing' ? 'bg-yellow-100 text-yellow-800'
                                                            : claim.status === 'Denied' ? 'bg-red-100 text-red-700'
                                                            : 'bg-blue-100 text-akoma-blue'
                                                        }`}>{claim.status}</span>
                                                    </td>
                                                     <td className="p-3">
                                                        {claim.isActivated ? 'Yes' : 'No'}
                                                     </td>
                                                    <td className="p-3 text-right">
                                                        {!claim.isActivated && (
                                                            <button onClick={() => activateInsuranceClaim(claim.id)} className="text-sm font-semibold text-akoma-blue hover:underline">Activate</button>
                                                        )}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </Card>
                        </div>
                         <div>
                            <Card title="Quick Actions">
                                <button onClick={() => handleRequestDocs('Ama Serwaa')} className="w-full text-left p-3 bg-akoma-light-blue text-akoma-blue font-semibold rounded-lg hover:bg-blue-200 transition-colors">
                                    Request Documents
                                </button>
                            </Card>
                        </div>
                    </div>
                );
        }
    };

    const TabButton: React.FC<{ tabName: Tab; label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >{label}</button>
    );


    return (
        <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">Insurance Claims Dashboard</h2>
            <div className="mb-6 bg-white p-2 rounded-lg shadow-sm inline-flex space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            {renderContent()}
        </div>
    );
};

export default InsurerHub;
