
import React from 'react';
// Fix: Corrected import from '../../../contexts/AppContext'
import { useApp } from '../../../contexts/AppContext';
// Fix: Corrected import from '../../../types'
import { Vendor } from '../../../types';

const VendorApplicationModal: React.FC<{ vendor: Vendor, onClose: () => void }> = ({ vendor, onClose }) => {
    const { t } = useApp();

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Review Vendor Application</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <p className="text-sm font-medium text-akoma-grey">Vendor Name</p>
                        <p className="font-semibold text-akoma-dark">{vendor.name}</p>
                    </div>
                    <div>
                        <p className="text-sm font-medium text-akoma-grey">Specialty</p>
                        <p className="text-akoma-dark">{vendor.specialty}</p>
                    </div>
                     <div>
                        <p className="text-sm font-medium text-akoma-grey">Date Applied</p>
                        <p className="text-akoma-dark">{vendor.dateApplied}</p>
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.close}</button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">Reject</button>
                    <button onClick={onClose} className="px-4 py-2 text-sm font-medium text-white bg-akoma-green rounded-md hover:bg-green-700">Approve</button>
                </footer>
            </div>
        </div>
    );
};

export default VendorApplicationModal;
