
import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { User, UserRole } from '../../../types';
import ThemeSettings from '../shared/ThemeSettings';

const SettingsToggle: React.FC<{ label: string; description: string; enabled: boolean; }> = ({ label, description, enabled }) => (
    <div className="flex justify-between items-center py-4 border-b">
        <div>
            <p className="font-medium text-akoma-dark">{label}</p>
            <p className="text-sm text-akoma-grey">{description}</p>
        </div>
        <div className={`w-12 h-6 rounded-full p-1 cursor-pointer ${enabled ? 'bg-akoma-blue' : 'bg-gray-300'}`}>
            <div className={`w-4 h-4 rounded-full bg-white transform transition-transform ${enabled ? 'translate-x-6' : ''}`}></div>
        </div>
    </div>
);


const AdminSettingsView: React.FC = () => {
    const { user, updateUserProfile, updateUserPassword, t, emergencyContacts, updateEmergencyContact, addToast } = useApp();
    
    // Profile State
    const [name, setName] = useState(user?.name || '');
    const [previewUrl, setPreviewUrl] = useState<string | null>(user?.profileImageUrl || null);
    const [profileSuccess, setProfileSuccess] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // Password State
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [passwordSuccess, setPasswordSuccess] = useState('');
    
    // Emergency Contacts State
    const [localEmergencyContacts, setLocalEmergencyContacts] = useState(emergencyContacts);

    useEffect(() => {
        if (profileSuccess) {
            const timer = setTimeout(() => setProfileSuccess(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [profileSuccess]);

    useEffect(() => {
        if (passwordSuccess) {
            const timer = setTimeout(() => setPasswordSuccess(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [passwordSuccess]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleProfileSave = () => {
        updateUserProfile({ name, profileImageUrl: previewUrl || undefined });
        setProfileSuccess('Profile updated successfully!');
    };
    
    const handlePasswordChange = (e: React.FormEvent) => {
        e.preventDefault();
        setPasswordError('');
        setPasswordSuccess('');
        if (newPassword !== confirmPassword) {
            setPasswordError('New passwords do not match.');
            return;
        }
        const result = updateUserPassword({ current: currentPassword, new: newPassword });
        if (result.success) {
            setPasswordSuccess(result.message);
            setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
        } else {
            setPasswordError(result.message);
        }
    };

    const handleEmergencyContactChange = (code: string, number: string) => {
        setLocalEmergencyContacts(prev => ({
            ...prev,
            [code]: { ...prev[code], number }
        }));
    };

    const handleEmergencySave = () => {
        Object.entries(localEmergencyContacts).forEach(([code, contact]) => {
            updateEmergencyContact(code, contact.number);
        });
        addToast({ message: 'Emergency contacts updated successfully!', type: 'success' });
    };

    const inputClasses = "w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";
    const disabledInputClasses = "w-full p-2 border rounded-md bg-gray-700 text-gray-400 border-akoma-grey cursor-not-allowed";


    return (
        <div>
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">Settings</h2>
            <div className="space-y-6">
                <div className="bg-white p-6 rounded-lg shadow-sm border">
                    <h3 className="text-lg font-bold text-akoma-blue mb-4">My Profile</h3>
                    <div className="flex items-center space-x-4 mb-4">
                        {previewUrl ? <img src={previewUrl} alt="Profile" className="w-20 h-20 rounded-full object-cover" /> : <div className="w-20 h-20 rounded-full bg-akoma-light-blue text-akoma-blue flex items-center justify-center text-3xl font-bold">{name.charAt(0)}</div>}
                        <div>
                            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                            <button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 text-sm font-medium text-akoma-blue bg-white border border-akoma-blue rounded-md hover:bg-gray-50">Upload Picture</button>
                        </div>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-akoma-dark mb-1">{t.common.name}</label>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={inputClasses} />
                    </div>
                     <div className="mt-4">
                        <label className="block text-sm font-medium text-akoma-dark mb-1">Email</label>
                        <input type="email" value={user?.email || ''} disabled className={disabledInputClasses} />
                    </div>
                    <div className="mt-6 border-t pt-4 flex justify-end items-center space-x-4">
                        {profileSuccess && <p className="text-sm text-akoma-green animate-fade-in-fast">{profileSuccess}</p>}
                        <button onClick={handleProfileSave} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.settings.saveChanges}</button>
                    </div>
                </div>

                <form onSubmit={handlePasswordChange} className="bg-white p-6 rounded-lg shadow-sm border">
                    <h3 className="text-lg font-bold text-akoma-blue mb-4">Change Password</h3>
                    <div className="space-y-4">
                        <div><label className="block text-sm font-medium text-akoma-dark mb-1">Current Password</label><input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className={inputClasses} required/></div>
                        <div><label className="block text-sm font-medium text-akoma-dark mb-1">New Password</label><input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className={inputClasses} required/></div>
                        <div><label className="block text-sm font-medium text-akoma-dark mb-1">Confirm New Password</label><input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className={inputClasses} required/></div>
                    </div>
                    <div className="mt-6 border-t pt-4 flex justify-end items-center space-x-4">
                        {passwordError && <p className="text-sm text-red-600 animate-fade-in-fast">{passwordError}</p>}
                        {passwordSuccess && <p className="text-sm text-akoma-green animate-fade-in-fast">{passwordSuccess}</p>}
                        <button type="submit" className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Update Password</button>
                    </div>
                </form>

                 <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-bold text-akoma-blue mb-4">Emergency Contact Management</h3>
                    <div className="space-y-3">
                        {Object.entries(localEmergencyContacts).map(([code, contact]) => (
                            <div key={code} className="flex items-center space-x-4">
                                <label className="w-32 text-sm font-medium text-akoma-dark">{contact.name}</label>
                                <input type="text" value={contact.number} onChange={(e) => handleEmergencyContactChange(code, e.target.value)} className={inputClasses} />
                            </div>
                        ))}
                    </div>
                    <div className="mt-6 border-t pt-4 flex justify-end">
                        <button onClick={handleEmergencySave} className="px-6 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">Save Emergency Numbers</button>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-bold text-akoma-blue mb-2">System Configuration</h3>
                    <SettingsToggle label="Maintenance Mode" description="Temporarily disable access for non-admin users." enabled={false} />
                    <SettingsToggle label="New User Registrations" description="Allow or disallow new users to sign up." enabled={true} />
                    <SettingsToggle label="Enable AI Assistant" description="Turn the Akoma AI Assistant on or off for all patients." enabled={true} />
                </div>
            </div>
        </div>
    );
};

export default AdminSettingsView;
