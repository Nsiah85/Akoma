
import React, { useState } from 'react';
import { PayoutAccount } from '../../../types';
import EditPayoutAccountModal from './EditPayoutAccountModal';
import { useApp } from '../../../contexts/AppContext';
import AddPayoutMethodModal from './AddPayoutMethodModal';
import { BankIcon, PaystackIcon, MomoIcon } from '../../icons/PayoutIcons';
import { TrashIcon } from '../../icons/TrashIcon';

const PayoutAccountCard: React.FC<{ account: PayoutAccount, onEdit: (account: PayoutAccount) => void, onDelete: (accountId: string) => void, onSetDefault: (account: PayoutAccount) => void, t: any }> = ({ account, onEdit, onDelete, onSetDefault, t }) => {
    
    const getIcon = () => {
        switch (account.type) {
            case 'bank': return <BankIcon className="w-6 h-6 text-akoma-blue" />;
            case 'paystack': return <PaystackIcon className="w-6 h-6" />;
            case 'momo': return <MomoIcon className="w-6 h-6 text-orange-500" />;
            default: return null;
        }
    };

    const getAccountDetails = () => {
        switch (account.type) {
            case 'bank': return `${account.accountHolder} - ${account.accountNumber}`;
            case 'paystack': return account.email;
            case 'momo': return `${account.provider} - ${account.phoneNumber}`;
        }
    }
    
    const getAccountTitle = () => {
        switch (account.type) {
            case 'bank': return account.bankName;
            case 'paystack': return 'Paystack';
            case 'momo': return 'Mobile Money';
        }
    }

    return (
        <div className="p-4 border rounded-md flex justify-between items-center">
            <div className="flex items-center space-x-4">
                {getIcon()}
                <div>
                    <p className="font-semibold">{getAccountTitle()} {account.isDefault && <span className="text-xs bg-akoma-light-green text-akoma-green font-bold px-2 py-0.5 rounded-full ml-2">{t.admin.payouts.default}</span>}</p>
                    <p className="text-sm text-akoma-grey">{getAccountDetails()}</p>
                </div>
            </div>
            <div className="flex items-center space-x-4">
                {account.type === 'bank' && (
                    <button onClick={() => onEdit(account)} className="text-sm font-semibold text-akoma-blue hover:underline">
                        {t.common.edit}
                    </button>
                )}
                {!account.isDefault && (
                    <button onClick={() => onSetDefault(account)} className="text-sm font-semibold text-akoma-blue hover:underline">
                        {t.admin.payouts.setAsDefault}
                    </button>
                )}
                <button onClick={() => onDelete(account.id)} className="p-1 text-gray-400 hover:text-red-600 rounded-full" title="Delete">
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    )
}


const AdminPayoutsView: React.FC = () => {
    const { t, payoutAccounts, updatePayoutAccount, deletePayoutAccount, showConfirmation } = useApp();
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [editingAccount, setEditingAccount] = useState<PayoutAccount | null>(null);

    const handleSetDefault = (account: PayoutAccount) => {
        updatePayoutAccount({ ...account, isDefault: true });
    };
    
    const handleDelete = (accountId: string) => {
        showConfirmation({
            title: 'Delete Payout Method',
            message: 'Are you sure you want to delete this payout method? This action cannot be undone.',
            onConfirm: () => deletePayoutAccount(accountId),
            confirmText: 'Delete',
        });
    };

    return (
        <div>
            {isAddModalOpen && <AddPayoutMethodModal onClose={() => setIsAddModalOpen(false)} />}
            {editingAccount && editingAccount.type === 'bank' && <EditPayoutAccountModal account={editingAccount} onClose={() => setEditingAccount(null)} />}
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-akoma-dark">{t.admin.payouts.title}</h2>
                <button onClick={() => setIsAddModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                    Add Payout Method
                </button>
            </div>
            <div className="bg-white rounded-lg shadow-sm border p-6">
                <h3 className="font-bold text-lg text-akoma-dark mb-4">{t.admin.payouts.payoutAccounts}</h3>
                <div className="space-y-4">
                    {payoutAccounts.map((account: PayoutAccount) => (
                        <PayoutAccountCard
                            key={account.id}
                            account={account}
                            onEdit={setEditingAccount}
                            onSetDefault={handleSetDefault}
                            onDelete={handleDelete}
                            t={t}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default AdminPayoutsView;
