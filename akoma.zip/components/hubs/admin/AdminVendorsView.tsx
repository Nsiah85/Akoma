
import React, { useState } from 'react';
import { MOCK_VENDORS } from '../../../constants';
import { Vendor } from '../../../types';
// Fix: Corrected the casing in the import statement to use PascalCase, resolving a file name casing conflict.
import VendorApplicationModal from './VendorApplicationModal';

const AdminVendorsView: React.FC = () => {
    const [vendors] = useState<Vendor[]>(MOCK_VENDORS.map(v => ({...v, applicationStatus: v.applicationStatus || 'Approved', dateApplied: v.dateApplied || '2024-05-10'})));
    const [reviewingVendor, setReviewingVendor] = useState<Vendor | null>(null);

    return (
        <div>
             {reviewingVendor && <VendorApplicationModal vendor={reviewingVendor} onClose={() => setReviewingVendor(null)} />}
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">Vendor Management</h2>
            <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-4 font-semibold text-sm">Vendor Name</th>
                            <th className="p-4 font-semibold text-sm">Specialty</th>
                            <th className="p-4 font-semibold text-sm">Date Applied</th>
                            <th className="p-4 font-semibold text-sm">Status</th>
                            <th className="p-4 font-semibold text-sm">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {vendors.map((vendor: Vendor) => (
                            <tr key={vendor.id} className="border-b last:border-0 hover:bg-gray-50">
                                <td className="p-4 font-medium">{vendor.name}</td>
                                <td className="p-4">{vendor.specialty}</td>
                                <td className="p-4 text-sm text-akoma-grey">{new Date(vendor.dateApplied).toLocaleDateString()}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                        vendor.applicationStatus === 'Approved' ? 'bg-akoma-light-green text-akoma-green' : 'bg-yellow-100 text-yellow-800'
                                    }`}>
                                        {vendor.applicationStatus}
                                    </span>
                                </td>
                                <td className="p-4">
                                    <button onClick={() => setReviewingVendor(vendor)} className="text-sm font-semibold text-akoma-blue hover:underline">
                                        {vendor.applicationStatus === 'Pending' ? 'Review' : 'View'}
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminVendorsView;