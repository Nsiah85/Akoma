import React, { useMemo } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { UserRole } from '../../../types';
import { UsersIcon, StoreIcon } from '../../icons/NavIcons';
import { BellIcon } from '../../icons/BellIcon';

const TrendUpIcon: React.FC = () => <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>;

const StatCard: React.FC<{ title: string; value: number | string; icon: React.ReactNode; trend?: React.ReactNode; trendText?: string }> = ({ title, value, icon, trend, trendText }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex items-start justify-between">
            <div>
                <p className="text-sm font-medium text-akoma-grey">{title}</p>
                <p className="text-3xl font-bold text-akoma-dark mt-1">{value}</p>
            </div>
            <div className="bg-akoma-light-blue text-akoma-blue p-3 rounded-full">
                {icon}
            </div>
        </div>
        {trend && (
            <div className="flex items-center text-xs text-akoma-grey mt-2">
                {trend}
                <span className="ml-1">{trendText}</span>
            </div>
        )}
    </div>
);

const AdminDashboardView: React.FC = () => {
    const { allUsers, activityLog } = useApp();

    const stats = useMemo(() => {
        return {
            totalUsers: allUsers.length,
            pendingApprovals: allUsers.filter(u => u.approvalStatus === 'Pending').length,
            activeVendors: allUsers.filter(u => u.role === UserRole.Vendor && u.approvalStatus === 'Approved').length,
            roleDistribution: allUsers.reduce((acc, user) => {
                acc[user.role] = (acc[user.role] || 0) + 1;
                return acc;
            }, {} as Record<UserRole, number>),
        };
    }, [allUsers]);

    const roleDistributionEntries = Object.entries(stats.roleDistribution).sort(([, a], [, b]) => b - a);
    const maxRoleCount = Math.max(...roleDistributionEntries.map(([, count]) => count), 1);
    
    const formatTimeAgo = (isoString: string) => {
        const date = new Date(isoString);
        const now = new Date();
        const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + " years ago";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + " months ago";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + " days ago";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + " hours ago";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + " minutes ago";
        return "just now";
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">Admin Dashboard</h2>
            {/* Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <StatCard title="Total Users" value={stats.totalUsers} icon={<UsersIcon className="w-6 h-6" />} trend={<TrendUpIcon />} trendText="+2 this week" />
                <StatCard title="Pending Approvals" value={stats.pendingApprovals} icon={<BellIcon className="w-6 h-6" />} />
                <StatCard title="Active Vendors" value={stats.activeVendors} icon={<StoreIcon className="w-6 h-6" />} trend={<TrendUpIcon />} trendText="+1 this month" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* User Role Distribution */}
                <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow-sm border">
                    <h3 className="text-lg font-bold text-akoma-blue mb-4">User Role Distribution</h3>
                    <div className="space-y-3">
                        {roleDistributionEntries.map(([role, count]) => (
                            <div key={role} className="flex items-center">
                                <span className="w-32 text-sm text-akoma-grey flex-shrink-0">{role}</span>
                                <div className="flex-1 bg-gray-200 rounded-full h-4">
                                    <div 
                                        className="bg-akoma-blue h-4 rounded-full text-white text-xs flex items-center justify-end pr-2"
                                        style={{ width: `${(count / maxRoleCount) * 100}%` }}
                                    >
                                        {count}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white p-6 rounded-lg shadow-sm border">
                    <h3 className="text-lg font-bold text-akoma-blue mb-4">Recent Activity</h3>
                    <ul className="space-y-4">
                        {activityLog.slice(0, 5).map(activity => (
                             <li key={activity.id} className="flex items-start">
                                <div className="w-2 h-2 bg-akoma-blue rounded-full mt-1.5 mr-3 flex-shrink-0"></div>
                                <div className="flex-1">
                                    <p className="text-sm text-akoma-dark">{activity.text}</p>
                                    <p className="text-xs text-akoma-grey">{formatTimeAgo(activity.timestamp)}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboardView;