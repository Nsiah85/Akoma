
import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { User } from '../../../types';
import AddUserModal from './AddUserModal';

const AdminUsersView: React.FC = () => {
    const { allUsers, updateUserStatus, deleteUser, t, showConfirmation } = useApp();
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    
    const handleStatusChange = (userId: string, newStatus: User['approvalStatus']) => {
        updateUserStatus(userId, newStatus);
    }

    const handleDelete = (userId: string) => {
        const userToDelete = allUsers.find(u => u.id === userId);
        if (!userToDelete) return;

        showConfirmation({
            title: 'Delete User',
            message: `Are you sure you want to permanently delete the user "${userToDelete.name}"? This action cannot be undone.`,
            onConfirm: () => deleteUser(userId),
            confirmText: 'Delete User',
        });
    }

    const getStatusColor = (status: User['approvalStatus']) => {
        switch(status) {
            case 'Approved': return 'bg-akoma-light-green text-akoma-green';
            case 'Pending': return 'bg-yellow-100 text-yellow-800';
            case 'Suspended': return 'bg-red-100 text-red-700';
            default: return 'bg-gray-100 text-akoma-grey';
        }
    }

    return (
        <div>
            {isAddModalOpen && <AddUserModal onClose={() => setIsAddModalOpen(false)} />}
            <div className="flex justify-between items-center mb-6">
                 <h2 className="text-3xl font-bold text-akoma-dark">{t.admin.userManagement.title}</h2>
                 <button onClick={() => setIsAddModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">
                    Add User
                </button>
            </div>
           
            <div className="bg-white rounded-lg shadow-sm border overflow-x-auto">
                <table className="w-full text-left min-w-[700px]">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="p-4 font-semibold text-sm">{t.common.name}</th>
                            <th className="p-4 font-semibold text-sm">{t.admin.userManagement.akomaId}</th>
                            <th className="p-4 font-semibold text-sm">{t.common.role}</th>
                            <th className="p-4 font-semibold text-sm">Date Joined</th>
                            <th className="p-4 font-semibold text-sm">{t.common.status}</th>
                            <th className="p-4 font-semibold text-sm">{t.admin.userManagement.actions}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {allUsers.map((user: User) => (
                            <tr key={user.id} className="border-b last:border-0 hover:bg-gray-50">
                                <td className="p-4 font-medium">{user.name}</td>
                                <td className="p-4 font-mono text-xs">{user.akomaId}</td>
                                <td className="p-4">{user.role}</td>
                                <td className="p-4 text-sm text-akoma-grey">{new Date(user.joinDate || Date.now()).toLocaleDateString()}</td>
                                <td className="p-4">
                                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(user.approvalStatus)}`}>
                                        {user.approvalStatus}
                                    </span>
                                </td>
                                <td className="p-4 space-x-2 whitespace-nowrap">
                                    {user.approvalStatus === 'Pending' && <button onClick={() => handleStatusChange(user.id, 'Approved')} className="text-sm font-semibold text-akoma-green hover:underline">{t.admin.userManagement.approve}</button>}
                                    {user.approvalStatus === 'Approved' && <button onClick={() => handleStatusChange(user.id, 'Suspended')} className="text-sm font-semibold text-yellow-600 hover:underline">{t.admin.userManagement.suspend}</button>}
                                    {user.approvalStatus === 'Suspended' && <button onClick={() => handleStatusChange(user.id, 'Approved')} className="text-sm font-semibold text-akoma-green hover:underline">{t.admin.userManagement.approve}</button>}
                                    <button onClick={() => handleDelete(user.id)} className="text-sm font-semibold text-red-600 hover:underline">{t.admin.userManagement.delete}</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminUsersView;
