import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { BankIcon, PaystackIcon, MomoIcon } from '../../icons/PayoutIcons';
import { MOCK_MOMO_PROVIDERS } from '../../../constants';

type PayoutType = 'bank' | 'paystack' | 'momo';

const AddPayoutMethodModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { t, addPayoutAccount, payoutAccounts } = useApp();
    const [step, setStep] = useState(1);
    const [payoutType, setPayoutType] = useState<PayoutType | null>(null);
    
    // Form state
    const [bankName, setBankName] = useState('');
    const [accountHolder, setAccountHolder] = useState('');
    const [accountNumber, setAccountNumber] = useState('');
    const [email, setEmail] = useState('');
    const [provider, setProvider] = useState(MOCK_MOMO_PROVIDERS[0]);
    const [phoneNumber, setPhoneNumber] = useState('');

    const inputClasses = "mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    const handleSelectType = (type: PayoutType) => {
        setPayoutType(type);
        setStep(2);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        const baseAccount = {
            isDefault: payoutAccounts.length === 0,
        };
        
        let newAccount;
        
        switch(payoutType) {
            case 'bank':
                if (!bankName || !accountHolder || !accountNumber) return;
                newAccount = { ...baseAccount, type: 'bank', bankName, accountHolder, accountNumber };
                break;
            case 'paystack':
                if (!email) return;
                newAccount = { ...baseAccount, type: 'paystack', email };
                break;
            case 'momo':
                if (!provider || !phoneNumber) return;
                newAccount = { ...baseAccount, type: 'momo', provider, phoneNumber };
                break;
            default:
                return;
        }

        addPayoutAccount(newAccount);
        onClose();
    };

    const renderStepOne = () => (
        <>
            <header className="p-6 border-b"><h3 className="text-xl font-bold text-akoma-blue">Add a Payout Method</h3></header>
            <main className="p-6 space-y-3">
                <button onClick={() => handleSelectType('bank')} className="w-full flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50">
                    <BankIcon className="w-8 h-8 text-akoma-blue" />
                    <span className="font-semibold">Bank Account</span>
                </button>
                <button onClick={() => handleSelectType('paystack')} className="w-full flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50">
                    <PaystackIcon className="w-8 h-8" />
                    <span className="font-semibold">Paystack</span>
                </button>
                 <button onClick={() => handleSelectType('momo')} className="w-full flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50">
                    <MomoIcon className="w-8 h-8 text-orange-500" />
                    <span className="font-semibold">Mobile Money</span>
                </button>
            </main>
            <footer className="px-6 py-4 bg-gray-50 flex justify-end">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
            </footer>
        </>
    );

    const renderStepTwo = () => (
        <form onSubmit={handleSubmit}>
            <header className="p-6 border-b">
                <h3 className="text-xl font-bold text-akoma-blue">
                    Add {payoutType === 'bank' ? 'Bank Account' : payoutType === 'paystack' ? 'Paystack' : 'Mobile Money'} Details
                </h3>
            </header>
            <main className="p-6 space-y-4">
                <button type="button" onClick={() => setStep(1)} className="text-sm text-akoma-blue mb-2">&larr; Back to methods</button>
                {payoutType === 'bank' && (
                    <>
                         <div>
                            <label className="block text-sm font-medium text-akoma-dark">{t.admin.payouts.bankName}</label>
                            <input type="text" value={bankName} onChange={e => setBankName(e.target.value)} required className={inputClasses}/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-akoma-dark">{t.admin.payouts.accountHolder}</label>
                            <input type="text" value={accountHolder} onChange={e => setAccountHolder(e.target.value)} required className={inputClasses}/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-akoma-dark">{t.admin.payouts.accountNumber}</label>
                            <input type="text" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} required className={inputClasses}/>
                        </div>
                    </>
                )}
                {payoutType === 'paystack' && (
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Paystack Email</label>
                        <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className={inputClasses}/>
                    </div>
                )}
                {payoutType === 'momo' && (
                     <>
                        <div>
                            <label className="block text-sm font-medium text-akoma-dark">Provider</label>
                            <select value={provider} onChange={e => setProvider(e.target.value)} className={inputClasses}>
                                {MOCK_MOMO_PROVIDERS.map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-akoma-dark">Phone Number</label>
                            <input type="tel" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} required className={inputClasses}/>
                        </div>
                    </>
                )}
            </main>
            <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">{t.common.cancel}</button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700">{t.common.add}</button>
            </footer>
        </form>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                {step === 1 ? renderStepOne() : renderStepTwo()}
            </div>
        </div>
    );
};

export default AddPayoutMethodModal;
