
import React, { useState } from 'react';
import { useApp } from '../../../contexts/AppContext';
import { Task } from '../../../types';

interface AddTaskModalProps {
    patientName: string;
    onClose: () => void;
}

const AddTaskModal: React.FC<AddTaskModalProps> = ({ patientName, onClose }) => {
    const { addTaskForPatient, addToast } = useApp();
    const [description, setDescription] = useState('');
    const [priority, setPriority] = useState<Task['priority']>('Medium');
    const [dueDate, setDueDate] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!description.trim()) {
            addToast({ message: 'Task description cannot be empty.', type: 'error' });
            return;
        }
        addTaskForPatient(patientName, {
            description,
            priority,
            dueDate: dueDate || undefined,
        });
        onClose();
    };
    
    const inputClasses = "mt-1 block w-full p-2 border rounded-md bg-akoma-dark text-white border-akoma-grey placeholder-gray-400 focus:ring-akoma-blue focus:border-akoma-blue";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <header className="p-6 border-b">
                    <h3 className="text-xl font-bold text-akoma-blue">Add Task for {patientName}</h3>
                </header>
                <main className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Task Description</label>
                        <textarea
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            rows={3}
                            className={inputClasses}
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Priority</label>
                        <select value={priority} onChange={e => setPriority(e.target.value as Task['priority'])} className={inputClasses}>
                            <option>High</option>
                            <option>Medium</option>
                            <option>Low</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-akoma-dark">Due Date (Optional)</label>
                        <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} className={inputClasses} />
                    </div>
                </main>
                <footer className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-akoma-grey bg-white border border-gray-300 rounded-md hover:bg-gray-50">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm text-white bg-akoma-blue rounded-md">Add Task</button>
                </footer>
            </form>
        </div>
    );
};

export default AddTaskModal;
