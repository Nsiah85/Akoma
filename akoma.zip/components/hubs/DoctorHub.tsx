import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import ProviderCalendarView from './provider/ProviderCalendarView';
import UserSettingsView from './shared/UserSettingsView';
import FindProviders from './patient/FindProviders';
import WellnessStore from './patient/WellnessStore';
import AddPatientModal from './shared/AddPatientModal';
import { Patient, UserRole } from '../../types';
import RequestLabModal from './provider/actions/RequestLabModal';
import RequestMeetingModal from './provider/actions/RequestMeetingModal';
import WritePrescriptionModal from './provider/actions/WritePrescriptionModal';
import WriteReportModal from './provider/actions/WriteReportModal';

type DoctorTab = 'dashboard' | 'my-patients' | 'availability' | 'find-providers' | 'wellness-store' | 'settings';
type ActionModal = 'lab' | 'meeting' | 'prescription' | 'report' | null;

const MyPatientsView: React.FC<{ onAction: (patient: Patient, action: ActionModal) => void }> = ({ onAction }) => {
    const { allUsers } = useApp();
    const patients = allUsers.filter(u => u.role === UserRole.Patient) as Patient[];
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-sm">
             <h3 className="text-xl font-bold text-akoma-blue mb-4">My Patients</h3>
             <div className="space-y-3">
                {patients.map(patient => (
                    <div key={patient.id} className="p-3 border rounded-md flex justify-between items-center">
                        <div>
                            <p className="font-semibold">{patient.name}</p>
                            <p className="text-sm text-akoma-grey">{patient.akomaId}</p>
                        </div>
                        <div className="relative">
                            <select 
                                onChange={(e) => onAction(patient, e.target.value as ActionModal)} 
                                className="text-sm font-semibold text-white bg-akoma-blue rounded-md px-3 py-1 appearance-none cursor-pointer"
                                value=""
                            >
                                <option value="" disabled>Manage...</option>
                                <option value="meeting">Request Meeting</option>
                                <option value="lab">Request Lab</option>
                                <option value="prescription">Write Prescription</option>
                                <option value="report">Write Report</option>
                            </select>
                        </div>
                    </div>
                ))}
             </div>
        </div>
    );
};

const DoctorHub: React.FC = () => {
    const { t, activeHubTab, setActiveHubTab } = useApp();
    const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);

    // State for action modals
    const [actionModal, setActionModal] = useState<ActionModal>(null);
    const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);

    const handleAction = (patient: Patient, action: ActionModal) => {
        setSelectedPatient(patient);
        setActionModal(action);
    };

    const closeActionModal = () => {
        setSelectedPatient(null);
        setActionModal(null);
    };

    const TabButton: React.FC<{ tabName: DoctorTab, label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveHubTab(tabName)}
            className={`px-4 py-2 font-semibold rounded-md transition-colors text-sm ${activeHubTab === tabName ? 'bg-akoma-blue text-white' : 'text-akoma-grey hover:bg-gray-200'}`}
        >
            {label}
        </button>
    );

    const renderContent = () => {
        switch (activeHubTab) {
            case 'my-patients':
                return <MyPatientsView onAction={handleAction} />;
            case 'availability':
                return <ProviderCalendarView />;
            case 'find-providers':
                return <FindProviders />;
            case 'wellness-store':
                return <WellnessStore />;
            case 'settings':
                return <UserSettingsView />;
            case 'dashboard':
            default:
                 if (window.innerWidth < 768 && !['dashboard', 'settings', 'my-patients'].includes(activeHubTab)) {
                    setActiveHubTab('dashboard');
                }
                return (
                     <>
                        <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
                            <h3 className="text-xl font-bold text-akoma-blue mb-4">Quick Actions</h3>
                            <button
                                onClick={() => setIsAddPatientModalOpen(true)}
                                className="px-4 py-2 text-sm font-medium text-white bg-akoma-blue rounded-md hover:bg-blue-700"
                            >
                                Add New Patient
                            </button>
                        </div>
                        <div className="bg-white p-6 rounded-lg shadow-sm">
                            <p>Welcome, Doctor. Your patient list and schedule will be displayed here.</p>
                        </div>
                     </>
                );
        }
    }

    return (
        <div className="max-w-6xl mx-auto">
            {isAddPatientModalOpen && <AddPatientModal onClose={() => setIsAddPatientModalOpen(false)} />}
            {selectedPatient && (
                <>
                    {actionModal === 'lab' && <RequestLabModal patient={selectedPatient} onClose={closeActionModal} />}
                    {actionModal === 'meeting' && <RequestMeetingModal patient={selectedPatient} onClose={closeActionModal} />}
                    {actionModal === 'prescription' && <WritePrescriptionModal patient={selectedPatient} onClose={closeActionModal} />}
                    {actionModal === 'report' && <WriteReportModal patient={selectedPatient} onClose={closeActionModal} />}
                </>
            )}
            <h2 className="text-3xl font-bold text-akoma-dark mb-6">{t.doctorHub.dashboardTitle}</h2>
            <div className="mb-6 bg-white p-2 rounded-lg shadow-sm space-x-2 flex-wrap hidden md:inline-flex">
                <TabButton tabName="dashboard" label={t.common.dashboard} />
                <TabButton tabName="my-patients" label="My Patients" />
                <TabButton tabName="availability" label={t.doctorHub.availability} />
                <TabButton tabName="find-providers" label={t.common.findProviders} />
                <TabButton tabName="wellness-store" label={t.common.wellnessStore} />
                <TabButton tabName="settings" label={t.common.settings} />
            </div>
            {renderContent()}
        </div>
    );
};

export default DoctorHub;