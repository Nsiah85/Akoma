import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { Conversation, ChatMessage, User } from '../types';
import { ReadReceiptIcon } from './icons/ReadReceiptIcon';

const PaperAirplaneIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>;
const PaperClipIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.122 2.122l7.81-7.81" /></svg>;

const ChatView: React.FC<{ conversation: Conversation; onBack: () => void }> = ({ conversation, onBack }) => {
    const { user, sendMessage, markMessagesAsRead } = useApp();
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const recipient = conversation.participants.find(p => p.id !== user?.id);

    useEffect(() => {
        markMessagesAsRead(conversation.id);
    }, [conversation.id, markMessagesAsRead]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [conversation.messages, conversation.isTyping]);

    const handleSend = () => {
        if (!input.trim() || !user) return;
        sendMessage(conversation.id, { senderId: user.id, text: input });
        setInput('');
    };

    return (
        <>
            <header className="p-4 border-b flex items-center space-x-3 flex-shrink-0">
                <button onClick={onBack} className="text-akoma-blue font-bold text-lg">&larr;</button>
                <img src={recipient?.profileImageUrl} alt={recipient?.name} className="w-8 h-8 rounded-full object-cover" />
                <h4 className="font-bold text-akoma-dark truncate">{recipient?.name}</h4>
            </header>
            <main className="flex-1 p-4 overflow-y-auto space-y-4">
                {conversation.messages.map(msg => (
                    <div key={msg.id} className={`flex items-end space-x-2 ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}>
                        {msg.senderId === user?.id && msg.readStatus && <ReadReceiptIcon status={msg.readStatus} className="w-4 h-4 text-akoma-blue mb-1" />}
                        <div className={`max-w-xs px-3 py-2 rounded-lg ${msg.senderId === user?.id ? 'bg-akoma-blue text-white' : 'bg-gray-200'}`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                 {conversation.isTyping && (
                    <div className="flex justify-start">
                        <div className="px-3 py-2 rounded-lg bg-gray-200">
                             <div className="flex items-center space-x-1">
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
                                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
                            </div>
                        </div>
                    </div>
                 )}
                <div ref={messagesEndRef} />
            </main>
            <footer className="p-2 border-t flex items-center space-x-2 flex-shrink-0">
                <button className="p-2 text-gray-500 hover:text-akoma-blue"><PaperClipIcon className="w-6 h-6" /></button>
                <input
                    type="text"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyPress={e => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message..."
                    className="w-full p-2 border rounded-full bg-gray-100"
                />
                <button onClick={handleSend} className="p-2 text-white bg-akoma-blue rounded-full"><PaperAirplaneIcon className="w-6 h-6" /></button>
            </footer>
        </>
    );
};

const ConversationListView: React.FC<{onSelectConversation: (c: Conversation) => void; onNewChat: () => void;}> = ({ onSelectConversation, onNewChat }) => {
    const { conversations, user } = useApp();
    return (
        <>
            <div className="p-4 border-b flex justify-between items-center flex-shrink-0">
                <h4 className="font-bold text-akoma-dark">Inbox</h4>
                <button onClick={onNewChat} className="text-sm text-akoma-blue font-semibold hover:underline">New Chat</button>
            </div>
            <div className="flex-1 overflow-y-auto">
                {conversations.map(convo => {
                    const recipient = convo.participants.find(p => p.id !== user?.id);
                    const lastMessage = convo.messages[convo.messages.length - 1];
                    const unreadCount = convo.messages.filter(m => !m.isReadByRecipient && m.senderId !== user?.id).length;

                    return (
                        <div key={convo.id} onClick={() => onSelectConversation(convo)} className="flex items-center space-x-3 p-4 border-b last:border-0 hover:bg-gray-50 cursor-pointer">
                           <img src={recipient?.profileImageUrl} alt={recipient?.name} className="w-10 h-10 rounded-full object-cover" />
                           <div className="flex-1 overflow-hidden">
                                <p className="font-semibold text-akoma-dark truncate">{recipient?.name}</p>
                                <p className="text-sm text-akoma-grey truncate">{lastMessage?.text || 'No messages yet'}</p>
                           </div>
                           {unreadCount > 0 && <span className="text-xs bg-akoma-blue text-white rounded-full w-5 h-5 flex items-center justify-center">{unreadCount}</span>}
                        </div>
                    )
                })}
            </div>
        </>
    );
};

const NewChatView: React.FC<{onBack: () => void; onSelectUser: (u: User) => void;}> = ({ onBack, onSelectUser }) => {
    const { user, allUsers } = useApp();
    const otherUsers = allUsers.filter(u => u.id !== user?.id);
    return (
        <>
            <header className="p-4 border-b flex items-center space-x-3 flex-shrink-0">
                <button onClick={onBack} className="text-akoma-blue font-bold text-lg">&larr;</button>
                <h4 className="font-bold text-akoma-dark">Start a new chat</h4>
            </header>
            <main className="flex-1 overflow-y-auto">
                {otherUsers.map(u => (
                    <div key={u.id} onClick={() => onSelectUser(u)} className="flex items-center space-x-3 p-3 border-b hover:bg-gray-50 cursor-pointer">
                        <img src={u.profileImageUrl} alt={u.name} className="w-10 h-10 rounded-full object-cover" />
                        <div>
                            <p className="font-semibold text-akoma-dark">{u.name}</p>
                            <p className="text-sm text-akoma-grey">{u.role}</p>
                        </div>
                    </div>
                ))}
            </main>
        </>
    );
};


const Inbox: React.FC = () => {
    const { conversations, allUsers, user, startConversationWithUser } = useApp();
    const [view, setView] = useState<'list' | 'chat' | 'new'>('list');
    const [selectedConvoId, setSelectedConvoId] = useState<string | null>(null);

    const handleSelectConversation = (convo: Conversation) => {
        setSelectedConvoId(convo.id);
        setView('chat');
    };
    
    const handleStartNewChatWithUser = (userToChat: User) => {
        const convo = startConversationWithUser(userToChat);
        setSelectedConvoId(convo.id);
        setView('chat');
    }
    
    const renderContent = () => {
        if (view === 'chat' && selectedConvoId) {
            const conversation = conversations.find(c => c.id === selectedConvoId);
            if (!conversation) {
                setView('list'); // Safety check
                return null;
            }
            return <ChatView conversation={conversation} onBack={() => setView('list')} />;
        }
        
        if (view === 'new') {
            return <NewChatView onBack={() => setView('list')} onSelectUser={handleStartNewChatWithUser} />;
        }
        
        return <ConversationListView onSelectConversation={handleSelectConversation} onNewChat={() => setView('new')} />;
    }

    return (
        <div className="absolute right-0 mt-2 w-96 h-[500px] bg-white rounded-lg shadow-xl border z-30 animate-fade-in-fast flex flex-col">
            {renderContent()}
        </div>
    );
};

export default Inbox;