
import React from 'react';

const Sidebar: React.FC = () => {
    return (
        <aside className="w-64 bg-white p-4">
            <h2 className="font-bold text-lg">Navigation</h2>
            {/* Navigation links will go here */}
        </aside>
    );
};

export default Sidebar;
