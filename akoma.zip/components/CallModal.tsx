import React, { useState, useEffect } from 'react';
import { MicrophoneOnIcon, MicrophoneOffIcon, CameraOnIcon, CameraOffIcon, EndCallIcon } from './icons/CallIcons';
import { useOutsideClick } from '../hooks/useOutsideClick';

interface CallModalProps {
  callType: 'voice' | 'video';
  recipient: { name: string; profileImageUrl?: string };
  onClose: () => void;
}

const CallModal: React.FC<CallModalProps> = ({ callType, recipient, onClose }) => {
    const [callStatus, setCallStatus] = useState<'ringing' | 'connected' | 'ended'>('ringing');
    const [isMuted, setIsMuted] = useState(false);
    const [isCameraOn, setIsCameraOn] = useState(callType === 'video');
    const [duration, setDuration] = useState(0);

    const callModalRef = useOutsideClick(() => {
        // Only allow closing via outside click if the call is still ringing
        if (callStatus === 'ringing') {
            handleEndCall();
        }
    });

    useEffect(() => {
        const connectTimer = setTimeout(() => {
            if (callStatus === 'ringing') {
                setCallStatus('connected');
            }
        }, 3000);

        return () => clearTimeout(connectTimer);
    }, [callStatus]);

    useEffect(() => {
        let interval: ReturnType<typeof setInterval>;
        if (callStatus === 'connected') {
            interval = setInterval(() => {
                setDuration(prevDuration => prevDuration + 1);
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [callStatus]);

    const formatDuration = (seconds: number) => {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    };

    const handleEndCall = () => {
        setCallStatus('ended');
        setTimeout(onClose, 500);
    };

    const statusText = {
        ringing: 'Ringing...',
        connected: formatDuration(duration),
        ended: 'Call Ended',
    };

    return (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-90 z-50 flex items-center justify-center p-4 animate-fade-in-fast">
            <div ref={callModalRef} className="flex flex-col items-center justify-center">
                <div className="text-center text-white mb-8">
                    <p className="text-3xl font-bold">{recipient.name}</p>
                    <p className="text-lg mt-2">{statusText[callStatus]}</p>
                </div>

                <div className="relative mb-12">
                    {recipient.profileImageUrl ? (
                        <img src={recipient.profileImageUrl} alt={recipient.name} className="w-40 h-40 rounded-full object-cover ring-4 ring-white/20" />
                    ) : (
                        <div className="w-40 h-40 rounded-full bg-akoma-blue text-white flex items-center justify-center font-bold text-6xl ring-4 ring-white/20">
                            {recipient.name.charAt(0)}
                        </div>
                    )}
                </div>

                <div className="flex items-center space-x-6">
                    <button onClick={() => setIsMuted(!isMuted)} className="bg-white/20 p-4 rounded-full text-white hover:bg-white/30 transition-colors">
                        {isMuted ? <MicrophoneOffIcon className="w-7 h-7" /> : <MicrophoneOnIcon className="w-7 h-7" />}
                    </button>

                    <button onClick={handleEndCall} className="bg-red-600 p-5 rounded-full text-white transform hover:scale-110 transition-transform">
                        <EndCallIcon className="w-8 h-8" />
                    </button>

                    <button 
                        onClick={() => setIsCameraOn(!isCameraOn)} 
                        className="bg-white/20 p-4 rounded-full text-white hover:bg-white/30 transition-colors"
                        disabled={callType === 'voice'}
                    >
                        {isCameraOn ? <CameraOnIcon className="w-7 h-7" /> : <CameraOffIcon className="w-7 h-7" />}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CallModal;