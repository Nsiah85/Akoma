import React from 'react';
import { useApp } from '../contexts/AppContext';
import { Currency } from '../types';

const CurrencyModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { currency, setCurrency } = useApp();

    const handleSelectCurrency = (curr: Currency) => {
        setCurrency(curr);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-end" onClick={onClose}>
            <div 
                className="w-full bg-white rounded-t-2xl shadow-lg p-4 animate-slide-in-up flex flex-col max-h-[80vh]"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4 flex-shrink-0"></div>
                <h3 className="text-lg font-bold text-center text-akoma-dark mb-4 flex-shrink-0">Select Currency</h3>
                <ul className="space-y-2 overflow-y-auto">
                    {(Object.values(Currency) as Currency[]).map(curr => (
                        <li key={curr}>
                            <button
                                onClick={() => handleSelectCurrency(curr)}
                                className={`w-full text-left p-3 rounded-lg font-semibold ${
                                    currency === curr ? 'bg-akoma-light-blue text-akoma-blue' : 'hover:bg-gray-100'
                                }`}
                            >
                                {curr}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default CurrencyModal;
