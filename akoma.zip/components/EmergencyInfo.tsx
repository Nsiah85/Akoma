
import React, { useState } from 'react';
import { EmergencyContact } from '../types';
import { useApp } from '../contexts/AppContext';

export const EmergencyInfo: React.FC = () => {
    const { emergencyContacts } = useApp();
    const [isOpen, setIsOpen] = useState(false);
    const [selectedCountry, setSelectedCountry] = useState('GH');

    const contact: (EmergencyContact & { name: string }) | undefined = emergencyContacts[selectedCountry];

    return (
        <div className="relative">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center p-2 bg-red-100 text-red-700 rounded-full hover:bg-red-200 transition-colors"
                aria-label="Emergency Information"
                title="Emergency Information"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
            </button>
            {isOpen && (
                 <div 
                    className="absolute right-0 mt-2 w-56 sm:w-64 bg-white rounded-lg shadow-xl p-4 z-20 border"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="flex justify-between items-center mb-2">
                        <h4 className="font-bold text-akoma-dark text-md">Emergency Contact</h4>
                        <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-gray-600">&times;</button>
                    </div>
                    <p className="text-sm text-akoma-grey mb-3">In a life-threatening emergency, call your local number immediately.</p>
                    <div>
                        <select
                            value={selectedCountry}
                            onChange={(e) => setSelectedCountry(e.target.value)}
                            className="w-full p-2 border border-gray-300 rounded-md shadow-sm text-sm"
                        >
                            {/* Fix: Added a check to ensure 'contact' exists before trying to access its properties. This prevents a runtime error if a country without a contact is somehow selected. */}
                            {Object.entries(emergencyContacts).map(([code, contactData]) => (
                                <option key={code} value={code}>{contactData.name}</option>
                            ))}
                        </select>
                        {contact && (
                            <div className="mt-3 text-center bg-red-50 p-3 rounded-md">
                                <p className="text-akoma-grey text-sm">{contact.name}</p>
                                <a href={`tel:${contact.number.replace(/\s/g, '')}`} className="text-2xl font-bold text-red-700 hover:underline">
                                    {contact.number}
                                </a>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};
