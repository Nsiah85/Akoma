import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { UserRole } from '../types';
import { DashboardIcon, UsersIcon, StoreIcon } from './icons/NavIcons';
import { ProviderIcon } from './icons/ProviderIcon';
import MobileMenuSheet from './MobileMenuSheet';
import { DotsHorizontalIcon } from './icons/DotsHorizontalIcon';
import { BellIcon } from './icons/BellIcon';
import LanguageModal from './LanguageModal';
import CurrencyModal from './CurrencyModal';

const MobileNav: React.FC = () => {
    const { user, activeHubTab, setActiveHubTab, t } = useApp();
    const [isMenuSheetOpen, setIsMenuSheetOpen] = useState(false);
    const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
    const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);

    if (!user) return null;

    interface NavItem {
        id: string;
        label: string;
        icon: React.ReactNode;
        action?: () => void;
    }

    let mainNavItems: NavItem[] = [];
    let menuSheetItems: NavItem[] = [];

    const baseSheetItems = [
      { id: 'reminders', label: t.patientHub.reminders, icon: <BellIcon className="w-6 h-6" /> },
      { id: 'settings', label: t.common.settings, icon: <UsersIcon className="w-6 h-6" /> },
    ];
    
    if (user.role === UserRole.Patient) {
        mainNavItems = [
            { id: 'dashboard', label: t.common.dashboard, icon: <DashboardIcon className="w-6 h-6 mx-auto" /> },
            { id: 'find-providers', label: t.common.findProviders, icon: <ProviderIcon className="w-6 h-6 mx-auto" /> },
            { id: 'wellness-store', label: t.common.wellnessStore, icon: <StoreIcon className="w-6 h-6 mx-auto" /> },
        ];
        menuSheetItems = baseSheetItems;
    } else { // Generic nav for other professionals
         mainNavItems = [
            { id: 'dashboard', label: t.common.dashboard, icon: <DashboardIcon className="w-6 h-6 mx-auto" /> },
            { id: 'find-providers', label: t.common.findProviders, icon: <ProviderIcon className="w-6 h-6 mx-auto" /> },
            { id: 'wellness-store', label: t.common.wellnessStore, icon: <StoreIcon className="w-6 h-6 mx-auto" /> },
        ];
        menuSheetItems = [{ id: 'settings', label: t.common.settings, icon: <UsersIcon className="w-6 h-6" /> }];
    }

    return (
        <>
            <nav className="md:hidden fixed bottom-0 left-0 w-full bg-white border-t z-30 shadow-lg">
                <div className="flex justify-around items-center h-16">
                    {mainNavItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => item.action ? item.action() : setActiveHubTab(item.id)}
                            className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${
                                activeHubTab === item.id ? 'text-akoma-blue' : 'text-akoma-grey'
                            }`}
                        >
                            {item.icon}
                            <span className="text-xs mt-1">{item.label}</span>
                        </button>
                    ))}
                    <button
                        onClick={() => setIsMenuSheetOpen(true)}
                        className="flex flex-col items-center justify-center w-full text-akoma-grey"
                    >
                        <DotsHorizontalIcon className="w-6 h-6 mx-auto" />
                        <span className="text-xs mt-1">{t.common.more}</span>
                    </button>
                </div>
            </nav>
            {isMenuSheetOpen && (
                <MobileMenuSheet 
                    items={menuSheetItems} 
                    onClose={() => setIsMenuSheetOpen(false)}
                    onOpenLanguage={() => setIsLanguageModalOpen(true)}
                    onOpenCurrency={() => setIsCurrencyModalOpen(true)}
                />
            )}
            {isLanguageModalOpen && <LanguageModal onClose={() => setIsLanguageModalOpen(false)} />}
            {isCurrencyModalOpen && <CurrencyModal onClose={() => setIsCurrencyModalOpen(false)} />}
        </>
    );
};

export default MobileNav;