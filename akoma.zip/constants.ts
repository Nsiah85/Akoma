import {
  User, UserRole, Language, EmergencyContact, Patient, StaffMember, FacilityAppointment,
  Provider, LabRequest, NurseAssignment, PharmacyPrescription, InsuranceClaim, LegalCase, Vendor, PayoutAccount, FacilityPatient, Product, Currency
} from './types';

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'ak', name: 'Asante Twi' },
  { code: 'ar', name: 'العربية' },
  { code: 'ha', name: 'Hausa' },
  { code: 'sw', name: 'Kiswahili' },
  { code: 'zu', name: 'isiZulu' },
];

export const COUNTRIES = [
    { code: 'CI', name: 'Ivory Coast' },
    { code: 'EG', name: 'Egypt' },
    { code: 'ET', name: 'Ethiopia' },
    { code: 'GH', name: 'Ghana' },
    { code: 'KE', name: 'Kenya' },
    { code: 'NG', name: 'Nigeria' },
    { code: 'RW', name: 'Rwanda' },
    { code: 'SN', name: 'Senegal' },
    { code: 'ZA', name: 'South Africa' },
    { code: 'TZ', name: 'Tanzania' },
    { code: 'UG', name: 'Uganda' },
    { code: 'US', name: 'United States' },
    { code: 'GB', name: 'United Kingdom' },
];

export const MOCK_MOMO_PROVIDERS = [
    'MTN Mobile Money',
    'Vodafone Cash',
    'AirtelTigo Money',
    'M-Pesa',
    'Tigo Pesa',
];

export const MOCK_EXCHANGE_RATES: { [key in Currency]: number } = {
    [Currency.USD]: 1,
    [Currency.GHS]: 15.00,
    [Currency.EUR]: 0.92,
    [Currency.GBP]: 0.79,
    [Currency.NGN]: 1480.00,
    [Currency.KES]: 130.00,
    [Currency.ZAR]: 18.50,
};

export const EMERGENCY_CONTACTS: { [key: string]: EmergencyContact & { name: string } } = {
  CI: { name: 'Ivory Coast', number: '111' },
  EG: { name: 'Egypt', number: '123' },
  ET: { name: 'Ethiopia', number: '911' },
  GH: { name: 'Ghana', number: '999' },
  KE: { name: 'Kenya', number: '999' },
  NG: { name: 'Nigeria', number: '112' },
  RW: { name: 'Rwanda', number: '112' },
  SN: { name: 'Senegal', number: '15' },
  ZA: { name: 'South Africa', number: '10177' },
  TZ: { name: 'Tanzania', number: '112' },
  UG: { name: 'Uganda', number: '999' },
  US: { name: 'United States', number: '911' },
  GB: { name: 'United Kingdom', number: '999' },
};

export const MOCK_PATIENT_USER: Patient = {
    id: 'p001',
    akomaId: 'AKO-54321',
    name: 'Ama Serwaa',
    email: 'ama.serwaa@email.com',
    password: 'Password123!',
    country: 'GH',
    approvalStatus: 'Approved',
    role: UserRole.Patient,
    profileImageUrl: 'https://randomuser.me/api/portraits/women/68.jpg',
    joinDate: '2024-06-01',
    lastVisit: '2024-07-15',
    status: 'Active',
    onboardingCompleted: true,
    doctorNotes: ["[07/28/2024]: Please remember to monitor your blood pressure daily. We'll follow up next week."],
    medicalHistory: {
        allergies: 'Peanuts',
        conditions: 'Hypertension',
    },
    currentMedications: [
        { name: 'Lisinopril', dosage: '10mg' },
        { name: 'Atorvastatin', dosage: '20mg' },
    ],
    emergencyContacts: [
        { name: 'Kojo Mensah', number: '+233 24 123 4567', relationship: 'Husband' }
    ],
    healthSummary: [
        { metric: 'Blood Pressure', value: '135/85', status: 'high' },
        { metric: 'Heart Rate', value: '72 bpm', status: 'normal' },
        { metric: 'Cholesterol', value: '210 mg/dL', status: 'high' },
    ],
    appointments: [
        { id: 'apt001', specialty: 'Cardiology', doctor: 'Dr. Kwaku Mensah', date: '2024-08-20', time: '10:00 AM', status: 'booked' },
        { id: 'apt002', specialty: 'General Check-up', doctor: 'Dr. Kwaku Mensah', date: '2024-07-15', time: '09:30 AM', status: 'completed' },
    ],
    prescriptions: [
        { id: 'pre001', drug: 'Lisinopril 10mg', dosage: '1 tablet daily', date: '2024-07-15', dispensed: false },
        { id: 'pre002', drug: 'Atorvastatin 20mg', dosage: '1 tablet daily', date: '2024-07-15', dispensed: true },
    ],
    labResults: [
        { id: 'lab001', testName: 'Lipid Panel', date: '2024-07-10', scientificExplanation: 'Total Cholesterol: 210 mg/dL, HDL: 45 mg/dL, LDL: 140 mg/dL. Indicates hyperlipidemia.' },
    ],
};


export const MOCK_USERS: User[] = [
  MOCK_PATIENT_USER,
  { id: 'd001', akomaId: 'AKO-12345', name: 'Dr. Kwaku Mensah', email: 'dr.mensah@akoma.health', password: 'Password123!', country: 'GH', approvalStatus: 'Approved', role: UserRole.Doctor, profileImageUrl: 'https://randomuser.me/api/portraits/men/75.jpg', joinDate: '2024-05-20', isListedProvider: true, specialty: 'Cardiology' },
  { id: 'a001', akomaId: 'AKO-00001', name: 'FXK holdings', email: 'admin@akoma.health', password: 'AdminPass123!', country: 'NG', approvalStatus: 'Approved', role: UserRole.Admin, profileImageUrl: 'https://randomuser.me/api/portraits/women/75.jpg', joinDate: '2024-01-10' },
  { id: 'n001', akomaId: 'AKO-67890', name: 'Nurse Adjoa', email: 'nurse.adjoa@akoma.health', password: 'Password123!', country: 'GH', approvalStatus: 'Approved', role: UserRole.Nurse, joinDate: '2024-05-15', isListedProvider: true, specialty: 'General Nursing', facilityName: 'Korle Bu Hospital' },
  { id: 'l001', akomaId: 'AKO-11223', name: 'Lab Tech Kofi', email: 'lab.kofi@akoma.health', password: 'Password123!', country: 'KE', approvalStatus: 'Approved', role: UserRole.LabTech, joinDate: '2024-04-22' },
  { id: 'ph001', akomaId: 'AKO-44556', name: 'Pharmacist Yaw', email: 'pharm.yaw@akoma.health', password: 'Password123!', country: 'US', approvalStatus: 'Approved', role: UserRole.Pharmacist, joinDate: '2024-03-30' },
  { id: 'i001', akomaId: 'AKO-77889', name: 'Insurer Bola', email: 'bola.insurer@akoma.health', password: 'Password123!', country: 'NG', approvalStatus: 'Pending', role: UserRole.Insurer, joinDate: '2024-07-25' },
  { id: 'law001', akomaId: 'AKO-99001', name: 'Lawyer Chioma', email: 'chioma.law@akoma.health', password: 'Password123!', country: 'ZA', approvalStatus: 'Approved', role: UserRole.Lawyer, joinDate: '2024-02-18' },
  { id: 'v001', akomaId: 'AKO-33445', name: 'Vendor Sade', email: 'sade.vendor@akoma.health', password: 'Password123!', country: 'GH', approvalStatus: 'Suspended', role: UserRole.Vendor, joinDate: '2024-02-01', payoutAccounts: [
      { id: 'pa_v001', type: 'bank', bankName: 'CalBank', accountHolder: 'Sade Enterprises', accountNumber: '**** **** **** 3456', isDefault: true }
  ]},
];

export const MOCK_STAFF: StaffMember[] = [
    { id: 'd001', name: 'Dr. Kwaku Mensah', role: 'Doctor', onDuty: true },
    { id: 'n001', name: 'Nurse Adjoa', role: 'Nurse', onDuty: true },
    { id: 'n002', name: 'Nurse Efua', role: 'Nurse', onDuty: false },
];

export const MOCK_FACILITY_APPOINTMENTS: FacilityAppointment[] = [
    { id: 'fa001', patientName: 'Kofi Annan', doctorName: 'Dr. Kwaku Mensah', date: '2024-08-01', time: '11:00 AM', reason: 'Follow-up' },
    { id: 'fa002', patientName: 'Abena Yeboah', doctorName: 'Dr. Kwaku Mensah', date: '2024-08-01', time: '11:30 AM', reason: 'Consultation' },
];

export const MOCK_FACILITY_PATIENTS: FacilityPatient[] = [
    { id: 'p002', name: 'Kofi Annan', akomaId: 'AKO-98765', lastVisit: '2024-07-20', doctor: 'Dr. Kwaku Mensah' },
    { id: 'p003', name: 'Abena Yeboah', akomaId: 'AKO-65432', lastVisit: '2024-07-18', doctor: 'Dr. Kwaku Mensah' },
];

export const MOCK_PROVIDERS: Provider[] = [
    { id: 'prov001', name: 'Dr. Ama Badu', specialty: 'Dermatology', location: 'Accra', available: true },
    { id: 'prov002', name: 'Dr. Kofi Osei', specialty: 'Pediatrics', location: 'Kumasi', available: true },
    { id: 'prov003', name: 'Dr. Efua Atta', specialty: 'Orthopedics', location: 'Accra', available: false },
    { id: 'prov004', name: 'Dr. Bola Adekunle', specialty: 'Cardiology', location: 'Lagos', available: true },
    { id: 'prov005', name: 'Dr. John Smith', specialty: 'General Practice', location: 'Nairobi', available: true },
];

export const MOCK_LAB_REQUESTS: LabRequest[] = [
    { id: 'lr001', patientName: 'Ama Serwaa', testName: 'Complete Blood Count', date: '2024-07-30', status: 'Pending' },
    { id: 'lr002', patientName: 'Kofi Annan', testName: 'Urinalysis', date: '2024-07-29', status: 'In Progress' },
    { id: 'lr003', patientName: 'Abena Yeboah', testName: 'Thyroid Panel', date: '2024-07-28', status: 'Completed', attachmentName: 'thyroid_results.pdf', attachmentUrl: '#' },
];

export const MOCK_PATIENTS = [MOCK_PATIENT_USER];

export const MOCK_NURSE_ASSIGNMENTS: NurseAssignment[] = [
    { patientName: 'Ama Serwaa', room: '302B', tasks: [
        { id: 't001', description: 'Administer Lisinopril', completed: true, priority: 'High', dueDate: '2024-08-05', creationDate: '2024-08-01T08:00:00Z' },
        { id: 't002', description: 'Check blood pressure (4hrs)', completed: false, priority: 'High', dueDate: '2024-08-05', creationDate: '2024-08-01T09:00:00Z' },
        { id: 't003', description: 'Morning rounds', completed: false, priority: 'Medium', creationDate: '2024-08-02T10:00:00Z' },
        { id: 't004', description: 'Update patient chart', completed: false, priority: 'Low', dueDate: '2024-08-06', creationDate: '2024-08-02T11:00:00Z' },
    ]}
];

export const MOCK_INSURANCE_CLAIMS: InsuranceClaim[] = [
    { id: 'cl001', patientName: 'Ama Serwaa', policyNumber: 'POL-12345', claimAmount: 250.00, date: '2024-07-18', status: 'Processing', isActivated: false },
    { id: 'cl002', patientName: 'Kofi Annan', policyNumber: 'POL-67890', claimAmount: 150.00, date: '2024-07-21', status: 'Approved', isActivated: true },
];

export const MOCK_LEGAL_CASES: LegalCase[] = [
    { id: 'lc001', clientName: 'Healthcare Inc.', caseType: 'Compliance', status: 'Active', lastUpdated: '2024-07-29', isActivated: true },
    { id: 'lc002', clientName: 'Pharma Co.', caseType: 'Contract Review', status: 'Closed', lastUpdated: '2024-06-15', isActivated: false },
];

export const MOCK_VENDORS: Vendor[] = [
    { id: 'ven001', name: 'Wellness Supplies Ltd.', specialty: 'Medical Equipment', applicationStatus: 'Approved', dateApplied: '2024-05-10' },
    { id: 'ven002', name: 'Healthy Eats Co.', specialty: 'Nutrition Products', applicationStatus: 'Pending', dateApplied: '2024-07-20' },
];

export const MOCK_PAYOUT_ACCOUNTS: PayoutAccount[] = [
    { id: 'pa001', type: 'bank', bankName: 'Global Trust Bank', accountHolder: 'FXK holdings Inc.', accountNumber: '**** **** **** 1234', isDefault: true },
    { id: 'pa002', type: 'bank', bankName: 'Fidelity Bank', accountHolder: 'FXK holdings Inc.', accountNumber: '**** **** **** 5678', isDefault: false },
    { id: 'pa003', type: 'paystack', email: 'payout-id-1580277@paystack.com', isDefault: false },
    { id: 'pa004', type: 'momo', provider: 'MTN Mobile Money', phoneNumber: '0247423660', isDefault: false },
];

export const MOCK_PRODUCTS: Product[] = [
  { id: 'prod001', name: 'Vitamin D3 Supplements', description: 'High-potency Vitamin D3 for bone and immune health.', price: 15.99, imageUrl: 'https://placehold.co/400x400/DBEAFE/3B82F6/png?text=Vitamin+D3', baseCurrency: Currency.USD },
  { id: 'prod002', name: 'Organic Shea Butter', description: 'Raw, unrefined shea butter for skin and hair.', price: 12.50, imageUrl: 'https://placehold.co/400x400/D1FAE5/10B981/png?text=Shea+Butter', baseCurrency: Currency.USD },
  { id: 'prod003', name: 'Digital Blood Pressure Monitor', description: 'Easy-to-use monitor for accurate home readings.', price: 45.00, imageUrl: 'https://placehold.co/400x400/E0E7FF/4338CA/png?text=BP+Monitor', baseCurrency: Currency.USD },
];