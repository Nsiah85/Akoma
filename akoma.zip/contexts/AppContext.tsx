import React, { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { User, UserRole, Patient, Notification, Conversation, ChatMessage, Language, Currency, CartItem, Product, LabResult, HealthSummary, Prescription, MedicationReminder, PayoutAccount, OnboardingData, Theme, EmergencyContact, Provider, Appointment, BankPayoutAccount, ActivityItem, NurseAssignment, Task, Toast, ConfirmationModalState } from '../types';
import { MOCK_USERS, MOCK_PATIENT_USER, MOCK_PRODUCTS, MOCK_PAYOUT_ACCOUNTS, MOCK_EXCHANGE_RATES, EMERGENCY_CONTACTS, MOCK_NURSE_ASSIGNMENTS } from '../constants';
// Fix: Corrected import to be relative, fixing module resolution error.
import { getTranslations } from '../i18n';
import { getChatResponse } from '../services/geminiService';

interface AppContextType {
  user: User | Patient | null;
  allUsers: User[];
  updateUserStatus: (userId: string, status: User['approvalStatus']) => void;
  deleteUser: (userId: string) => void;
  addUser: (details: Omit<User, 'id' | 'akomaId' | 'approvalStatus' | 'joinDate'>) => { success: boolean, message?: string };
  signIn: (identifier: string, password: string) => { success: boolean, message?: string };
  signUp: (details: Omit<User, 'id' | 'akomaId' | 'approvalStatus' | 'joinDate'>) => { success: boolean, message?: string };
  logout: () => void;
  patientData: Patient | null;
  notifications: Notification[];
  isNotificationsOpen: boolean;
  toggleNotifications: () => void;
  markNotificationsAsRead: () => void;
  addNotification: (details: { title: string; message: string; type: 'user' | 'payout' | 'system' }) => void;
  conversations: Conversation[];
  isInboxOpen: boolean;
  toggleInbox: () => void;
  sendMessage: (convoId: string, message: Pick<ChatMessage, 'senderId' | 'text' | 'attachment'>) => Promise<void>;
  markMessagesAsRead: (convoId: string) => void;
  startConversationWithUser: (userToChat: User) => Conversation;
  language: Language['code'];
  setLanguage: (langCode: Language['code']) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  t: any;
  isCartOpen: boolean;
  toggleCart: () => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartItemQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addLabResult: (result: LabResult) => void;
  updateHealthSummary: (metric: string, value: string, status: 'normal' | 'high' | 'low') => void;
  updatePrescriptionStatus: (prescriptionId: string, dispensed: boolean) => void;
  formatCurrency: (amount: number, fromCurrency?: Currency) => string;
  updateUserProfile: (profileData: Partial<User>) => void;
  updateUserPassword: (passwords: { current: string; new: string }) => { success: boolean; message: string };
  updateUserListingStatus: (isListed: boolean) => void;
  providers: Provider[];
  reminders: MedicationReminder[];
  addReminder: (reminder: Omit<MedicationReminder, 'id'>) => void;
  deleteReminder: (id: string) => void;
  activeHubTab: string;
  setActiveHubTab: (tab: string) => void;
  payoutAccounts: PayoutAccount[];
  addPayoutAccount: (account: Omit<PayoutAccount, 'id'>) => void;
  updatePayoutAccount: (account: PayoutAccount) => void;
  deletePayoutAccount: (accountId: string) => void;
  addVendorPayoutAccount: (account: Omit<BankPayoutAccount, 'id'>) => void;
  updateVendorPayoutAccount: (account: PayoutAccount) => void;
  deleteVendorPayoutAccount: (accountId: string) => void;
  isOnboarding: boolean;
  completeOnboarding: (data: OnboardingData) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  emergencyContacts: {[key: string]: EmergencyContact & { name: string }};
  updateEmergencyContact: (countryCode: string, number: string) => void;
  isForcePasswordChange: boolean;
  forcePasswordUpdate: (newPassword: string) => { success: boolean; message: string };
  addAppointmentForPatient: (patientId: string, details: Omit<Appointment, 'id'|'status'>) => void;
  addLabRequestForPatient: (patientId: string, testName: string) => void;
  addPrescriptionForPatient: (patientId: string, details: Omit<Prescription, 'id'|'dispensed'>) => void;
  addReportForPatient: (patientId: string, report: string) => void;
  activateLegalCase: (caseId: string) => void;
  activateInsuranceClaim: (claimId: string) => void;
  activityLog: ActivityItem[];
  nurseAssignments: NurseAssignment[];
  addTaskForPatient: (patientName: string, task: Omit<Task, 'id' | 'completed' | 'creationDate'>) => void;
  updateTaskStatus: (patientName: string, taskId: string, completed: boolean) => void;
  deleteTaskForPatient: (patientName: string, taskId: string) => void;
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  confirmationModal: ConfirmationModalState;
  showConfirmation: (options: Omit<ConfirmationModalState, 'isOpen'>) => void;
  hideConfirmation: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | Patient | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>(MOCK_USERS);
  const [patientData, setPatientData] = useState<Patient | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isInboxOpen, setIsInboxOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [language, setLanguage] = useState<Language['code']>('en');
  const [currency, setCurrency] = useState<Currency>(Currency.USD);
  const [t, setT] = useState(getTranslations('en'));
  const [reminders, setReminders] = useState<MedicationReminder[]>([]);
  const [activeHubTab, setActiveHubTab] = useState('dashboard');
  const [payoutAccounts, setPayoutAccounts] = useState<PayoutAccount[]>(MOCK_PAYOUT_ACCOUNTS);
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [theme, setTheme] = useState<Theme>({ background: '#F9FAFB', font: 'Inter' });
  const [emergencyContacts, setEmergencyContacts] = useState<{[key: string]: EmergencyContact & { name: string }}>(EMERGENCY_CONTACTS);
  
  // State for forced password change
  const [isForcePasswordChange, setIsForcePasswordChange] = useState(false);
  const [userForPasswordChange, setUserForPasswordChange] = useState<User | null>(null);

  // State for real-time activity log
  const [activityLog, setActivityLog] = useState<ActivityItem[]>([
     { id: 'act_3', text: "Payout of GHS 2,500.00 sent to FXK holdings Inc.", timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString() },
     { id: 'act_4', text: "Dr. Ama Badu's account has been approved.", timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString() },
  ]);
  
  const [nurseAssignments, setNurseAssignments] = useState<NurseAssignment[]>(MOCK_NURSE_ASSIGNMENTS);

  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Feedback state
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmationModal, setConfirmationModal] = useState<ConfirmationModalState>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = Date.now().toString() + Math.random();
    setToasts(prev => [...prev, { ...toast, id }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const showConfirmation = useCallback((options: Omit<ConfirmationModalState, 'isOpen'>) => {
    setConfirmationModal({ ...options, isOpen: true });
  }, []);

  const hideConfirmation = useCallback(() => {
    setConfirmationModal(prev => ({ ...prev, isOpen: false }));
  }, []);


  const addActivity = (text: string) => {
    const newActivity: ActivityItem = {
        id: `act_${Date.now()}`,
        text,
        timestamp: new Date().toISOString()
    };
    setActivityLog(prev => [newActivity, ...prev].slice(0, 10)); // Keep last 10 activities
  };
  
  const addNotification = useCallback((details: { title: string; message: string; type: 'user' | 'payout' | 'system' }) => {
    const newNotification: Notification = {
        id: `${Date.now()}`,
        date: new Date().toISOString(),
        read: false,
        ...details,
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 20));
  }, []);


  // Derive providers from allUsers whenever it changes
  useEffect(() => {
    const professionalRoles = [UserRole.Doctor, UserRole.Nurse, UserRole.Pharmacist, UserRole.LabTech];
    const listedProviders = allUsers
        .filter(u => professionalRoles.includes(u.role) && u.isListedProvider)
        .map((u): Provider => ({
            id: u.id,
            name: u.name,
            specialty: u.specialty || u.role,
            location: u.country || 'Unknown',
            available: u.approvalStatus === 'Approved',
        }));
    setProviders(listedProviders);
  }, [allUsers]);

  const updateEmergencyContact = (countryCode: string, number: string) => {
    setEmergencyContacts(prev => ({
        ...prev,
        [countryCode]: { ...prev[countryCode], number: number.trim() }
    }));
  };

  useEffect(() => {
    setT(getTranslations(language));
  }, [language]);
  
  useEffect(() => {
    document.body.style.backgroundColor = theme.background;
    document.body.style.fontFamily = `'${theme.font}', sans-serif`;
  }, [theme]);

  // Request notification permission for patients
  useEffect(() => {
      if (user?.role === UserRole.Patient && typeof window !== 'undefined' && 'Notification' in window) {
          if (Notification.permission === 'default') {
              Notification.requestPermission();
          }
      }
  }, [user]);

  // Medication reminder check interval
  useEffect(() => {
    if (user?.role !== UserRole.Patient || reminders.length === 0 || typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') {
        return;
    }

    const checkReminders = () => {
        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

        reminders.forEach(reminder => {
            if (reminder.times.includes(currentTime)) {
                new Notification('Medication Reminder', {
                    body: `It's time to take your ${reminder.medicationName} (${reminder.dosage}).`,
                    icon: '/favicon.ico' 
                });
            }
        });
    };

    const intervalId = setInterval(checkReminders, 60000); // Check every minute

    return () => clearInterval(intervalId);
  }, [reminders, user]);

  const signIn = (identifier: string, password: string): { success: boolean, message?: string } => {
    const foundUser = allUsers.find(u => (u.email.toLowerCase() === identifier.toLowerCase() || u.akomaId.toUpperCase() === identifier.toUpperCase()) && u.password === password);
    
    if (foundUser) {
        if (foundUser.approvalStatus === 'Pending') {
            return { success: false, message: getTranslations(language).auth.pendingApproval };
        }
        if (foundUser.approvalStatus === 'Suspended') {
            return { success: false, message: "Your account has been suspended. Please contact support." };
        }
        if (foundUser.temporaryPassword) {
            setUserForPasswordChange(foundUser);
            setIsForcePasswordChange(true);
            return { success: true };
        }
        setUser(foundUser);
        setActiveHubTab('dashboard'); // Reset tab on sign in
        addToast({ message: `Welcome back, ${foundUser.name.split(' ')[0]}!`, type: 'success' });
        if (foundUser.role === UserRole.Patient) {
            const patientProfile = foundUser as Patient;
            setPatientData(patientProfile);
            if (!patientProfile.onboardingCompleted) {
                setIsOnboarding(true);
            }
        }
        return { success: true };
    }
    return { success: false, message: getTranslations(language).auth.errors.authFailed };
  };
  
    const forcePasswordUpdate = (newPassword: string): { success: boolean; message: string } => {
        if (!userForPasswordChange) return { success: false, message: "No user context for password change." };

        const updatedUser = { ...userForPasswordChange, password: newPassword, temporaryPassword: false };
        setAllUsers(prev => prev.map(u => u.id === userForPasswordChange.id ? updatedUser : u));
        
        // Log the user in
        setUserForPasswordChange(null);
        setIsForcePasswordChange(false);
        setUser(updatedUser);
        setActiveHubTab('dashboard');
        addToast({ message: `Password updated successfully, ${updatedUser.name.split(' ')[0]}!`, type: 'success' });
        if (updatedUser.role === UserRole.Patient) {
            setPatientData(updatedUser as Patient);
            if (!(updatedUser as Patient).onboardingCompleted) {
                setIsOnboarding(true);
            }
        }

        return { success: true, message: "Password updated successfully." };
    };

  const addUser = (details: Omit<User, 'id' | 'akomaId' | 'approvalStatus' | 'joinDate'>): { success: boolean; message?: string; newUser?: User | Patient } => {
       if (allUsers.some(u => u.email.toLowerCase() === details.email.toLowerCase())) {
          return { success: false, message: 'An account with this email already exists.' };
      }
      const rolesRequiringApproval = [
        UserRole.Doctor,
        UserRole.Nurse,
        UserRole.LabTech,
        UserRole.Pharmacist,
        UserRole.FacilityAdmin,
      ];
      const requiresApproval = rolesRequiringApproval.includes(details.role);
      
      const baseUser: User = {
          ...details,
          id: `user_${Date.now()}`,
          akomaId: `AKO-${Math.floor(10000 + Math.random() * 90000)}`,
          joinDate: new Date().toISOString().split('T')[0],
          approvalStatus: requiresApproval ? 'Pending' : 'Approved',
          temporaryPassword: user?.role !== UserRole.Admin, // User signing up doesn't have temp pass, one added by Admin/Dr does.
      };

      let newUser: User | Patient = baseUser;
      
      if (details.role === UserRole.Patient) {
          newUser = {
              ...baseUser,
              role: UserRole.Patient,
              lastVisit: new Date().toISOString().split('T')[0],
              status: 'Active',
              healthSummary: [],
              appointments: [],
              prescriptions: [],
              labResults: [],
              doctorNotes: [],
              onboardingCompleted: false,
              emergencyContacts: [],
              currentMedications: [],
              medicalHistory: { allergies: '', conditions: '' },
          } as Patient;
      }
      
      setAllUsers(prev => [...prev, newUser]);

      // Add to activity log & notify admin
      const activityText = `New ${newUser.role.toLowerCase()}, ${newUser.name}, created an account.`;
      addActivity(activityText);
      addNotification({ title: 'New User', message: activityText, type: 'user' });

      // Simulate sending invite if a professional adds a patient
      if (user && user.role !== UserRole.Admin && newUser.role === UserRole.Patient) {
          addToast({
              message: `An invitation has been sent to ${newUser.email} with their temporary login details.`,
              type: 'info',
              duration: 10000,
          });
      }

      return { success: true, newUser };
  }

  const signUp = (details: Omit<User, 'id' | 'akomaId' | 'approvalStatus' | 'joinDate'>): { success: boolean, message?: string } => {
      const result = addUser(details);
      if (!result.success || !result.newUser) {
        return { success: false, message: result.message };
      }
      
      const { newUser } = result;

      if (newUser.approvalStatus === 'Approved') {
          setUser(newUser);
          setActiveHubTab('dashboard');
          if (newUser.role === UserRole.Patient) {
              setPatientData(newUser as Patient);
              setIsOnboarding(true);
          }
           return { success: true };
      } else {
           return { success: true, message: getTranslations(language).auth.pendingApproval };
      }
  };

  const logout = () => {
    setUser(null);
    setPatientData(null);
    setIsOnboarding(false);
    setActiveHubTab('dashboard'); // Reset tab on logout
    setIsForcePasswordChange(false);
    setUserForPasswordChange(null);
  };

  const toggleNotifications = () => setIsNotificationsOpen(prev => !prev);
  const markNotificationsAsRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));

  const [conversations, setConversations] = useState<Conversation[]>([
      {
        id: 'convo001',
        participants: [{id: 'p001', name: 'Ama Serwaa', profileImageUrl: 'https://randomuser.me/api/portraits/women/68.jpg'}, {id: 'd001', name: 'Dr. Kwaku Mensah', profileImageUrl: 'https://randomuser.me/api/portraits/men/75.jpg'}],
        messages: [
            { id: 'msg001', senderId: 'd001', text: 'Hello Ama, please remember to take your medication.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), isReadByRecipient: true, readStatus: 'read' },
            { id: 'msg002', senderId: 'p001', text: 'Thank you, doctor. I will.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 23).toISOString(), isReadByRecipient: true, readStatus: 'read' },
        ],
        isTyping: false
      }
  ]);
  
  const toggleInbox = () => setIsInboxOpen(prev => !prev);
  
  const markMessagesAsRead = useCallback((convoId: string) => {
    if(!user) return;
    setConversations(prev => prev.map(convo => {
        if (convo.id === convoId) {
            return {
                ...convo,
                messages: convo.messages.map(msg => msg.senderId !== user.id ? { ...msg, isReadByRecipient: true, readStatus: 'read' } : msg)
            };
        }
        return convo;
    }));
  }, [user]);

  const startConversationWithUser = (userToChat: User): Conversation => {
    if (!user) throw new Error("Current user not found.");
    
    // Check if a conversation already exists
    const existingConvo = conversations.find(c => 
        c.participants.some(p => p.id === userToChat.id) && c.participants.some(p => p.id === user.id)
    );
    if (existingConvo) return existingConvo;

    // Create a new conversation
    const newConvo: Conversation = {
        id: `convo_${Date.now()}`,
        participants: [
            { id: user.id, name: user.name, profileImageUrl: user.profileImageUrl },
            { id: userToChat.id, name: userToChat.name, profileImageUrl: userToChat.profileImageUrl },
        ],
        messages: [],
        isTyping: false,
    };
    setConversations(prev => [newConvo, ...prev]);
    return newConvo;
  }

  const sendMessage = async (convoId: string, message: Pick<ChatMessage, 'senderId' | 'text' | 'attachment'>) => {
    const newMessage: ChatMessage = {
      ...message,
      id: `msg_${Date.now()}`,
      timestamp: new Date().toISOString(),
      isReadByRecipient: false,
      readStatus: 'sent',
    };

    const updatedConversations = conversations.map(c => 
        c.id === convoId ? { ...c, messages: [...c.messages, newMessage], isTyping: true } : c
    );
    setConversations(updatedConversations);

    // Simulate AI response
    const convo = updatedConversations.find(c => c.id === convoId);
    if(convo && user) {
        setTimeout(async () => {
            const aiResponseText = await getChatResponse(convo.messages, message.text);
            const recipient = convo.participants.find(p => p.id !== user.id)!;

            const aiMessage: ChatMessage = {
                id: `msg_${Date.now() + 1}`,
                senderId: recipient.id,
                text: aiResponseText,
                timestamp: new Date().toISOString(),
                isReadByRecipient: false,
            }
            setConversations(prev => prev.map(c => 
                c.id === convoId ? { ...c, messages: [...c.messages, aiMessage], isTyping: false } : c
            ));
            addNotification({ title: 'New Message', message: `You have a new message from ${recipient.name}.`, type: 'system' });
        }, 1500);
    }
  };
  
  const toggleCart = () => setIsCartOpen(prev => !prev);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { product, quantity }];
    });
  };

  const updateCartItemQuantity = (productId: string, quantity: number) => {
    setCart(prev => {
      if (quantity <= 0) {
        return prev.filter(item => item.product.id !== productId);
      }
      return prev.map(item => 
        item.product.id === productId ? { ...item, quantity } : item
      );
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };


  const clearCart = () => setCart([]);
  
    const addProduct = (productData: Omit<Product, 'id'>) => {
        const newProduct: Product = {
            ...productData,
            id: `prod_${Date.now()}`,
        };
        setProducts(prev => [newProduct, ...prev]);
        addActivity(`New product "${newProduct.name}" was added.`);
    };

    const updateProduct = (updatedProduct: Product) => {
        setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    };

    const deleteProduct = (productId: string) => {
        setProducts(prev => prev.filter(p => p.id !== productId));
    };


  const addLabResult = (result: LabResult) => {
    if (patientData) {
      setPatientData({ ...patientData, labResults: [...patientData.labResults, result] });
    }
  };
  
  const updateHealthSummary = (metric: string, value: string, status: HealthSummary['status']) => {
      if (patientData) {
          const existingMetricIndex = patientData.healthSummary.findIndex(s => s.metric === metric);
          const newSummary = [...patientData.healthSummary];
          if(existingMetricIndex > -1) {
              newSummary[existingMetricIndex] = { metric, value, status };
          } else {
              newSummary.push({ metric, value, status });
          }
          setPatientData({ ...patientData, healthSummary: newSummary });
      }
  };

  const updatePrescriptionStatus = (prescriptionId: string, dispensed: boolean) => {
      if(patientData) {
          setPatientData({ ...patientData, prescriptions: patientData.prescriptions.map(p => p.id === prescriptionId ? {...p, dispensed } : p)});
      }
  };

  const formatCurrency = (amount: number, fromCurrency: Currency = Currency.USD): string => {
    const toCurrency = currency;
    const rate = (MOCK_EXCHANGE_RATES[toCurrency] || 1) / (MOCK_EXCHANGE_RATES[fromCurrency] || 1);
    const convertedAmount = amount * rate;
    
    let locale = 'en-US'; // Default
    switch (language) {
      case 'fr': locale = 'fr-FR'; break;
      case 'es': locale = 'es-ES'; break;
      case 'ak': locale = 'ak-GH'; break;
      case 'ha': locale = 'ha-NG'; break;
      case 'sw': locale = 'sw-KE'; break;
      case 'zu': locale = 'zu-ZA'; break;
    }

    try {
      return new Intl.NumberFormat(locale, { style: 'currency', currency: toCurrency }).format(convertedAmount);
    } catch (e) {
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: toCurrency }).format(convertedAmount);
    }
  };
  
  const updateUserProfile = (profileData: Partial<User>) => {
      if (!user) return;
      const updatedUser = { ...user, ...profileData };
      setUser(updatedUser as User | Patient); // Allow Patient type
      setAllUsers(prev => prev.map(u => u.id === user.id ? updatedUser as User : u));
      
      if(patientData && updatedUser.role === UserRole.Patient) {
          setPatientData({ ...patientData, ...profileData, role: UserRole.Patient });
      }
  };

  const updateUserPassword = (passwords: { current: string, new: string }): { success: boolean, message: string } => {
      if (!user || !user.password) return { success: false, message: 'User not found.' };
      if (user.password !== passwords.current) {
          return { success: false, message: 'Current password does not match.' };
      }
      const updatedUser = { ...user, password: passwords.new };
      setUser(updatedUser as User | Patient); // Allow Patient type
      setAllUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
       if (patientData && updatedUser.role === UserRole.Patient) {
          setPatientData({ ...patientData, ...updatedUser, role: UserRole.Patient });
      }
      return { success: true, message: 'Password updated successfully!' };
  };

  const updateUserListingStatus = (isListed: boolean) => {
    if (!user) return;
    updateUserProfile({ isListedProvider: isListed });
  };

  const addReminder = (reminder: Omit<MedicationReminder, 'id'>) => {
    const newReminder: MedicationReminder = {
        ...reminder,
        id: `rem_${Date.now()}`,
    };
    setReminders(prev => [...prev, newReminder]);
  };

  const deleteReminder = (id: string) => {
      setReminders(prev => prev.filter(r => r.id !== id));
  };

  const updateUserStatus = (userId: string, status: User['approvalStatus']) => {
      setAllUsers(prev => prev.map(u => {
        if (u.id === userId) {
            const activityText = `${u.name}'s account has been ${status.toLowerCase()}.`;
            addActivity(activityText);
            addNotification({ title: 'User Status Updated', message: activityText, type: 'user' });
            return { ...u, approvalStatus: status };
        }
        return u;
      }));
  };
  
  const deleteUser = (userId: string) => {
      const userToDelete = allUsers.find(u => u.id === userId);
      if (userToDelete) {
          addToast({ message: `User ${userToDelete.name} has been deleted.`, type: 'info' });
          setAllUsers(prev => prev.filter(u => u.id !== userId));
      }
  };

  const addPayoutAccount = (account: Omit<PayoutAccount, 'id'>) => {
    const newAccount = { ...account, id: `pa_${Date.now()}` } as PayoutAccount;
    setPayoutAccounts(prev => [...prev, newAccount]);
  };

  const updatePayoutAccount = (updatedAccount: PayoutAccount) => {
    setPayoutAccounts(prev => {
        // If setting a new default, unset the old one
        if (updatedAccount.isDefault) {
            return prev.map(acc => 
                acc.id === updatedAccount.id ? updatedAccount : { ...acc, isDefault: false }
            );
        }
        return prev.map(acc => acc.id === updatedAccount.id ? updatedAccount : acc);
    });
  };

  const addVendorPayoutAccount = (account: Omit<BankPayoutAccount, 'id'>) => {
    if (!user) return;
    const newAccount: BankPayoutAccount = {
        ...account,
        id: `pa_v_${Date.now()}`
    };
    const updatedAccounts = [...(user.payoutAccounts || []), newAccount];
    updateUserProfile({ payoutAccounts: updatedAccounts });
  };
  
  const updateVendorPayoutAccount = (updatedAccount: PayoutAccount) => {
      if (!user || !user.payoutAccounts) return;
      
      const updatedAccounts = user.payoutAccounts.map(acc => {
          if (updatedAccount.isDefault) {
             return acc.id === updatedAccount.id ? { ...acc, ...updatedAccount, isDefault: true } : { ...acc, isDefault: false };
          }
          return acc.id === updatedAccount.id ? { ...acc, ...updatedAccount } : acc;
      });
      
      updateUserProfile({ payoutAccounts: updatedAccounts });
  };

  const deletePayoutAccount = (accountId: string) => {
    setPayoutAccounts(prev => {
      const accountToDelete = prev.find(acc => acc.id === accountId);
      if (!accountToDelete) return prev;
      
      const remainingAccounts = prev.filter(acc => acc.id !== accountId);

      if (accountToDelete.isDefault && remainingAccounts.length > 0) {
          const newAccountsWithDefault = remainingAccounts.map((acc, index) => ({
              ...acc,
              isDefault: index === 0
          }));
          return newAccountsWithDefault;
      }
      return remainingAccounts;
    });
  };

  const deleteVendorPayoutAccount = (accountId: string) => {
      if (!user || !user.payoutAccounts) return;
      
      const accountToDelete = user.payoutAccounts.find(acc => acc.id === accountId);
      if (!accountToDelete) return;

      let updatedAccounts = user.payoutAccounts.filter(acc => acc.id !== accountId);

      if (accountToDelete.isDefault && updatedAccounts.length > 0) {
          updatedAccounts = updatedAccounts.map((acc, index) => ({
              ...acc,
              isDefault: index === 0
          }));
      }

      updateUserProfile({ payoutAccounts: updatedAccounts });
  };

  const completeOnboarding = (data: OnboardingData) => {
      if (patientData) {
          const updatedPatient: Patient = {
              ...patientData,
              medicalHistory: {
                  allergies: data.allergies,
                  conditions: data.conditions,
              },
              currentMedications: data.medications,
              emergencyContacts: data.emergencyContacts,
              onboardingCompleted: true,
          };
          setPatientData(updatedPatient);
          setUser(updatedPatient); // Also update the main user object
          setAllUsers(prev => prev.map(u => u.id === patientData.id ? updatedPatient : u));
          setIsOnboarding(false);
          addToast({ message: "Your health profile is now complete!", type: 'success'});
      }
  };

  const addAppointmentForPatient = (patientId: string, details: Omit<Appointment, 'id'|'status'>) => {
    addNotification({ title: 'New Appointment', message: `An appointment for ${details.date} has been requested for you.`, type: 'system' });
    // This is a mock; in a real app, you'd update the patient's record.
  };

  const addLabRequestForPatient = (patientId: string, testName: string) => {
      addNotification({ title: 'New Lab Request', message: `A new lab request for "${testName}" has been made.`, type: 'system' });
      // Mock
  };

  const addPrescriptionForPatient = (patientId: string, details: Omit<Prescription, 'id'|'dispensed'>) => {
      addNotification({ title: 'New Prescription', message: `A new prescription for ${details.drug} is ready.`, type: 'system' });
      // Mock
  };

  const addReportForPatient = (patientId: string, report: string) => {
    const dateStamp = new Date().toLocaleDateString();
    const newNote = `[${dateStamp}]: ${report}`;

    if (patientData && patientData.id === patientId) {
        setPatientData(prev => ({ ...prev!, doctorNotes: [...(prev?.doctorNotes || []), newNote]}));
    }

    setAllUsers(prevUsers => prevUsers.map(u => {
        if (u.id === patientId && u.role === UserRole.Patient) {
            const p = u as Patient;
            return { ...p, doctorNotes: [...(p.doctorNotes || []), newNote]};
        }
        return u;
    }));
      addNotification({ title: 'New Doctor Note', message: `A new doctor's note has been added to your profile.`, type: 'system' });
  };
  
  const activateLegalCase = (caseId: string) => {
      addNotification({ title: 'Case Activated', message: `Legal case ${caseId} has been activated.`, type: 'system' });
      // Mock
  };
  
  const activateInsuranceClaim = (claimId: string) => {
      addNotification({ title: 'Claim Activated', message: `Insurance claim ${claimId} has been activated.`, type: 'system' });
      // Mock
  }
  
  const addTaskForPatient = (patientName: string, taskDetails: Omit<Task, 'id'|'completed'|'creationDate'>) => {
    setNurseAssignments(prevAssignments => {
      return prevAssignments.map(assignment => {
        if (assignment.patientName === patientName) {
          const newTask: Task = {
            ...taskDetails,
            id: `task_${Date.now()}`,
            completed: false,
            creationDate: new Date().toISOString(),
          };
          addToast({ message: `Task added for ${patientName}.`, type: 'success' });
          return { ...assignment, tasks: [newTask, ...assignment.tasks] };
        }
        return assignment;
      });
    });
  };

  const updateTaskStatus = (patientName: string, taskId: string, completed: boolean) => {
    setNurseAssignments(prevAssignments => {
      return prevAssignments.map(assignment => {
        if (assignment.patientName === patientName) {
          return {
            ...assignment,
            tasks: assignment.tasks.map(task => 
              task.id === taskId ? { ...task, completed } : task
            )
          };
        }
        return assignment;
      });
    });
  };

  const deleteTaskForPatient = (patientName: string, taskId: string) => {
    setNurseAssignments(prevAssignments => {
        return prevAssignments.map(assignment => {
            if (assignment.patientName === patientName) {
                addToast({ message: `Task removed for ${patientName}.`, type: 'info' });
                return { ...assignment, tasks: assignment.tasks.filter(task => task.id !== taskId) };
            }
            return assignment;
        });
    });
  };

  return (
    <AppContext.Provider value={{ 
      user,
      allUsers,
      updateUserStatus,
      deleteUser,
      addUser,
      signIn,
      signUp,
      logout,
      patientData,
      notifications,
      isNotificationsOpen,
      toggleNotifications,
      markNotificationsAsRead,
      addNotification,
      conversations,
      isInboxOpen,
      toggleInbox,
      sendMessage,
      markMessagesAsRead,
      startConversationWithUser,
      language,
      setLanguage,
      currency,
      setCurrency,
      t,
      isCartOpen,
      toggleCart,
      cart,
      addToCart,
      updateCartItemQuantity,
      removeFromCart,
      clearCart,
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      addLabResult,
      updateHealthSummary,
      updatePrescriptionStatus,
      formatCurrency,
      updateUserProfile,
      updateUserPassword,
      updateUserListingStatus,
      providers,
      reminders,
      addReminder,
      deleteReminder,
      activeHubTab,
      setActiveHubTab,
      payoutAccounts,
      addPayoutAccount,
      updatePayoutAccount,
      deletePayoutAccount,
      addVendorPayoutAccount,
      updateVendorPayoutAccount,
      deleteVendorPayoutAccount,
      isOnboarding,
      completeOnboarding,
      theme,
      setTheme,
      emergencyContacts,
      updateEmergencyContact,
      isForcePasswordChange,
      forcePasswordUpdate,
      addAppointmentForPatient,
      addLabRequestForPatient,
      addPrescriptionForPatient,
      addReportForPatient,
      activateLegalCase,
      activateInsuranceClaim,
      activityLog,
      nurseAssignments,
      addTaskForPatient,
      updateTaskStatus,
      deleteTaskForPatient,
      toasts,
      addToast,
      removeToast,
      confirmationModal,
      showConfirmation,
      hideConfirmation,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};