import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Patient, ChatMessage, HealthTip } from '../types';


// Ensure the API_KEY is available in the environment variables
const apiKey = process.env.API_KEY;
if (!apiKey) {
  // In a real app, you might want to handle this more gracefully.
  // For this context, we assume it's always provided.
  throw new Error("API_KEY environment variable not set.");
}

// Fix: Pass API key as a named parameter
const ai = new GoogleGenAI({ apiKey: apiKey });

export const explainMedicalTermInLaymanTerms = async (term: string, explanation: string): Promise<string> => {
  try {
    const prompt = `You are 'akoma', a helpful and empathetic AI medical assistant. Explain the following medical result to a patient in simple, easy-to-understand layman's terms. 
    
    Your explanation should:
    1.  Start by clearly stating what the test measures in one sentence.
    2.  Explain what the results mean in a simple, reassuring, and descriptive way.
    3.  Provide a brief, general health tip related to the result without giving a diagnosis or medical advice.
    4.  End by encouraging the patient to discuss the results with their doctor for a full picture.
    
    Be clear and encouraging, but DO NOT provide a diagnosis. Keep the entire explanation concise and easy to digest.

    Medical Test: "${term}"
    Scientific Explanation: "${explanation}"

    Simple, Descriptive Explanation for a Patient:`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
       config: {
            temperature: 0.3,
       }
    });

    // Fix: Access the response text directly from the .text property
    return response.text;
  } catch (error) {
    console.error("Error explaining medical term:", error);
    return "Sorry, I couldn't process that explanation right now. Please try again later.";
  }
};

export const explainHealthMetric = async (metric: string, value: string, status: 'normal' | 'high' | 'low'): Promise<string> => {
    try {
        const prompt = `You are 'akoma', a helpful and empathetic AI medical assistant. Explain the following health metric to a patient in simple, easy-to-understand layman's terms.

        Your explanation should:
        1.  Briefly explain what the metric measures.
        2.  Explain what their specific reading of "${value}" means, especially with a status of "${status}". Use encouraging and non-alarming language.
        3.  Provide a general wellness tip related to this metric.
        4.  Conclude by advising them to talk to their doctor for personalized advice.

        Do NOT give a diagnosis or tell them they have a specific condition.

        Health Metric: "${metric}"
        Patient's Reading: "${value}" (Status: ${status})

        Simple Explanation for a Patient:`;

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.4,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error explaining health metric:", error);
        return "Sorry, I couldn't process that explanation right now. Please try again later.";
    }
}


export const getDrugPurpose = async (drugName: string): Promise<string> => {
    try {
        const prompt = `You are a helpful pharmacy assistant. In one or two simple sentences, explain the primary purpose of the following medication for a patient. Do not describe side effects or give dosage instructions. Just explain what it is generally used for.

Medication: "${drugName}"

Simple Purpose:`;
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { temperature: 0.1 }
        });
        // Fix: Access the response text directly from the .text property
        return response.text;
    } catch (error) {
        console.error("Error getting drug purpose:", error);
        return "Could not retrieve the purpose of this medication at this time.";
    }
};

export const generateDoctorNote = async (patient: Patient): Promise<string> => {
    try {
        // Create a concise summary of the patient's data
        const patientSummary = {
            name: patient.name,
            lastVisit: patient.lastVisit,
            status: patient.status,
            recentAppointment: patient.appointments.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0],
            prescriptions: patient.prescriptions.map(p => p.drug),
            recentLabResult: patient.labResults.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0],
            healthSummaryMetrics: patient.healthSummary.map(s => `${s.metric}: ${s.value} (${s.status})`),
        };

        const prompt = `You are a caring doctor writing a brief, encouraging, and easy-to-understand summary note for your patient, ${patient.name}. Based on their latest health data, create a short note (2-3 paragraphs) that covers:
        1.  A general statement about their recent visit or overall status.
        2.  A brief mention of any key results or new prescriptions and their purpose.
        3.  Positive encouragement and a reminder for their next follow-up.
        
        Do not use complex medical jargon. The tone should be supportive and clear. Address the patient directly.

        Patient Data: ${JSON.stringify(patientSummary)}

        Doctor's Note for ${patient.name}:`;

         const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { temperature: 0.5 }
        });
        // Fix: Access the response text directly from the .text property
        return response.text;
    } catch (error) {
        console.error("Error generating doctor's note:", error);
        return "Could not generate a summary at this time. Please check back later.";
    }
};


export const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const getAIResponse = async (prompt: string, imagePart?: { inlineData: { data: string; mimeType: string; } }): Promise<string> => {
    try {
        const contents: any = imagePart ? { parts: [{ text: prompt }, imagePart] } : prompt;
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: "You are 'akoma', a friendly and helpful AI health assistant. If a document or image is provided, analyze it. If it is a medical document like a lab report, extract the key information and explain it in simple, easy-to-understand layman's terms for a patient. You are not a doctor and cannot give medical advice, diagnoses, or prescriptions. Always advise users to consult a healthcare professional for medical concerns.",
                temperature: 0.7
            }
        });
        // Fix: Access the response text directly from the .text property
        return response.text;
    } catch (error) {
        console.error("Error getting AI response:", error);
        return "I'm having trouble connecting right now. Please check your connection and try again.";
    }
};

export const getChatResponse = async (conversationHistory: ChatMessage[], newMessage: string): Promise<string> => {
    try {
        // Create a simplified history for the prompt
        const history = conversationHistory.map(msg => 
            `${msg.senderId === 'p001' ? 'Patient' : 'Doctor'}: ${msg.text}`
        ).join('\n');

        const prompt = `You are Dr. Kwaku Mensah, a caring and professional doctor. You are having a secure message conversation with your patient, Ama Serwaa. Continue the conversation naturally. Keep your response concise (2-3 sentences). Do not give a diagnosis or prescription over chat. Encourage best practices and follow-ups.

Here is the conversation history:
${history}

Patient: "${newMessage}"

Your response as Dr. Kwaku Mensah:`;
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.7,
            }
        });

        // Fix: Access the response text directly from the .text property
        return response.text;
    } catch (error) {
        console.error("Error getting chat response:", error);
        return "I apologize, there seems to be a connection issue. Please let me know if I can help with anything else.";
    }
};

export const generateHealthTips = async (patient: Patient): Promise<HealthTip[]> => {
  try {
    const healthSummary = patient.healthSummary.map(s => `${s.metric}: ${s.value} (${s.status})`).join(', ');
    const conditions = patient.medicalHistory?.conditions;

    const prompt = `You are 'akoma', a friendly and helpful AI health assistant. Based on the following patient's health data, generate 3 actionable and personalized wellness tips.

The tips should be:
1. Directly relevant to their health summary and chronic conditions.
2. Encouraging, safe, and easy to follow.
3. Focused on lifestyle, diet, or mental well-being.
4. Phrased as helpful suggestions, NOT medical advice. Always end the final tip with a sentence encouraging them to speak with their doctor before making any significant lifestyle changes.

Address the patient, ${patient.name.split(' ')[0]}, in a friendly and supportive tone.

Patient Health Summary: "${healthSummary}"
Chronic Conditions: "${conditions || 'None listed'}"

Return the tips as a JSON object with a "tips" property containing an array of tip objects, each with a "title" and a "tip".`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tips: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  tip: { type: Type.STRING },
                },
                required: ['title', 'tip']
              },
            },
          },
          required: ['tips']
        },
        temperature: 0.6,
      },
    });

    // Fix: Access the response text directly from the .text property
    const jsonStr = response.text.trim();
    const result = JSON.parse(jsonStr);
    return result.tips || [];
  } catch (error) {
    console.error("Error generating health tips:", error);
    // Return a default set of tips on error
    return [
      { title: "Stay Hydrated", tip: "Drinking enough water is crucial for your energy levels and overall health. Try to carry a water bottle with you throughout the day." },
      { title: "Mindful Movement", tip: "Incorporate gentle movement into your day, like a short walk or some stretching. It's great for both your body and mind." },
      { title: "Prioritize Sleep", tip: "Aim for 7-8 hours of quality sleep per night. A consistent sleep schedule can significantly improve your well-being." },
    ];
  }
};
