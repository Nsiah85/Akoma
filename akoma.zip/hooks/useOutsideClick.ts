import { useEffect, useRef } from 'react';

/**
 * A custom hook that triggers a handler function when a click is detected outside of the referenced element.
 * @param handler - The function to call on an outside click.
 * @returns A ref object to be attached to the DOM element that should be monitored.
 */
export const useOutsideClick = (handler: () => void) => {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            // Do nothing if the click is on the referenced element or its children
            if (ref.current && !ref.current.contains(event.target as Node)) {
                handler();
            }
        };

        // Add event listener when the component mounts
        document.addEventListener('mousedown', handleClickOutside);
        
        // Clean up the event listener when the component unmounts
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [handler]); // Re-run the effect if the handler function changes

    return ref;
};