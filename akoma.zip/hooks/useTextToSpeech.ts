import { useState, useCallback, useEffect, useRef } from 'react';

export const useTextToSpeech = () => {
    const [isSpeaking, setIsSpeaking] = useState(false);
    const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

    const speak = useCallback((text: string) => {
        if (!window.speechSynthesis) {
            console.error("Text-to-speech is not supported in this browser.");
            return;
        }

        // Cancel any ongoing speech before starting a new one
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utteranceRef.current = utterance;
        
        utterance.onstart = () => {
            setIsSpeaking(true);
        };

        utterance.onend = () => {
            setIsSpeaking(false);
            utteranceRef.current = null;
        };

        utterance.onerror = (event) => {
            console.error("SpeechSynthesisUtterance.onerror", event);
            setIsSpeaking(false);
            utteranceRef.current = null;
        };

        speechSynthesis.speak(utterance);
    }, []);

    const cancel = useCallback(() => {
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
            setIsSpeaking(false);
        }
    }, []);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (speechSynthesis.speaking) {
                speechSynthesis.cancel();
            }
        };
    }, []);

    return { speak, cancel, isSpeaking };
};